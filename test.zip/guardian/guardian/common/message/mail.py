# -*- coding:utf-8 -*-
__author__ = 'Ray'

import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr


class GuardianMail:
    """
        "mail_host":"smtp.mxhichina.com",
        "smtp_port":465,
        "is_tls":1,
        "user_name":"云管测试",
        "from_addr":"junfeng.li@leaptocloud.com",
        "mail_pass":"×××××××",
        "to_addr": ["junfeng.li@leaptocloud.com"]
    """
    @classmethod
    def send_mail(cls, mail_host, smtp_port, is_tls, user_name, from_addr, mail_pass, to_addr, sub, content):

        msg = MIMEText(content, _subtype='html', _charset="utf-8")
        msg['Subject'] = sub
        # msg['From'] = formataddr(["昵称", "xxxx@xxx.com"])
        msg['From'] = formataddr([user_name, from_addr])
        msg['To'] = ";".join(to_addr)
        try:
            if is_tls:
                server = smtplib.SMTP_SSL(timeout=1)
            else:
                server = smtplib.SMTP(timeout=1)
            server.connect(mail_host, port=smtp_port)
            server.login(from_addr, mail_pass)
            server.sendmail(from_addr, to_addr, msg.as_string())
            server.close()
            return {"code": 200, "message":"邮件发送成功!"}

        except smtplib.SMTPConnectError as e:
            return {"code": e.smtp_code, "message": "邮件发送失败，连接失败!", "error": e.smtp_error}
        except smtplib.SMTPAuthenticationError as e:
            return {"code": e.smtp_code, "message": "邮件发送失败，认证错误!", "error": e.smtp_error}
        except smtplib.SMTPSenderRefused as e:
            return {"code": e.smtp_code, "message": "邮件发送失败，发件人被拒绝!", "error": e.smtp_error}
        except smtplib.SMTPRecipientsRefused as e:
            return {"code": e.smtp_code, "message": "邮件发送失败，收件人被拒绝!", "error": e.smtp_error}
        except smtplib.SMTPDataError as e:
            return {"code": e.smtp_code, "message": "邮件发送失败，数据接收拒绝!", "error": e.smtp_error}
        except smtplib.SMTPException as e:
            return {"code": 500, "message": "邮件发送失败!"}
        except Exception as e:
            return {"code": 500, "message": "邮件发送失败：邮箱连接失败!"}
