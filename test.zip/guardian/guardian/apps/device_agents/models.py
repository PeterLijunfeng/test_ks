import uuid
from sqlalchemy import Boolean, Column, String, desc
from guardian.utils.db import provide_session
from guardian.apps import CommonModel, BaseModel
from guardian.log4 import app_logger as log


class AgentScriptExecModel(BaseModel, CommonModel):
    __tablename__ = "agent_script_exec"

    id = Column(String(50), nullable=False, primary_key=True, index=True)
    host_ip = Column(String(20), nullable=False, doc="主机IP")
    host_name = Column(String(100), doc="主机名称")
    agent_name = Column(String(50), doc="Agent名称")
    agent_version = Column(String(20), doc="Agent版本")
    agent_url = Column(String(200), doc="Agent地址")
    agent_status = Column(String(10), doc="Agent状态")

    def __init__(self, *args, **kwargs):
        super(AgentScriptExecModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(AgentScriptExecModel)
        if self.id:
            qry = qry.filter(id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, offset=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('id'):
            qry = qry.filter(cls.id == kwargs.get('id'))
        if kwargs.get('host_ip'):
            qry = qry.filter(cls.host_ip == kwargs.get('host_ip'))
        if kwargs.get('host_name'):
            qry = qry.filter(cls.host_name == kwargs.get('host_name'))
        if kwargs.get('agent_name'):
            qry = qry.filter(cls.agent_name == kwargs.get('agent_name'))
        if kwargs.get('agent_version'):
            qry = qry.filter(cls.agent_version == kwargs.get('agent_version'))
        if kwargs.get('agent_url'):
            qry = qry.filter(cls.agent_url == kwargs.get('agent_url'))
        if kwargs.get('agent_status'):
            qry = qry.filter(cls.agent_status == kwargs.get('agent_status'))
        if kwargs.get('create_at'):
            qry = qry.filter(cls.create_at == kwargs.get('create_at'))
        if kwargs.get('update_at'):
            qry = qry.filter(cls.update_at == kwargs.get('update_at'))
        return qry.count(), qry.order_by(desc(AgentScriptExecModel.create_at)).limit(limit).offset((offset - 1) * limit)

    @classmethod
    @provide_session
    def add_agent_script_record(cls, host_ip, host_name, agent_name, agent_version, agent_url, agent_status,
                                session=None, **kwargs):
        obj = AgentScriptExecModel(
            host_ip=host_ip,
            host_name=host_name,
            agent_name=agent_name,
            agent_version=agent_version,
            agent_url=agent_url,
            agent_status=agent_status)
        obj.id = str(uuid.uuid4())
        session.add(obj)
        session.commit()
        return obj

    @provide_session
    def update_agent_script_record(self, agent_status, session=None):
        self.agent_status = agent_status
        session.merge(self)
        session.commit()


class DeviceAgentModel(BaseModel, CommonModel):
    __tablename__ = "device_agent"

    id = Column(String(50), primary_key=True, nullable=False, index=True)
    host_ip = Column(String(20), nullable=False, index=True, doc="主机IP")
    host_name = Column(String(100), doc="主机名称")
    ansible_conn_status = Column(Boolean, doc="连接状态")
    agent_name = Column(String(50), doc="Agent名称")
    agent_version = Column(String(20), doc="Agent版本")
    agent_url = Column(String(200), doc="Agent地址")
    agent_status = Column(String(10), doc="Agent状态")

    def __init__(self, *args, **kwargs):
        super(DeviceAgentModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(DeviceAgentModel)
        if self.id:
            qry = qry.filter(DeviceAgentModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, offset=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('id'):
            qry = qry.filter(cls.id == kwargs.get('id'))
        if kwargs.get('host_ip'):
            qry = qry.filter(cls.host_ip == kwargs.get('host_ip'))
        if kwargs.get('host_name'):
            qry = qry.filter(cls.host_name == kwargs.get('host_name'))
        if kwargs.get('ansible_conn_status'):
            qry = qry.filter(cls.ansible_conn_status == kwargs.get('ansible_conn_status'))
        if kwargs.get('agent_name'):
            qry = qry.filter(cls.agent_name == kwargs.get('agent_name'))
        if kwargs.get('agent_version'):
            qry = qry.filter(cls.agent_version == kwargs.get('agent_version'))
        if kwargs.get('agent_url'):
            qry = qry.filter(cls.agent_url == kwargs.get('agent_url'))
        if kwargs.get('agent_status'):
            qry = qry.filter(cls.agent_status == kwargs.get('agent_status'))
        res = qry.order_by(desc(DeviceAgentModel.create_at))
        qry = res.limit(limit).offset((offset - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def add_agent_list(cls, datas, session=None):
        data_list = []
        for data in datas:
            data_item = {'id': data.get('id'),
                         'host_ip': data.get('host_ip'),
                         'host_name': data.get('host_name'),
                         'ansible_conn_status': data.get('ansible_conn_status'),
                         'agent_name': data.get('agent_name'),
                         'agent_version': data.get('agent_version'),
                         'agent_url': data.get('agent_url'),
                         'agent_status': data.get('agent_status')
                         }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def update_agent_list(cls, datas, session=None):
        data_list = []
        for data in datas:
            data_item = {'id': data.get('id'),
                         'host_ip': data.get('host_ip'),
                         'host_name': data.get('host_name'),
                         'ansible_conn_status': data.get('ansible_conn_status'),
                         'agent_name': data.get('agent_name'),
                         'agent_version': data.get('agent_version'),
                         'agent_url': data.get('agent_url'),
                         'agent_status': data.get('agent_status')
                         }
            data_list.append(data_item)
        session.bulk_update_mappings(cls, data_list)

    @classmethod
    @provide_session
    def add_device_agent_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "host_ip": data_info.get("host_ip"),
                "host_name": data_info.get("host_name"),
                "ansible_conn_status": data_info.get("ansible_conn_status"),
                "agent_name": data_info.get("agent_name"),
                "agent_version": data_info.get("agent_version"),
                "agent_url": data_info.get("agent_url"),
                "agent_status": data_info.get("agent_status"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )
