#!/usr/bin/python

import os
import platform

py_version = platform.python_version()[0:1]
activate_this = '/opt/leaptocloud/cloudenv/bin/activate_this.py'

if py_version == "3":
    exec(open(activate_this).read(), dict(__file__=activate_this))
else:
    execfile(activate_this, dict(__file__=activate_this))
os.system("guardian webserver")