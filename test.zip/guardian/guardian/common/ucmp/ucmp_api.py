import requests
import json
from guardian.settings import UCMP_BASE
from guardian.log4 import app_logger as log
from guardian.common.errors import UcmpHandleException


def chk_resource_in_apps(token, app_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Subject-Token'] = token
    uri = '%s/stats/res_trend/app/%s' % (UCMP_BASE, app_id)
    resp = requests.get(uri, headers=myheaders, verify=True)
    if resp.status_code == 200:
        res_val = resp.json()
        if res_val.get('is_include_res'):
            return True
        else:
            return False
    else:
        log.error("get UCMP service data failed! URL:[%s], RST_CODE:[%s], RST_DATA:[%s]"
                  % (uri, resp.status_code, str(resp.json())))
        raise UcmpHandleException("get UCMP service data failed! URL:[%s]" % uri)


def chk_resource_in_orgs(token, org_id_list):
    """True: 组织机构下存在依赖资源信息"""
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Subject-Token'] = token
    for org_id in org_id_list:
        uri = '%s/ucmp3/resource_instance/all/count?owner_type=org&owner_id=%s' % (UCMP_BASE, org_id)
        resp = requests.get(uri, headers=myheaders, verify=True)
        if resp.ok:
            res_val = resp.json()
            return res_val.get('count', 0)
        else:
            log.error("get UCMP service data failed! URL:[%s], RST_CODE:[%s], RST_DATA:[%s]"
                      % (uri, resp.status_code, str(resp.json())))
            raise UcmpHandleException("get UCMP service data failed! URL:[%s]" % uri)


def update_user_role(token, user_id, org_id, project_id, role_list):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Subject-Token'] = token
    uri = '%s/ucmp3/user_instance' % UCMP_BASE
    data = {'userId': user_id,
            'orgId': org_id,
            'tenantId': project_id,
            'roleNameList': role_list}
    resp = requests.put(uri, data=json.dumps(data), headers=myheaders, verify=True)
    if resp.status_code == 200:
        log.info('Update user role success.')
    else:
        log.error("Update user role with ucmp failed! URL:[%s], RST_CODE:[%s], RST_DATA:[%s]"
                  % (uri, resp.status_code, str(resp.json())))
        raise UcmpHandleException("Update user role with ucmp failed! URL:[%s]" % uri)
