import paramiko
from guardian.log4 import app_logger as log
from guardian.common.errors import ParamsException
from guardian.apps.device_agents.models import AgentScriptExecModel
from guardian.settings import ANSIBLE_HOST_IP
from guardian.settings import ANSIBLE_ROOT_USER
from guardian.settings import ANSIBLE_ROOT_PASS


def connect(host, username, password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, username=username, password=password)
    if not ssh:
        log.error("host %s not connect ,please check username and password (%s,%s)" % (
            host, username, password))
        raise ParamsException("host %s not connect ,please check username and password (%s,%s)" % (
            host, username, password))
    return ssh


def exec_commands(conn, cmd):
    stdin, stdout, stderr = conn.exec_command(cmd)
    results = stdout.read()
    return results


def execute_script_by_agents(agents):
    for agent in agents:
        host_ip = agent['host_ip']
        host_name = agent['host_name']
        agent_version = agent['agent_version']
        agent_url = agent['agent_url']
        filename = agent_url.split('/')[-1]
        agent_status = "RUNNING"
        agent_script = AgentScriptExecModel.add_agent_script_record(host_ip, host_name, filename, agent_version,
                                                                    agent_url, agent_status)
        conn = connect(host=ANSIBLE_HOST_IP, username=ANSIBLE_ROOT_USER, password=ANSIBLE_ROOT_PASS)
        command = ("ansible %s -m shell -a 'curl %s -o /opt/leaptocloud/cmdb/shell/%s && "
                   "chmod 755 /opt/leaptocloud/cmdb/shell/%s'" %
                   (host_ip, agent_url, filename, filename))
        result = exec_commands(conn=conn, cmd=command)
        log.info(result)
        if "%s | SUCCESS" % (host_ip) in bytes.decode(result):
            agent_status = "SUCCESS"
        else:
            agent_status = "FAILED"
        agent_script.update_agent_script_record(agent_status)
        conn.close()
