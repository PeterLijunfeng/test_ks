
import uuid


def gen_uuid():
    return uuid.uuid4().hex
