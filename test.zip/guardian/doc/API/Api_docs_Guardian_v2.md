

# Api Docs for Guardian V3.3.2



## 用户 Users

### 验证token

1. URL: /gd/v2/user/token
2. METHOD: GET
3. request headers:
```json
{
    "X-Subject-Token": "gAAAAABcU_XFLUO85FY82xc3qB_-Q6ySf-VSltsXecq1MFom4DCDGXE4n4ctFiopMjOXNV0ehFxoKG7KUB_ZzkLu9Rh7LWa
    XRTvRVVYtQF014RQd0gRVG7nqXWqx4ejuIFYdqBB6tzy3kCIW-csYXFSTSuYyJbrVx0SY3jcJzinMFDktS0rv3ok"
}
```
4. response data:

```json
{
	"rst": "ok",
	"data": {
		"id": "87cb4da3919a47688d6a0669ea366fed",
		"name": "admin",
		"roles": {
			"ucmp": {
				"id": "1278945210e1458290cdde9417e0d7d1",
				"name": "atowflow\\u7ba1\\u7406\\u5458",
				"role_ctl": "{}",
				"role_data": "ucmp_root",
				"comments": ""
			},
			"cmdb": {
				"id": "76b8508b61a34855a736d8f785f112e8",
				"name": "\\u79df\\u6237\\u7ba1\\u7406\\u5458",
				"role_ctl": "{}",
				"role_data": "cmdb_root",
				"comments": ""
			}
		},
		"token": "gAAAAABcU_XFLUO85FY82xc3qB_-Q6ySf-VSltsXecq1MFom4DCDGXE4n4ctFiopMjOXNV0ehFxoKG7KUB_ZzkLu9Rh7LWaXRTvRVVYtQF014RQd0gRVG7nqXWqx4ejuIFYdqBB6tzy3kCIW-csYXFSTSuYyJbrVx0SY3jcJzinMFDktS0rv3ok",
		"project_id": "0eb082df17d44c8abf46414d8a1397f8",
		"project_name": "admin",
		"domain_id": "default",
		"domain_name": "Default",
		"token_expires_at": "2019-02-02T07:31:17.000000Z"
	}
}
```



### 用户登录

1. URL: /gd/v2/user/login
2. METHOD: POST
3. request body:

```json
{
   "domain_id": "1789d1",
   "username": "James Doe",
   "password": "secretsecret"
 }

```

4. response data:

```json
{
	"rst": "ok",
	"data": {
		"code": 2,
		"first_login": false,
		"user_id": "87cb4da3919a47688d6a0669ea366fed",
		"username": "admin",
		"login_project_id": "0eb082df17d44c8abf46414d8a1397f8",
		"checkout_project": false
    }
}
```
code 0: 用户不存在 code -1 :用户名或密码为空 code 1: 帐号被禁用 code 2: 登录成功 3用户认证失败


### 用户登出

注：需要token认证

1. URL: /gd/v2/user/logout
2. METHOD: GET
3. request headers:
   {
    "X-Subject-Token": "gAAAAABcU_XFLUO85FY82xc3qB_-Q6ySf-VSltsXecq1MFom4DCDGXE4n4ctFiopMjOXNV0ehFxoKG7KUB_ZzkLu9Rh7LWa
    XRTvRVVYtQF014RQd0gRVG7nqXWqx4ejuIFYdqBB6tzy3kCIW-csYXFSTSuYyJbrVx0SY3jcJzinMFDktS0rv3ok"
   }
4. response data:

```json
{
    "rst": "ok",
    "data": {}
}
```

### 用户根据project_id登录 for java

1. URL: /gd/v2/user/login/scope_project
2. METHOD: POST
3. request body:

```json
{
   "project_id": "c5143669f6ac4db6b47c3f703ca2e82a",
   "user_id": "87cb4da3919a47688d6a0669ea366fed",
   "password": "123456"
 }

```

4. response data:

```json
{
    "rst": "ok", 
    "data": {
        "user_id": "87cb4da3919a47688d6a0669ea366fed", 
        "login_project_id": "c5143669f6ac4db6b47c3f703ca2e82a"
    }
}
```



### 域信息列表

1. URL: /gd/v2/user/domain/list
2. METHOD: GET
3. response data:

```json
{
	"rst": "ok",
	"data": {
		"domains": [{
			"name": "leaptocloud",
			"id": "39c4ab7a91474111bddfd3e160e5a361"
		},
		{
			"name": "guardian",
			"id": "2cf2952e868a41a18a2fa9cdd0268990"
		},
		{
			"name": "Default",
			"id": "default"
		}]
	}
}
```



### 创建用户

注：需要token认证

1. URL: /gd/v2/user/create
2. METHOD: POST
3. request body:

```json
 {
		"name": "taikanglife",
		"realname": "chenxu.bai",
		"password": "123456",
		"default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
		"tel": "15691880739",
		"phone": "15691880739",
		"email": "383656225@qq.com",
		"enabled": 0,
		"comments": "",
		"domain_id": "default",
		"org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
		"org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]
	}

```

4. response data:

```json
{
"rst": "ok",
"data": {}
}
```



### 修改用户

注：需要token认证

1. URL: /gd/v2/user/update
2. METHOD: POST
3. request body:

```json
 {
    "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
    "name": "taikanglife",
    "realname": "chenxu.bai",
    "password": "123456",
    "default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "tel": "15691880739",
    "phone": "15691880739",
    "email": "383656225@qq.com",
    "enabled": 0,
    "comments": "",
    "domain_id": "default",
    "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
    "org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]
	}

```

4. response data:

```json
{
"rst": "ok",
"data": {"id": "51b0c1ee68ed4a7e86fffe71357f95b8"}
}

```



### 删除用户

注：需要token认证

1. URL: /gd/v2/user/delete?user_id=26ca9a3101b04c449f1c60602e30ebee
2. METHOD: DELETE
3. request params:
user_id
4. response data:

```json
{
"rst": "ok",
"data": {"id": "26ca9a3101b04c449f1c60602e30ebee"}
}

```



### 重置用户密码接口

>  系统管理 > 用户管理 > 重置密码

注：需要token认证

1. URL: /gd/v2/user/passwd/reset
2. METHOD: POST
3. request body:

```json
{
    "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
    "domain_id": "default"
}

```

4. response data:

```json
{
    "rst": "ok",
    "data": {"reset_passwd": "123456"}
}

```



### 修改用户密码接口

>  登录后，若用户token中的first_login=1，跳转修改密码页面

注：需要token认证

1. URL: /gd/v2/user/passwd/modify
2. METHOD: POST
3. request body:

```json
{
    "new_passwd":"12345678",
    "original_passwd":"123456"
}
```

4. response data:

```json
# code: 0 旧密码错误 1 密码修改成功
{
    "rst": "ok",
    "data": {"code": 1}
}
```



### 检查用户是否存在接口或通过用户名获取用户详情接口

注：需要token认证

1. URL: /gd/v2/user/check?username=
2. METHOD: GET
3. params：:
username
4. response data:

```json
# 用户存在
{
    'rst': 'ok', 
    'data': {
        'id': '87cb4da3919a47688d6a0669ea366fed', 
        'name': 'admin', 
        'realname': '管理员', 
        'default_project_id': '0eb082df17d44c8abf46414d8a1397f8', 
        'tel': None, 
        'phone': None, 
        'email': 'sd@leaptocloud.com', 
        'enabled': 1, 
        'comments': None, 
        'domain_id': 'default', 
        'org_id': 'ec6f498747c04f6c8e0fdbb1ef220595', 
        'org_array': ['c2d3ec86-84b6-4b02-9e5e-df5c573976d3', 
                      'e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a'], 
        'user_code': '123456'
    }
}

# 用户不存在
{
    'rst': 'ok', 
    'data': {}
}
```

### 根据组织机构id查询部门管理员

注：需要token认证

1. URL: /gd/v2/user/list/dept/admin
2. METHOD: GET
3. request params:
org_id
local_user：0 查询子、父组织机构管理员
            1 查询当前子组织机构管理员
4. response data:

```json
{
        "rst": "ok",
        "data": {
            "users_info": [{
                "project_id": "7fca4022faba4ba69d8cd42de409dab2",
                "user_id": "11fb50ce59ef48d3a7653c2360eb8799",
                "org_name": "",
                "org_id": "",
                "phone": "",
                "email": "superadmin@company.com",
                "username": "superadmin",
                "realname": "superadmin",
                "comments": "superadmin",
                "domain_id": "8deb6204a1e54d24b81af996490b8e92"
            }]
        }
    }
```

### 根据角色数据范围获取管理员用户

注：需要token认证

1. URL: /gd/v2/user/list/roles/admin
2. METHOD: GET
3. request params:
role_data
4. response data:

```json
{
        "rst": "ok",
        "data": {
            "users_info": [{
                "project_id": "7fca4022faba4ba69d8cd42de409dab2",
                "user_id": "11fb50ce59ef48d3a7653c2360eb8799",
                "org_name": "",
                "org_id": "",
                "phone": "",
                "email": "superadmin@company.com",
                "username": "superadmin",
                "realname": "superadmin",
                "comments": "superadmin",
                "domain_id": "8deb6204a1e54d24b81af996490b8e92"
            }]
        }
    }
```



### 获取用户详情

注：需要token认证

1. URL: /gd/v2/user/detail?user_id=26ca9a3101b04c449f1c60602e30ebee
2. METHOD: GET
3. request params:
user_id
4. response data:

```json
{
    "rst": "ok",
    "data": {
        "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
        "name": "taikanglife",
        "realname": "chenxu.bai",
        "default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "tel": "029-88880000",
        "phone": "15691880739",
        "email": "383656225@qq.com",
        "enabled": 0,
        "comments": "",
        "domain_id": "default",
        "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
        "org_name": "test1",
        "org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"],
        "org_name_array": ["test1","test2"]
    }
 }
```

### 校验用户email是否重复

注：需要token认证

1. URL: /gd/v2/user/domain/check?email=383656225@qq.com
2. METHOD: GET
3. request params:
email
4. response data:
用户email存在
```json
{
  "rst": "ok",
  "data": {"user_id": "c38a4fd167144400b8a3cfd0f5e6ea73"}
 }
```
用户email不存在
```json
{
  "rst": "ok",
  "data": {}
 }
```

### 切换租户

注：需要token认证

1. URL: /gd/v2/user/project/change?project_id=c5143669f6ac4db6b47c3f703ca2e82a
2. METHOD: GET
3. request params:
project_id
4. response data:
```json
{
    "rst": "ok",
    "data": {"user_id": "87cb4da3919a47688d6a0669ea366fed"}
 }
```



### 同步用户信息接口

**请求URL：**

- `URL: /gd/v2/sys/sync/user`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "base_dn":"OU=西安测试中心,DC=leaptocloud,DC=com"
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "sync_status": 2
    }
}
# 同步用户前需要先同步组织机构
# sync_status 0 用户同步失败
# sync_status 1 用户同步成功
# sync_status 2 用户同步中
# sync_status 3 组织机构同步中
# sync_status 4 组织机构同步失败
# sync_status 5 没有同步过组织机构，需要先同步组织机构
```





## 角色 Role

### 创建用户角色

注：需要token认证

1. URL: /gd/v2/user/roles/create
2. METHOD: POST
3. request body:

```json
 {
		"name": "平台管理员",
		"role_model_menu":[{
                        "module_id":"3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                        "sub_menu":["a7a053ba-2473-49be-8e94-9826a24b484b"]
                    }],
		"role_data": "ucmp_root",
		"role_ctl": {"F5": {"ip": ["192.168.1.1"]},
		              "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
		              "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
		"comments": "",
		"platform_name": "ucmp"
	}

```

4. response data:

```json
{
    "rst": "ok",
    "data": {}
 }
```



### 修改用户角色

注：需要token认证

1. URL: /gd/v2/user/roles/update
2. METHOD: POST
3. request body:

```json
 {
        "id": "485abaa031dd42f291d167cf723a904e",
		"name": "平台管理员",
		"role_model_menu":[{
                        "module_id":"3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                        "sub_menu":["a7a053ba-2473-49be-8e94-9826a24b484b"]
                    }],
		"role_data": "cmdb_root",
		"role_ctl": {"F5": {"ip": ["192.168.1.1"]},
		              "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
		              "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
		"comments": ""
	}

```

4. response data:

```json
{
    "rst": "ok",
    "data": {"id": "485abaa031dd42f291d167cf723a904e"}
 }
```



### 删除用户角色

注：需要token认证

1. URL: /gd/v2/user/roles/delete?role_id=26ca9a3101b04c449f1c60602e30ebee
2. METHOD: DELETE
3. request params:
role_id
4. response data:

```json
{
"rst": "ok",
"data": {"id": "26ca9a3101b04c449f1c60602e30ebee"}
}
```



### 用户分配角色

注：需要token认证

1. URL: /gd/v2/user/roles/assign
2. METHOD: POST
3. request body:

```json
{
        "user_id" : "51b0c1ee68ed4a7e86fffe71357f95b8",
        "role_id" : ["485abaa031dd42f291d167cf723a904e","1278945210e1458290cdde9417e0d7d1"]
    }
```

4. response data:

```json
{
"rst": "ok",
"data": {}
}
```

### 根据角色id和组织机构id获取管理员用户信息

注：需要token认证

1. URL: /gd/v2/user/list/administrator
2. METHOD: POST
3. request body:

```json
{
            "role_id": "ad822b337d884cbb9b84f61a39aff904",
            "org_id": "5aa0028069314b469d69bd5b586dd0a9"
        }
```

4. response data:

```json
{
    "rst": "ok",
    "data": {
    "users_info": [{
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "user_id": "881347b05ed4411fba95b8caac275a03",
            "org_name": "test11",
            "org_id": "5aa0028069314b469d69bd5b586dd0a9",
            "phone": "15691880736",
            "email": "123456789@qq.com",
            "username": "zhangxiaofeng",
            "realname": "zhangxiaofeng7891",
            "comments": "",
            "domain_id": "default"
      }]
    }
}
```



### 查询用户分配角色

注：需要token认证

1. URL: /gd/v2/user/roles/assigned?user_id=1fdb4b36fce247feaccd701b08b401f6
2. METHOD: GET
3. request params:
user_id
4. response data:

```json
{
    "rst": "ok",
    "data":{
			"ucmp": {
				"id": "1278945210e1458290cdde9417e0d7d1",
				"name": "atowflow\\u7ba1\\u7406\\u5458",
				"role_ctl": "{}",
				"role_data": "ucmp_root",
				"comments": ""
			},
			"cmdb": {
				"id": "76b8508b61a34855a736d8f785f112e8",
				"name": "\\u79df\\u6237\\u7ba1\\u7406\\u5458",
				"role_ctl": "{}",
				"role_data": "cmdb_root",
				"comments": ""
			}
		}
}
```



### 获取角色勾选菜单接口

> 需要token信息，登录成功后调用 

**请求URL：**

- `URL: /gd/v2/sys/role/menus`

**请求方式：**

- GET

**请求参数**
role_id
**返回参数示例**

```json
{
    "rst": "ok",
    "data": [
        {
            "id": "aa562131-7545-4350-bc46-67c6ab6ea042",
            "title": "云厂商容量概况",
            "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
            "url": "resource_overview",
            "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
            "icon": "ucmp-icon-sys_menu-statistic-analysis",
            "sortby": 360
        },
        {
            "id": "673e57e2-b43e-47c3-9150-a519d1b30ac8",
            "title": "云厂商资源概况",
            "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
            "url": "provider_resource",
            "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
            "icon": "ucmp-icon-capacity-mgmt",
            "sortby": 359
        },
        ... ...
	]
}    
```



### 查询角色详情

注：需要token认证

1. URL: /gd/v2/user/roles/detail?role_id=1278945210e1458290cdde9417e0d7d12
2. METHOD: GET
3. request params:
role_id
4. response data:

```json
{
        "rst": "ok",
        "data":{
                    "id": "485abaa031dd42f291d167cf723a904e",
                    "name": "平台管理员",
                    "role_data": "ucmp_root",
                    "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                                  "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                  "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                    "platform_name": "ucmp",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "comments": ""
                }
     }
```

### 查询可选的角色列表

注：需要token认证

1. URL: /gd/v2/user/roles/allow/lists?project_id=1278945210e1458290cdde9417e0d7d12
2. METHOD: GET
3. request params:
project_id
4. response data:

```json
{
    "rst": "ok",
    "data": {
    "roles": [{
        "id": "0ee3059a68a44aaea809b1aac5e57c5b",
        "name": "云主机管理员",
        "role_data": "ucmp_admin",
        "role_ctl": {},
        "platform_name": "ucmp",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "comments": ""
    }]
    }
}
```

### 通过角色id查询用户详情
**请求URL：**

- `URL: /gd/v2/user/roles/listuser`

**请求方式：**

- GET

**参数**
必选
role_id  # 角色id

**返回参数示例**
```json
 {
    "rst": "ok", 
    "data": [{
        "id": "1fdb4b36fce247feaccd701b08b401f6", 
        "name": "xiaokai", 
        "realname": "xiaokai123", 
        "default_project_id": "0eb082df17d44c8abf46414d8a1397f8", 
        "tel": "15691880739", 
        "email": "383656225@qq.com", 
        "enabled": 1, 
        "comments": "", 
        "domain_id": "default", 
        "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a", 
        "org_array": "[]", 
        "user_code": "", 
        "org_name": "test2"
        }]
    }
```

### 校验角色是否存在

注：需要token认证

1. URL: gd/v2/user/roles/check?role_name=da
2. METHOD: GET
3. request params:
role_name
4. response data:
角色不存在
```json
{"rst": "ok", "data": {}}     
```
角色存在
```json
{"rst": "ok", "data": {"role_id": "7bd5e93f612b450ca5918bb167282e1b"}}     
```


### 查询角色列表

注：需要token认证

1. URL: /gd/v2/user/roles/lists?page=2&limit=3
2. METHOD: GET
3. request params:
必填:projcet_id 可选: name,limit,page
4. response data:

```json
{
         "rst": "ok",
         "data": { "roles":
                        [{"id": "1278945210e1458290cdde9417e0d7d1",
                        "name": "atowflow\\u7ba1\\u7406\\u5458",
                        "role_data": "ucmp_root",
                        "role_data_name": "超级管理员",
                        "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                                    "ECS": {"vm": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                    "Nas": {"app": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                        "platform_name": "ucmp",
                        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                        "comments": ""}],
                  "page": 2,
                  "page_count": 4,
                  "total": 4
                }
        }
```



### 查询默认角色种类接口

注：需要token认证

1. URL: /gd/v2/user/roles/kinds
2. METHOD: GET
3. request params:
platform:cmdb/ucmp/atomflow/system 
4. response data:

```json
# 权限不足 只有具备ucmp_root或有ucmp_admin可以创建角色
{
    "rst": "ok",
    "data": {
        "code": 0
    }
}

# 具备 ucmp_root
{
    "rst": "ok",
    "data": {
        "ucmp_root": "超级管理员",
        "ucmp_admin": "租户管理员",
        "ucmp_dept": "部门管理员",
        "ucmp_user": "管理员",
        "ucmp_app": "应用管理员",
        "ucmp_business": "业务管理员"
    }
}

# 没有 ucmp_root, 有ucmp_admin
{
    "rst": "ok",
    "data": {
        "ucmp_admin": "租户管理员",
        "ucmp_dept": "部门管理员",
        "ucmp_user": "管理员",
        "ucmp_app": "应用管理员",
        "ucmp_business": "业务管理员"
    }
}
```



## 租户 Project

### 创建租户

注：需要token认证

1. URL: /gd/v2/user/project/create
2. METHOD: POST
3. request body:

```json
{
        "name" : "my project",
        "description" : "This is test project"
    }
```

4. response data:

```json
{
    "rst": "ok",
    "data": {}
}
```



### 租户修改 禁用启用接口

注：需要token认证

1. URL: /gd/v2/user/project/update
2. METHOD: POST
3. request body:

```json
{
    "project_id": "c5143669f6ac4db6b47c3f703ca2e82a",
    "name" : "my project",
    "description" : "This is test project",
    "enabled": true
}
# "enabled": true   启用
# "enabled": false  禁用 
```

4. response data:

```json
{
    "rst": "ok",
    "data": {
        "project_id": "bec6dbf79a71404290eb82be34a92efc"
    }
}
```



### 租户列表

注：需要token认证

1. URL: /gd/v2/user/project/lists
2. METHOD: GET
3. request body:
4. response data:

```json
{
    "rst": "ok",
    "data": [
        {
            "id": "0eb082df17d44c8abf46414d8a1397f8",
            "domain_id": "default",
            "name": "admin",
            "description": "前提",
            "enabled": true
        },
        {
            "id": "bec6dbf79a71404290eb82be34a92efc",
            "domain_id": "default",
            "name": "hello_world",
            "description": "qieuiqeuoifaffafaf",
            "enabled": false
        }
    ]
}
```


### 用户列表(GO)
API for go

注：需要token认证

1. URL: /gd/v2/user/inside/lists
2. METHOD: POST
3. request body:

```json
{
      "user_ids":["200876f2479f4566b1364badc5ed4c1d","c38a4fd167144400b8a3cfd0f5e6ea73"]
    }
```

4. response data:

```json
{
               "rst": "ok",
               "data": {
                       "user_infos": [{
                                      "id": "89f71e87c85a45fdb9cb3c0f4a818073",
                                      "name": "t_3",
                                      "realname": "dwlal1",
                                      "org_id": "c2d3ec86-84b6-4b02-9e5e-df5c573976d3"
                                       },
                                      {
                                      "id": "87cb4da3919a47688d6a0669ea366fed",
                                      "name": "admin",
                                      "realname": "管理员",
                                      "org_id": "7249332a-f7fc-4a84-9a00-77008713f92e"
                                     }]
                        }
             }
```


### 用户列表

注：需要token认证

1. URL: /gd/v2/user/lists?limit=20&page_idx=1&org_name=test199
2. METHOD: GET
3. request params:
可选:limit,page_idx,org_name,name,user_id,user_ids,email,tel,phone,org_id,org_name,org_array,domain_id,enable,user_code
4. response data:

```json
{
	"rst": "ok",
	"data": {
		"users": [{
			"id": "6bf790530de0427bb176ca06e2f197ee",
			"name": "taikang7",
			"realname": "chenxu.ba",
			"default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
			"tel": "15691880739",
			"phone": "15691880739",
			"email": "383656225@qq.com",
			"enabled": 1,
			"comments": "",
			"domain_id": "default",
			"org_id": "ec6f498747c04f6c8e0fdbb1ef220595",
			"org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3",
			"e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"],
			"user_code": null,
			"org_name": "test12"
		},
		{
			"id": "87cb4da3919a47688d6a0669ea366fed",
			"name": "admin",
			"realname": "管理员",
			"default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
			"tel": null,
			"phone": null,
			"email": "sd@leaptocloud.com",
			"enabled": 1,
			"comments": null,
			"domain_id": "default",
			"org_id": "ec6f498747c04f6c8e0fdbb1ef220595",
			"org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3",
			"e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"],
			"user_code": "123456",
			"org_name": "test13"
		}],
		"page": 1,
		"page_count": 1,
		"total": 2
	}
}
```



## 组织机构 Org

### 新建组织机构接口

**请求URL：**

- `URL: /gd/v2/user/org/create`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "org_name":"新加3",
    "parent_id":"fcbc045b-6a70-4815-b256-b2d5249f94a9"
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id": "66749960e6fb4585bf8b2dcf705ea199"
    }
}
```



### 修改组织机构名称接口

**请求URL：**

- `URL: /gd/v2/user/org/update`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id":"efcbc045-6a70-4815-b256-b2d5249f94af",
    "org_name":"新加3"
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id": "efcbc045-6a70-4815-b256-b2d5249f94af"
    }
}
```





### 删除组织机构接口

**请求URL：**

- `URL: /gd/v2/user/org/del`

**请求方式：**

- DELETE

**参数**

- json

**提交参数示例**

```json
{
    "id":"cf17c2ab83444379b987a2aba1162857",
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "ids": ["efcbc045-6a70-4815-b256-b2d5249f94af"]
    }
}
```





### 查询子组织机构ID接口

**请求URL：**

- `URL: /gd/v2/user/sub_org`

**请求方式：**

- GET

**参数**

```
/user/sub_orgs?id=3f71e2c77ef74254a224099b59320651
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "sub_ids": [
            "3f71e2c77ef74254a224099b59320651",
            "72941e4520b54c96938c14781df90ec5",
            "e2f8cb45dc1b43cfaa7c3234971e3e1a"
        ]
    }
}
```



### 查询父级组织机构ID接口(含自身)

> API for Java  
>
>  返回的org_id 包含自己，同时从叶子到根节点排序
> 

**请求URL：**

- `URL: /gd/v2/user/parent_orgs`

**请求方式：**

- GET

**参数**

```
/gd/v2/user/parent_orgs?id=
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "parent_ids": [
            "c534dbc6d2744420938c8b4e1753716c",
            "164349b76ce449229d52d953282f4f30",
            "571ab95c37174d20a00ff5d2840993b0",
            "16f0d23ba70b47788e43299c0b8cfae4",
            "ec6f498747c04f6c8e0fdbb1ef220595"
        ]
    }
}
```



### 获取某组织机构code接口

API for JAVA

**请求URL：**

- `URL: /gd/v2/user/org_code`

**请求方式：**

- GET

**参数**

```
/user/org_code?user_id=3f71e2c77ef74254a224099b59320651
```

**返回参数示例**

```json
# 根节点组织机构
{
    "rst": "ok",
    "data": "1"
}

# 非根节点组织机构
{
    "rst": "ok",
    "data": "1-5-12"
}

# user_id 不存在
{
    "rst": "ok",
    "data": ""
}
```







### 查询某组织机构的子集接口

> 通过id查询该足足的下一级组织机构， 不传id或id为空，返回根组织机构

**请求URL：**

- `URL: /gd/v2/user/orgs`

**请求方式：**

- GET

**参数**

```
id           组织机构id
project_id   租户id
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "orgs": [
            {
                "id": "72941e4520b54c96938c14781df90ec5",
                "parent_id": "e2f8cb45dc1b43cfaa7c3234971e3e1a",
                "org_name": "新加711",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "domain_id": "",
                "object_uid": "",
                "dn": "",
                "mgr_user_id": [],
                "node_id": 8,
                "parent_code": "2-5-6"
            }
        ],
        "total": 1
    }
}
```





### 批量查询组织机构接口

API for Go & Java

**请求URL：**

- `URL: /gd/v2/user/orgs/info`

**请求方式：**

- GET

**参数**

```
/gd/v2/user/orgs/info?ids=1234,abcd&limit=&page=
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "orgs": [
            {
                "id": "1df47706b7644344bb3b5eb33518a79b",
                "parent_id": "7a2c3521e9064be0a6b1e4c30b48c3e2",
                "org_name": "dd",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "domain_id": "default",
                "object_uid": "",
                "dn": "",
                "mgr_user_id": [],
                "node_id": 2145,
                "parent_code": "1-2144"
            }
        ],
        "total": 2129
    }
}
```





### 同步组织机构接口

**请求URL：**

- `URL: /gd/v2/sys/sync/org`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "base_dn":"OU=西安测试中心,DC=leaptocloud,DC=com"
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "sync_status": 2
    }
}
# sync_status 0 同步失败
# sync_status 1 同步成功
# sync_status 2 同步中
```



### 检查此节点的组织机构存在接口

**请求URL：**

- `URL: /gd/v2/user/orgname/check`

**请求方式：**

- GET

**参数**

- json

**提交参数示例**
必填:org_name,project_id
选填:parent_org_id
**返回参数示例**

```json
# 不存在：返回 "code": 0
{
    "rst": "ok",
    "data": {
        "code": 0
    }
}
# 存在：  "code": 1
{
    "rst": "ok",
    "data": {
         "code": 1
    }
}
```





### 模糊查询组织机构接口

> 通过组织名称或组织id获取组织机构信息

**请求URL：**

- `URL: /gd/v2/user/org/query`

**请求方式：**

- GET

**参数**

- json

**提交参数示例**

```json
org_name 和 org_id 不能同时传递到后端。若同时传递，按照org_name进行筛选
必填:org_name或org_id,project_id
```
**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "org_info": [
            {
                "id": "ec6f498747c04f6c8e0fdbb1ef220595",
                "parent_id": "",
                "org_name": "test1",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "domain_id": "default",
                "object_uid": "",
                "dn": "",
                "mgr_user_id": [],
                "node_id": 1,
                "parent_code": "",
                "sub_orgs": [
                    {
                        "id": "d481bf344fee4142aee933dd7e32b9d5",
                        "parent_id": "ec6f498747c04f6c8e0fdbb1ef220595",
                        "org_name": "test12",
                        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                        "domain_id": "default",
                        "object_uid": "",
                        "dn": "",
                        "mgr_user_id": [],
                        "node_id": 5,
                        "parent_code": "1",
                        "sub_orgs": []
                    }
                ]
            }
        ]
    }
}
```



### 获取组织机构下业务接口

> 企业通用云管理平台 》 运营管理 》 流程定义 》 添加配置

**请求URL：**

- `URL: /gd/v2/user/org/business`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "rst": "ok",
    "data": [{
        "id": "000000000000CCE7AED4",
        "parent_id": "",
        "org_name": "西部机场集团",
        "sub_orgs": [{
            "id": "wE44RYLfS2uoQNJdwAK7X8znrtQ=",
            "parent_id": "000000000000CCE7AED4",
            "org_name": "控参股公司",
            "sub_orgs": [],
        	"business":[]},
		... ...                     
                    ],
		"business": [{
			"business_id": "0d7ca344ecfc4763bf3f1d18486db5f4",
			"business_name": "twa"}]              
    }]
}
```








## 模块 Module

### 获取Module接口(旧版中APP)

> 需要token信息

**请求URL：**

- `URL: /gd/v2/sys/modules`

**请求方式：**

- GET

**提交参数**

**返回参数示例**

```json
{
    "rst": "ok",
    "data": [
        {
            "id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
            "module_name": "企业通用云管理平台",
            "description": null,
            "module_url": "ucmp",
            "sortby": 0,
            "remote_url": null
        },
        {
            "id": "960a89cc-044f-4233-ad7e-50c14a290071",
            "module_name": "主动式配置管理数据库平台",
            "description": null,
            "module_url": "cmdb",
            "sortby": 7,
            "remote_url": null
        }
    ]
}
```



## 菜单 Menu

### 获取系统全部菜单接口

> 需要token信息

**请求URL：**

- `URL: /gd/v2/sys/menus`

**请求方式：**

- GET
**提交参数**

必填:platform

**返回参数示例**

```json
{
    "rst": "ok",
    "data": [
        {
            "id": "a7a053ba-2473-49be-8e94-9826a24b484b",
            "title": "总览",
            "parent_id": null,
            "url": "dashboard",
            "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
            "icon": "ucmp-icon-sys_menu-dashboard",
            "sortby": 350,
            "subMenus": [
                {
                    "id": "aa562131-7545-4350-bc46-67c6ab6ea042",
                    "title": "云厂商容量概况",
                    "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                    "url": "resource_overview",
                    "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                    "icon": "ucmp-icon-sys_menu-statistic-analysis",
                    "sortby": 360
                }
            ]
        }
    ]
}
```











### 获取用户菜单接口

> 需要token信息，登录成功后调用 

**请求URL：**

- `URL: /gd/v2/sys/user/menus`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "rst": "ok",
    "data": [
        {
            "id": "a7a053ba-2473-49be-8e94-9826a24b484b",
            "title": "总览",
            "parent_id": null,
            "url": "dashboard",
            "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
            "icon": "ucmp-icon-sys_menu-dashboard",
            "sortby": 350,
            "subMenus": [
                {
                    "id": "aa562131-7545-4350-bc46-67c6ab6ea042",
                    "title": "云厂商容量概况",
                    "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                    "url": "resource_overview",
                    "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                    "icon": "ucmp-icon-sys_menu-statistic-analysis",
                    "sortby": 360
                }
            ]
        }
    ]
}
```





## 业务 Business

### 检查业务是否同名接口

**请求URL：**

- `URL: /gd/v2/business/chk/name`

**请求方式：**

- GET

**参数**


必填:name


**返回参数示例**

```json
# 不存在
{
    'rst': 'ok', 
    'data': {}
}

# 存在
{
    'rst': 'ok', 
    'data': {
        "id": "",
        "name": "",
        "description": "",
        "project_id": "",
        "org_id": "",
        "org_array": "",
        "sortby": 0,
        "enable":1   # 只返回0, 1
    }
}
```



### 新建/更新业务接口

**请求URL：**

- `URL: /gd/v2/business/save`

**请求方式：**

- POST

**提交参数示例**

```json
{
    "id": "",  # 有id默认进行更新， 无id字段创建
    "name": "test123",
    "description": "test123",
    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "org_id": "",
    "org_array": [],
    "sortby": 0,
    "enable": 1  # 只接受 0， 1
}
```

**返回参数示例**

```json
{
    "rst": "ok", 
    "data": {
        "id": "dbdf7fbd-att1-4d34-9ba5-2d3779c11b21"
    }
}
```



### 删除业务接口

**请求URL：**

- `URL: /gd/v2/business/del`

**请求方式：**

- DELETE

**参数**

```json
{"id": "f715c4a59d7d4afea69434117d318853"}
```

**返回参数示例**

```json
# 报错1： 该业务下有应用
# 报错2： 该业务不存在

# 删除成功
{
    "rst": "ok", 
    "data": {
        "id": "f715c4a59d7d4afea69434117d318853"
    }
}
```



### 获取业务接口

**请求URL：**

- `URL: /gd/v2/business/list`

**请求方式：**

- GET

**参数**

可选参数:
limit
page
name  # 业务名称 模糊匹配
org_id  # 组织机构ID

**返回参数示例**

```json
{
    "rst": "ok", 
    "data": {
        "business": [{
            "id": "7b7e25ecf1c3452b8e637870c8539719",
            "name": "test", 
            "description": "tttt", 
            "project_id": "0eb082df17d44c8abf46414d8a1397f8", 
            "org_id": "7249332a-f7fc-4a84-9a00-77008713f92e", 
            "org_name": "测试组织机构A", 
            "org_array": ["7249332a-f7fc-4a84-9a00-77008713f92e"], 
            "sortby": 0, 
            "enable": 1
        }], 
        "page": 1, 
        "page_count": 1, 
        "total": 1
    }
}
```


### 根据应用id获取业务接口

**请求URL：**

- `URL: /gd/v2/business/app/businessinfo`

**请求方式：**

- GET

**参数**

必选:app_id  # 应用ID


**返回参数示例**

```json
{
               "rst": "ok", 
               "data": {
                       "business_id": "200014150bfc40b89c34d3f2723afb93", 
                       "business_name": "dwa1"
                       }
            }
```


### 根据根据组织机构id获取业务接口

**请求URL：**

- `URL: /gd/v2/business/org/businessinfo`

**请求方式：**

- GET

**参数**

必选: org_id  # 组织机构ID


**返回参数示例**

```json
{
	"rst": "ok",
	"data": {
		"business": [{
			"id": "7fa4950e010a4b31bb7af1eb1d3ed070",
			"name": "dwa"
		},
		{
			"id": "200014150bfc40b89c34d3f2723afb93",
			"name": "dwa1"
		}],
		"page": 1,
		"page_count": 1,
		"total": 2
	}
}
```





## 应用 BusinessApp

### 检查业务是否同名接口

**请求URL：**

- `URL: /gd/v2/business/apps/chk/name`

**请求方式：**

- GET

**参数**

必选: name


**返回参数示例**

```json
# 不存在
{
    'rst': 'ok', 
    'data': {}
}

# 存在
{
    'rst': 'ok', 
    'data': {
        'id': '18a35736ec24495aa880d17448e5f868', 
        'business_app_name': 'ttt', 
        'shorter_name': 'ttt', 
        'description': 'dwadw', 
        'project_id': '0eb082df17d44c8abf46414d8a1397f8', 
        'business_id': '7b7e25ecf1c3452b8e637870c8539719', 
        'enable': 1
    }
}
```



### 新建/更新应用接口

**请求URL：**

- `URL: /gd/v2/business/apps/save`

**请求方式：**

- POST

**提交参数示例**

```json
{
    "id": "",  # 有id默认进行更新， 无id字段创建
    "business_app_name": "",
    "shorter_name": "",
    "description": "",
    "business_id": "",
    "project_id": 0,
    "enable": 1  # 只接受 0， 1
}
```

**返回参数示例**

```json
{
    "rst": "ok", 
    "data": {
        "id": "dbdf7fbd-att1-4d34-9ba5-2d3779c11b21"
    }
}
```



### 删除应用接口

**请求URL：**

- `URL: /gd/v2/business/apps/del`

**请求方式：**

- DELETE

**参数**

```json
{"id": 'f715c4a59d7d4afea69434117d318853'}
```

**返回参数示例**

```json
# 报错1： 该业务下有应用
# 报错2： 该业务不存在

# 删除成功
{
    'rst': 'ok', 
    'data': {
        'id': 'f715c4a59d7d4afea69434117d318853'
    }
}
```


### 获取应用接口

**请求URL：**

- `URL: /gd/v2/business/apps/list`

**请求方式：**

- GET

**参数**
选填:
limit
page
app_ids  # 应用ID字符串，用,隔开
name  # 应用名称/简称  模糊匹配
business_id  # 应用ID

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {
        'apps': [
            {'app_name': 'ttt2', 
             'description': 'ttt', 
             'id': '66009391c17549d3a85b32c57b12c2c6', 
             'business_id': '7b7e25ecf1c3452b8e637870c8539719', 
             'short': 'ttt2', 
             'enable': 1}
        ], 
        'page': 1, 
        'page_count': 1, 
        'total': 1
    }
}
```



### 获取应用全称相似度接口

> token 

**请求URL：**

- `URL: /gd/v2/business/app/name/similar`

**请求方式：**

- GET

**参数**
```json
name  # 应用名称全称
similar  # 相似度比例 0-1 float
```

**返回参数示例**

```json
# 只返回相似度大于0.1的数据
{
    "rst": "ok",
    "data": [
        {
            "id": "6c91140d6cc4448daf388262ff9a5933",
            "business_app_name": "t1",
            "shorter_name": "t1",
            "similar": 1
        }
    ]
}
```







### 修改授权：应用对应的组织机构接口

> 返回组织机构的node_id数组

**请求URL：**

- `URL: /gd/v2/business/app/org`

**请求方式：**

- PUT

**参数**

```json
{
    "app_id": "1",
    "org_ids": ["571ab95c37174d20a00ff5d2840993b0"]
}
```

**返回参数示例**

```json
{
    "rst": "ok", 
    "data": {}
}
```
###查询：应用对应的组织机构接口


**请求URL：**

- URL: /gd/v2/business/app/org

**请求方式：**

- GET

参数
```json
    
    "app_id": "0d7ca344ecfc4763bf3f1d18486db5f4"
    
```
**返回参数示例**
```json
    {
        "rst": "ok", 
        "data": "['ER4AAAAC8bvM567U']"
    }
```




### 增量授权：应用对应的组织机构接口

> 返回组织机构的node_id数组

**请求URL：**

- `URL: /gd/v2/business/apps/orgs`

**请求方式：**

- POST

**参数**

```json
{
    "app_ids": ["facd2c8475e543c1b7f705e2ff056cfe"],
    "org_ids": ["571ab95c37174d20a00ff5d2840993b0"]
}
```

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {}
}
```

### 通过业务id查询业务详情
**请求URL：**

- `URL: /gd/v2/business/businessinfo`

**请求方式：**

- GET

**参数**
必选
business_id  # 业务id

**返回参数示例**
```json
{
    "rst": "ok", 
    "data": {
          "business_id": "347d80f4115f4dee9a4b816490e5a26f", 
          "business_name": "test1234", 
          "description": "tttt", 
          "project_id": "0eb082df17d44c8abf46414d8a1397f8", 
          "org_id": "7249332a-f7fc-4a84-9a00-77008713f92e"
          }
}
```


### 获取组织机构树(应用授权组织机构)接口

**请求URL：**

- `URL: /gd/v2/user/orgtree`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "rst": "ok",
    "data": [{
        "id": "000000000000CCE7AED4",
        "parent_id": "",
        "org_name": "西部机场集团",
        "sub_orgs": [{
            "id": "wE44RYLfS2uoQNJdwAK7X8znrtQ=",
            "parent_id": "000000000000CCE7AED4",
            "org_name": "控参股公司",
            "sub_orgs": []},
		... ...                     
                    ]
    }]
}
```



## 系统设置 System Config

### 上传LOGO接口(常规配置)

**请求URL：**

- `URL: /gd/v2/sys/file`

**请求方式：**

- POST

**参数**

```python
Form Data
file:(binary)
```

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {
        'name': '89eb5337a17d49098951a9b09e6a7e83.png', 
        'url': '/gd_static/89eb5337a17d49098951a9b09e6a7e83.png',  # logo static url
    }
}
```



### 获取LOGO接口(常规配置)

**请求URL：**

- `URL: /gd/v2/sys/logo/<img_name>`

**请求方式：**

- GET

**参数**

```python
# 示例
http://192.168.3.127:9090/gd/v2/sys/logo/49a74bb173e64f97a0860c35d4c2caa2.png
```



### 更新常规配置接口

**请求URL：**

- `URL: /gd/v2/sys/conf/save`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "copyright": "Copyright©2018",
    "log_delete_time": "10",
    "session_expire": 30,
    "surport_mail": "support@domain.com",
    "surport_tel": "400-000-0000",
    "sys_logo": "/gd_static/89eb5337a17d49098951a9b09e6a7e83.png",  # logo static url
    "sys_name": "IT运营管理中",
    "version": "V3.0",
    "case_sensitive": 1,  # 只接收 0 不区分， 1 区分
    "license_expire": 10
}
```

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {
        'id': 'dbdf7fbd-att1-4d34-9ba5-2d3779c11b21', 
        'copyright': 'Copyright©2018', 
        'log_delete_time': '10', 
        'session_expire': 30, 
        'surport_mail': 'support@domain.com', 
        'surport_tel': '400-000-0000', 
        'sys_logo': '/gd_static/89eb5337a17d49098951a9b09e6a7e83.png',  # logo static url
        'sys_name': 'IT运营管理中', 
        'version': 'V3.0', 
        'case_sensitive': 1,  # 只返回 0 区分， 1 不区分
        'license_expire': 10
    }
}
```



### 获取常规配置接口 

**请求URL：**

- `URL: /gd/v2/sys/conf`

**请求方式：**

- GET

**返回参数示例**

```json
# 不存在
{
    'rst': 'ok', 
    'data': {}
}

# 存在
{
    'rst': 'ok', 
    'data': {
        'id': 'dbdf7fbd-att1-4d34-9ba5-2d3779c11b21', 
        'sys_logo': '/gd_static/49a74bb173e64f97a0860c35d4c2caa2.png', 
        'sys_name': 'IT运营管理中枢', 
        'version': 'V3.0', 
        'copyright': 'Copyright © 2018', 
        'surport_mail': 'support@domain.com', 
        'surport_tel': '400-000-0000', 
        'log_delete_time': '7', 
        'session_expire': 30, 
        'case_sensitive': 1, 
        'license_expire': 7, 
        'project_id': '0eb082df17d44c8abf46414d8a1397f8'
    }
}
```



## 



### 新建/更新认证配置接口

**请求URL：**

- `URL: /gd/v2/sys/ldap`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id": "",
    "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
    "server_addr": "192.168.3.116",
    "server_port": 389,
    "is_ssl": 0,
    "user_name": "Administrator@leaptocloud.com",
    "user_pass": "1qaz@WSX",
    "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com",
    "is_update": 0  # 0 不更新 1 更新
}
```

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {
        'id': 'b35d11509cf841bfb897f8b9d2e67cb5'
    }
}
```





### 获取认证配置接口

**请求URL：**

- `URL: /gd/v2/sys/ldap`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "id": "",
    "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
    "server_addr": "192.168.3.116",
    "server_port": 389,
    "is_ssl": 0,
    "user_name": "Administrator@leaptocloud.com",
    "user_pass": "1qaz@WSX",
    "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
}
```



### 测试认证配置接口

**请求URL：**

- `URL: /gd/v2/sys/ldap/test`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id": "",
    "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
    "server_addr": "192.168.3.116",
    "server_port": 389,
    "is_ssl": 0,
    "user_name": "Administrator@leaptocloud.com",
    "user_pass": "1qaz@WSX",
    "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "code": 0
    }
}
# 连接失败  code：0
# 连接成功  code：1
```



### 更新授权码接口

**请求URL：**

- `URL: /gd/v2/sys/license`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
files: file 
 'file': ('1550565606.lic', open('/home/peter/Desktop/1550565606.lic', 'rb'))
{
    "module_id": ""
}
```

**返回参数示例**

```json
{
    'rst': 'ok', 
    'data': {
        'version': '普通版', 
        'authObject': 'test', 
        'status': 'invalid', 
        'authItem': [
            {'type': '物理机CPU核数', 'status': 'active', 'total': '100000', 'left': '99908', 'unit': '核', 'message': ''}, 
            {'type': '有效截止日期', 'status': 'invalid', 'total': '2019-01-27', 'left': '0', 'unit': '天', 'message': '已过期'}
        ]
    }
}
```



### 获取授权接口

**请求URL：**

- `URL: /gd/v2/sys/license`

**请求方式：**

- GET

**参数**

```json
module_id
```



**返回参数示例**

```json
# 不存在
{
    'rst': 'ok', 
    'data': {}
}

# 存在
{
    'rst': 'ok', 
    'data': {
        'version': '普通版', 
        'authObject': 'test', 
        'status': 'invalid', 
        'authItem': [
            {
                'type': '物理机CPU核数',
                'status': 'active', 
                'total': '100000', 
                'left': '99908', 
                'unit': '核', 
                'message': ''
            }, 
            {
                'type': '有效截止日期', 
                'status': 'invalid', 
                'total': '2019-01-27', 
                'left': '0', 
                'unit': '天', 
                'message': '已过期'
            }
        ]
    }
}
```






## 消息中心 Message

### 新建/修改消息策略接口

**请求URL：**

- `URL: /gd/v2/msgs/strategy`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
[
    {
        "id": "70deda9b77364e11acc63ba6bcca19db",  # id为空新建, 不为空更新
        "strategy_app_id": "ucmp/iaas_apply/success",  # value 拼接  for Go & Java
        "strategy_app_name": "服务申请/成功",
        "title": "test1",
        "strategy_period_type": 1,
        "strategy_period_type_name": "单次",
        "accept_role_list": ["applicant", "fc37e6af5a284b01b67be6b4593f0fdf"],
        "accept_user_list": ["user_id_uuid_1", "user_id_uuid_2"],
        "send_ahead_date": 0,
        "support_message_types": [0, 1],  # 0 邮件, 1 短信, 2 站内消息
        "select_template_ids": [],
        "select_strategy_app_id": ""  # uuid  for web
    }
]
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```





### 启用/禁用消息策略接口

**请求URL：**

- `URL: /gd/v2/msgs/strategy/enable`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
   "id": "59657812ee79457da5fdb2502f0bc08b",
   "is_on":0
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id":"5b13bdc0808748648c566d384513c9cb"
    }
}
```





### 删除消息策略接口

**请求URL：**

- `URL: /gd/v2/msgs/strategy/del`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id": "59657812ee79457da5fdb2502f0bc08b"
}
```



**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id":"5b13bdc0808748648c566d384513c9cb"
    }
}
```








### 获取消息策略接口

**请求URL：**

- `URL: /gd/v2/msgs/strategy/list`

**请求方式：**

- GET

**参数**

```json
app_id  # strategy_app_id
is_on   # 非必填；取值范围：[ 不填-获取全部, 1-启用, 0-禁用 ]
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "strategy_list": [
            {
                "id": "fdad37829441404cbaa337de6f800e05",
                "strategy_app_id": "ucmp/monitor",
                "strategy_app_name": "监控告警",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "title": "告警消息测试2",
                "strategy_period_type": 1,
                "strategy_period_type_name": "单次",
                "send_ahead_date": 0,
                'support_message_type_ids': [1, 0],   # 0 邮件 1 短信 2 站内信
                'support_message_type_names': ['短信', '邮件'],   # 消息类型名称
                "select_template_ids": [
                    "ooge1213dd-0dkk-42b7-8abf-2df78pp69c"
                ],
                "accept_role_list": [
                    {
                        "id": "ucmp_admin",
                        "lable": "租户管理员"
                    },
                    {
                        "id": "ucmp_dept",
                        "lable": "部门管理员"
                    }
                ],
                "accept_user_list": [],
                "select_strategy_app_id": "c67199103bf74ff096e2cd84cff618d7",
                "is_on": 1,
                "create_at": 1552550859,
                "update_at": 1552556122,
                "select_message_type_list": [
                  {
                      "id": "",
                      "type": "",
                      "lable": "",
                      "variable": {},
                  }
                ]
            }
        ],
        "page": 1,
        "page_count": 1,
        "total": 1
    }
}
# 更多接收人 调用接口：/gd/v2/user/lists
参数：user_id_list 数组  使用返回的accept_user_list字段
```



### 异步发送策略消息接口

> 需要token
>
> API for Java & Go

**请求URL：**

- `URL: /gd/v2/msgs/send`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
# notice_type_id  涉及站内信必须要传
# message_type  不传 按照策略中配置的发送； 传 只发传的类型，如 邮件，短信， 站内消息
{
	"to_user": [
        "87cb4da3919a47688d6a0669ea366fed",  # 申请人
        "53a882c0f1384393ae651a48dc73b791"   # 责任人
    ],
    "source_info": {
        "org_id": "xxx"  # 部门管理员时需要传
    },
    "strategy_id": "87cb4da3919a47688d6a0669ea366fed",
    "notice_type_id": 1,  # 站内消息类型
    "message_type": 1,  # 发送信息的类型，邮件、短信、站内消息
    "level": 1,
    "variable": [
    	{"key": "username", "value": "用户名"},
		{"key": "action", "value": "行为，如申请等"},
        {"key": "app", "value": "业务"},
        {"key": "machine_name", "value": "name"},
        {"key": "cpu", "value": "CPU"},
        {"key": "memory", "value": "10%"}
    ],
	"force":1
}

# force:1 强制发送消息至to_user内的用户
# force:0 需要过滤并组合所有用户并发送消息

# 通知类型(notice_type_id)：通知（notice:2），故障告警（alarm:3），产品升级维护（maintenance:4），提示 （info:1）
# 信息类型(message_type)：邮件（0），短信（1），站内消息（2） # java
```
**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```


### 异步发送自定义消息接口

> 需要token
>
> API for Java  非模板消息

**请求URL：**

- `URL: /gd/v2/msgs/customize/send`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
	"to_user": ["87cb4da3919a47688d6a0669ea366fed"],
    "source_info": {
        "org_id": "xxx"
    },
    "title": "自定义消息标题",
    "content": "自定义消息内容",
    "notice_type_id": 1,  # 站内消息类型
    "message_type": 1,  # 发送信息的类型，邮件、短信、站内消息
    "level": 1
}

# 通知类型(notice_type_id)：  涉及站内信必须要传
# 		提示 （info:1）,通知（notice:2）,故障告警（alarm:3）,产品升级维护（maintenance:4）
# 信息类型(message_type)：邮件（0）,短信（1）,站内消息（2）
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```



### 获取策略配置接口

> token

**请求URL：**

- `URL: /gd/v2/msgs/strategy/conf`

**请求方式：**

- GET

**返回参数示例**

```json
# value 拼接后存到 strategy_app_id  for Go & Java
# id    拼接后存到 select_strategy_app_id  for Web
{
    'rst': 'ok', 
    'data': [
        {
        'id': 'ucmp/iaas_apply', 
        'value': 'ucmp/iaas_apply', 
        'label': '服务申请', 
        'advancedOptions': True, 
        'acceptRole': [{'id': 'applicant', 'label': '申请人'}, {'id': 'responsible', 'label': '责任人'}, {'id': 'ucmp_admin', 'label': '租户管理员'}, {'id': 'ucmp_dept', 'label': '部门管理员'}], 
        'hasDelayTime': False, 
        'noticeTimes': [{'value': 1, 'label': '单次'}], 
        'period': [], 
        'children': [
            {'id': 'apply_success', 'value': 'success', 'label': '成功', 'parentId': 'iaas_apply', 'tempalte_list': None}, 
            {'id': 'apply_failed', 'value': 'failed', 'label': '失败', 'parentId': 'iaas_apply', 'tempalte_list': None}
        ]}
    ]
}
```



## 模板 Template

### 编辑消息模板接口

**请求URL：**

- `URL: /gd/v2/msgs/template/update`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "strategy_app_id":"statis/idle",
    "template_list":[
        {
            "id":"cdfefd9dd-0d75-g2b7-8abf-2df788839c",
            "title":"模板1",
            "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%}, 网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
        },
        {
            "id":"fd9dd-0d75-g2b7-8abf-2efeofefe",
            "title":"模板",
            "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%}, 网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
        },
        {
            "id":"cdfefd9dd-0d75-g2b7-826839c-fewa",
            "title":"模板2",
            "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%}, 网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
        }
    ]
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```





### 获取消息模板接口

**请求URL：**

- `URL: /gd/v2/msgs/template/list`

**请求方式：**

- GET

**type_id**

|类型 | 0 | 1 | 2 |
| - | - | - | - |
| 说明 | 邮件 | 短信 | 站内消息 |

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "data_list":[{
            "strategy_app_id":"system/service_expire",
            "strategy_app_name":"服务到期",
            "template_list":[
                {
                    "id":"oooz2ad91d-0d75-42b7-8abf-2df78826839c",
                    "strategy_app_id":"system/service_expire",
                    "strategy_app_name":"服务到期",
                    "title":"模板",
                    "content":"用户{%username%}的{%service_name%}服务{%experation_date%}到期，为保证正常使用，请尽快前往处理，如有问题请联系相关负责人",
                    "project_id":"0eb082df17d44c8abf46414d8a1397f8",
                    "type":2,
                    "type_name":"站内消息",
                    "variable":"[{"key":"username", "value":"用户名"}, {"key":"service_name", "value":"服务"}, {"key":"experation_date", "value":"过期时间"}]"
                }
            ]
        }],
    "page": 1}
}

```





## 站内消息 Notice

### 创建站内消息接口

**请求URL：**

- `URL: /gd/v2/msgs/notice`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**
```json
{
    "notice_type": 2,
    "notice_type_name": "通知",
    "title": "test_1",
    "content": "123456"
}
```
**返回参数示例**
```
{
    "rst": "ok",
    "data": {
        "id": "66749960e6fb4585bf8b2dcf705ea199"
    }
}
```



### 获取全部站内消息接口

**请求URL：**

- `URL: /gd/v2/msgs/notice`

**请求方式：**

- `GET`

**参数**

| 参数名 | 必选| 类型| 说明|
| - | -| -| - |
| type | 是 | String | 通知类型 |

通知类型：提示 （1 info），通知（2 notice），故障告警（3 alarm），产品升级维护（4 maintenance）



**提交参数示例**

```
/notice?type=&limit=20&page=1    # 全部
/notice?type=1&limit=20&page=1   # 提示
/notice?type=2&limit=20&page=1   # 通知
/notice?type=3&limit=20&page=1   # 故障告警
/notice?type=4&limit=20&page=1   # 产品升级维护
```
**返回参数示例**
```json
{
    "rst": "ok",
    "data": {
        "notices": [
            {
                "id":"1c2f1e3dec0c4420bfc329a58a780590",
                "project_id":"87cb4da3919a47688d6a0669ea366fed",
                "title":"模板"
                "content":"用户{%username%}的{%service_name%}...",
                "notice_type": 2,
                "notice_type_name":"提示",
                "is_read": 1,
                "create_at":"2019-01-29 09:00:13",
            }
        ],
        "page": 1,
        "page_count": 1,
        "total": 1
    }
}
```



### 获取未读站内消息接口

**请求URL：**

- `URL: /gd/v2/msgs/notice/notread?type=&limit=20&page=1`

**请求方式：**

- `GET`

**返回参数示例**
```json
{
    "rst": "ok",
    "data": {
        "notices": [
            {
                "id": null,
                "notice_id": "df79bc9ed36041e899dcbf16333a6f4f",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "title": "\"\\u6a21\\u677f\"",
                "content": "用户管理员的云主机出现告警，告警来源：192.168.6.7 告警类型:性能，告警级别:提示，请尽快前往进行处理",
                "notice_type": "3",
                "notice_type_name": "故障告警",
                "is_read": null,
                "create_at": 1553503189
            }
        ],
        "page": 1,
        "page_count": 1,
        "total": 1
    }
}
```



### 标记站内消息已读接口

**请求URL：**

- `URL: /gd/v2/msgs/notice/read`

**请求方式：**

- `POST`

**参数**

- `json`

**提交参数示例**
```json
{
    "notice_ids":["c6180536b8a14043b9ba2e28ba17b9ad"]
}
```
**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```



### 删除站内消息接口

**请求URL：**

- `URL: /gd/v2/msgs/notice/del`

**请求方式：**

- `DELETE`

**参数**

- `json`

**提交参数示例**

```json
{
    "notice_ids":["c6180536b8a14043b9ba2e28ba17b9ad"]
}
```
**返回参数示例**
```json
{
    "rst": "ok",
    "data": {}
}
```



## 短信 SMS_Conf

### 新建/更新短信配置接口

**请求URL：**

- `URL: /gd/v2/msgs/sms_conf`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id":"",
    "server_addr":"123",
    "server_port":22,
    "account_id":"12345",
    "account_token":"123",
    "test_phone":"18629876785",
    "extra_params":[
        {
            "key":"test",
            "value":"test"
        }
    ]
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id": "66749960e6fb4585bf8b2dcf705ea199"
    }
}
```



### 获取短信配置接口

**请求URL：**

- `URL: /gd/v2/msgs/sms_conf`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id":"",
        "project_id":"",
        "server_addr":"123",
        "server_port":22,
        "app_id":"12345",
        "account_token":"123",
        "to_phone":"18629876785",
        "extra_params":[
            {
                "key":"test",
                "value":"test"
            }
        ]
    }
}
```



## 邮件 E-Mail Conf

### 新建/更新邮件配置接口

**请求URL：**

- `URL: /gd/v2/msgs/email/conf`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id": "",
    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "server_addr":"smtp.mxhichina.com",
    "server_port":465,
    "is_tls":1,
    "user_name":"云管测试",
    "from_user_addr":"junfeng.li@leaptocloud.com",
    "user_pass":"×××××××",
    "test_to_user_addr":"junfeng.li@leaptocloud.com"
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id": "0eb082df17d44c8abf46414d8a1397f8"
    }
}
```





### 获取邮件配置接口

**请求URL：**

- `URL: /gd/v2/msgs/email`

**请求方式：**

- GET

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "id": "9d8b6b03cd864e7fb613f3ea198373a7",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "server_addr":"smtp.mxhichina.com",
        "server_port":465,
        "is_tls":1,
        "user_name":"云管测试",
        "from_user_addr":"junfeng.li@leaptocloud.com",
        "user_pass":"×××××××",
        "test_to_user_addr":"junfeng.li@leaptocloud.com"
    }
}
```



### 测试邮件发送接口

**请求URL：**

- `URL: /gd/v2/msgs/email/test`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "id": "9d8b6b03cd864e7fb613f3ea198373a7",
    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "server_addr":"smtp.mxhichina.com",
    "server_port":465,
    "is_tls":1,
    "user_name":"云管测试",
    "from_user_addr":"junfeng.li@leaptocloud.com",
    "user_pass":"×××××××",
    "test_to_user_addr":"junfeng.li@leaptocloud.com"
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
        "status": {
            "code": 1,
            "message": "邮件发送成功!"
        }
    }
}
```

### 邮件发送接口

**请求URL：**

- `URL: /gd/v2/msgs/email/send`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
{
    "to_user_addrs": ['cloud@163.com'],
    "sub": "Title",
    "content": "mail content."
}
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```



## Divece Agent

### cmdb平台调用agent执行脚本

**请求URL：**

- `URL: /gd/v2/agent/script/exec`

**请求方式：**

- POST

**参数**

- json

**提交参数示例**

```json
[
            {
                "host_ip": "127.0.0.1",
                "host_name": "host126",
                "agent_version": "1.0",
                "agent_url": "127.0.0.1"
            }
        ]
```

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```

### cmdb同步device agent

**请求URL：**

- `URL: /gd/v2/device/agent/sync`

**请求方式：**

- GET

**参数**

- json

**提交参数示例**


**返回参数示例**

```json
{
    "rst": "ok",
    "data": {}
}
```

### cmdb获取device agent列表

**请求URL：**

- `URL: /gd/v2/device/agent/list`

**请求方式：**

- GET

**参数**

- json

**提交参数示例**
page_idx,limit

**返回参数示例**

```json
{
    "rst": "ok",
    "data": {
            "agents": [{
                "id": "46e4049b-fe16-4e8b-98d2-9c5e80a1d916",
                "host_ip": "192.168.3.141",
                "host_name": "192.168.3.141",
                "ansible_conn_status": false,
                "agent_name": null,
                "agent_version": null,
                "agent_url": null,
                "agent_status": null
            }],
        "page": 1,
        "page_count": 1,
        "total": 1
        }
    }
```
