
from sqlalchemy import Column, DateTime, func
from sqlalchemy.ext.declarative import declarative_base
from guardian.utils.uuid_util import gen_uuid

BaseModel = declarative_base()

N_DEL = 0
DEL = 1

ON = 1
OFF = 0

N_READ = 0
READ = 1

IS_PUBLIC = 1  # 通用模块 SysModuleModel
N_PUBLIC = 0

IS_TLS = 1  # 支持TLS协议
NOT_TLS = 0
EMAIL_SERVER_PORT = 23

IS_SSL = 1  # 支持SSL协议
N_SSL = 0
LDAP_SERVER_PORT = 389

SUCCESS = 1
FAILED = 0
DOING = 2

SYNC_ORG_DOING = 3  # 组织机构正在同步中
SYNC_ORG_FAILED = 4  # 组织机构同步失败
SYNC_NOT_ORG = 5  # 没有同步过组织机构，需要先同步组织机构

SYNC_USER = 'user'
SYNC_ORG = 'org'

# notice_type
INFO = 1
NOTICE = 2
ALARM = 3
MAINTENANCE = 4
MESSAGE_TYPE_DICT = {
    INFO: "提示",
    NOTICE: "通知",
    ALARM: "故障告警",
    MAINTENANCE: "产品升级维护"
}


class CommonModel(object):
    create_at = Column(DateTime, default=func.now(), doc="创建时间")
    update_at = Column(DateTime, default=func.now(), onupdate=func.now(), doc="更新时间")

    def __init__(self, *args, **kwargs):
        pass

    def gen_uuid(self):
        return gen_uuid()
