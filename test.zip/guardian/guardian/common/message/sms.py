
import requests
import urllib.parse
from guardian.log4 import celery_logger as log
from guardian.settings import MSM_TIPS, MSM_TIPS_POSITION


class GuardianSms:
    @classmethod
    def send_sms(cls, username, password, text, phones, send_uri, **kwargs):
        # TODO 需要根据客户现场，定制化开发
        """
        235 云通信短信网关
        :param username:
        :param password:
        :param text:
        :param phones:
        :param send_uri:
        :return:
        """
        if isinstance(phones, str):
            phones_str = phones
        elif isinstance(phones, list):
            phones_str = phones[0]
        else:
            return {"code": 500, "message": "手机号缺失", "error": ""}
        log.info('>>>phone is %s', phones_str)
        if MSM_TIPS_POSITION == "top":
            params = {'account': username, 'password': password, 'msg': MSM_TIPS + urllib.parse.quote(text), 'phone': phones_str,
                      'report': 'false'}
        else:
            params = {'account': username, 'password': password, 'msg': urllib.parse.quote(text) + MSM_TIPS, 'phone': phones_str,
                      'report': 'false'}
        headers = {"Content-type": "application/json"}
        try:
            _resp = requests.post(send_uri, headers=headers, json=params, verify=False)
            if _resp.status_code == requests.codes.ok:
                data = _resp.json()
                log.debug("msg send ok, status: %s, reason: send ok" % _resp.status_code)
                log.debug("########msm data is %s" % data)
                response_code = data.get('code')
                if int(response_code) != 0:
                    return {"code": 500, "message": "短信发送失败",
                            "error": "response code [%s], msgId [%s]" % (str(data.get("code")), str(data.get('msgId')))}
                return {"code": 200, "message": "短信发送成功!"}
            else:
                return {"code": _resp.status_code, "message": "连接失败", "error": "request post error"}
        except Exception as e:
            return {"code": 500, "message": "连接失败", "error": str(e)}



