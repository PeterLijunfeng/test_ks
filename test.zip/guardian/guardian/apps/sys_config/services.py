import re
import json
import time
import requests
import paramiko
from datetime import datetime
from guardian.settings import TERRAFORM_BASE
from guardian.settings import KEYSTONE_BASE
from guardian.settings import KEYSTONE_ROOT_USER
from guardian.settings import KEYSTONE_ROOT_PASS
from guardian.settings import KEYSTONE_PORT
from guardian.settings import LDAP_TIMEOUT
from guardian.settings import KEYSTONE_CONF_HOME
from guardian.settings import LDAP_CONF_FILE
from guardian.common.errors import ApiException
from guardian.common.errors import ParamsException
from guardian.common.ldap_domain.myldap import ldap_conn
from guardian.apps import NOTICE, MESSAGE_TYPE_DICT
from guardian.apps.users.models import get_menu_by_user_id
from guardian.apps.users.models import query_role_join_user
from guardian.apps.sys_config.models import SysModuleModel
from guardian.apps.sys_config.models import SysMenuModel
from guardian.apps.sys_config.models import LicenseModel
from guardian.apps.sys_config.models import SysInfoConfModel
from guardian.utils.dates import string_toDatetime
from guardian.apps.messages.models import InnerNoticeModel


def get_menu_by_role_ids(user_id):
    role_permissions = get_menu_by_user_id(user_id)
    menu_id_list = []
    for role_perm in role_permissions:
        menu_id_list.append(role_perm.menu_id)
    menu_objs = SysMenuModel.get_menu_by_ids(menu_id_list)
    menus = SysMenuModel.get_all()
    all_menu_info_dicts = {}
    root_menu_id_list = []
    for menu in menus:
        all_menu_info_dicts[menu.id] = {
            'id': menu.id,
            'title': menu.title,
            'parent_id': menu.parent_id,
            'url': menu.url,
            'sys_module_id': menu.sys_module_id,
            'icon': menu.icon,
            'sortby': menu.sortby,
            'subMenus': []
        }
        if not menu.parent_id and menu.id not in root_menu_id_list:
            root_menu_id_list.append(menu.id)

    # sub_menu_info
    map_menus = dict()
    arr_menus = []
    role_root_menu_id_list = []
    for menu in menu_objs:
        if menu.parent_id:
            sub_menus = map_menus.get(menu.parent_id, [])
            obj = {
                'id': menu.id,
                'title': menu.title,
                'parent_id': menu.parent_id,
                'url': menu.url,
                'sys_module_id': menu.sys_module_id,
                'icon': menu.icon,
                'sortby': menu.sortby,
            }
            role_root_menu_id_list.append(menu.parent_id)
            sub_menus.append(obj)
            map_menus[menu.parent_id] = sub_menus
        else:
            role_root_menu_id_list.append(menu.id)

    # root_menu_info
    for root_menu_id in root_menu_id_list:
        if root_menu_id in role_root_menu_id_list:
            menu_info = all_menu_info_dicts.get(root_menu_id)
            arr_menus.append({
                'id': menu_info.get("id"),
                'title': menu_info.get("title"),
                'parent_id': menu_info.get("parent_id"),
                'url': menu_info.get("url"),
                'sys_module_id': menu_info.get("sys_module_id"),
                'icon': menu_info.get("icon"),
                'sortby': menu_info.get("sortby"),
                'subMenus': map_menus.get(root_menu_id, [])
            })
    return arr_menus


def get_roles_by_user_project(user_id):
    role_list = query_role_join_user(user_id=user_id)
    role_id_list = []
    for role_relate, role in role_list:
        role_id_list.append(role.id)
    modu_role = SysModuleModel.get_module_by_role_ids(role_id_list)
    module_id_list = []
    for module_info, role in modu_role:
        if module_info.id not in module_id_list:
            module_id_list.append(module_info.id)
    return module_id_list


def check_license_by_hacksaw(license_data, token):
    myheader = {
        'Content-Type': 'application/json',
        'X-Subject-Token': token
    }

    resp = requests.post(TERRAFORM_BASE + '/license', data=license_data,
                         headers=myheader, verify=True)
    if resp.ok:
        res_val = resp.json()
        if res_val.get('rst') == 'ok':
            license_info = res_val.get('data')
            status_info = license_info.get('status')
            if status_info == 'active':
                status = True
            else:
                status = False
            return license_info, status
        else:
            raise ApiException("request hacksaw license api error, %s" % str(resp))
    else:
        raise ApiException("request hacksaw license api error, %s" % str(resp))


def reset_keystone_basedn(ldap_obj, basedn, config_file):
    if not ldap_obj:
        raise ParamsException("ldap_obj is None type")
    conn = ldap_conn(ldap_obj.server_addr, ldap_obj.server_port, ldap_obj.user_name, ldap_obj.user_pass)
    if not conn:
        raise ParamsException("connect to Ldap config failed: %s:%s" % (ldap_obj.server_addr, ldap_obj.server_port))

    hostname = re.search('\d+\.\d+\.\d+\.\d+', KEYSTONE_BASE).group(0)
    domains = basedn.split(',')
    if len(domains) > 1:
        domain = domains[-2][3:]
    else:
        domain = domains[0]
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=hostname, port=KEYSTONE_PORT, username=KEYSTONE_ROOT_USER, password=KEYSTONE_ROOT_PASS,
                timeout=LDAP_TIMEOUT)
    tt = ssh.invoke_shell()
    tt.send("sudo rm -rf %s.%s.conf" % (KEYSTONE_CONF_HOME, domain))
    tt.send("\n")
    tt.send("set +H")
    tt.send("\n")
    for i in config_file.split('\n'):
        tt.send("sudo echo %s >> %s.%s.conf" % (i, KEYSTONE_CONF_HOME, domain))
        tt.send("\n")
        time.sleep(0.2)
    tt.send("sudo systemctl restart httpd")
    tt.send("\n")
    time.sleep(8)
    ssh.close()


def get_conf_file(basedn, server_addr, user_name, user_pass):
    basedn_split = basedn.split(',')
    if len(basedn_split) > 1:
        suffix = ','.join(basedn_split[1:])
    else:
        suffix = basedn_split[0]
    config_file = LDAP_CONF_FILE % (server_addr, user_name, user_pass, suffix, basedn, basedn)
    if 'ldap' in config_file:
        return config_file
    else:
        return None


def check_license_expire_task():
    cnt, sys_confs = SysInfoConfModel.get_all()
    conf_dict = dict()
    for conf in sys_confs:
        conf_dict[conf.project_id] = conf.license_expire

    project_modules_dict = dict()
    count, licenses = LicenseModel.get_all()
    if licenses:
        for license in licenses:
            license_info = json.loads(license.license_info)
            project_id = license.project_id
            sys_module_id = license.sys_module_id

            if project_id not in project_modules_dict:
                count, modules = SysModuleModel.get_list()
                module_dict = dict()
                for module in modules:
                    module_dict[module.id] = module.module_name
                project_modules_dict[project_id] = module_dict

            platform = project_modules_dict[project_id][sys_module_id]
            auth_items = license_info.get('authItem')
            for item in auth_items:
                unit = item.get('unit', '')
                if unit == "天":
                    finally_time = item.get('total', '')
                    days = (string_toDatetime(finally_time) - datetime.now()).days
                    if days <= 0:
                        # 已过期
                        send_license_expire_msg(project_id, "invalid", platform, finally_time)
                    elif conf_dict[project_id] >= days:
                        # 即将过期
                        send_license_expire_msg(project_id, "valid", platform, finally_time)


def send_license_expire_msg(project_id, status, platform, expire_date):
    data = dict()
    data["project_id"] = project_id
    if status == "invalid":
        data["title"] = "License到期"
        data["content"] = platform + "系统的License已在" + expire_date + "到期，请及时更新"
    else:
        data["title"] = "License即将到期"
        data["content"] = platform + "系统的License即将在" + expire_date + "到期，请及时更新"
    data["notice_type"] = NOTICE
    data["notice_type_name"] = MESSAGE_TYPE_DICT.get(NOTICE)

    InnerNoticeModel.add_notice(**data)
