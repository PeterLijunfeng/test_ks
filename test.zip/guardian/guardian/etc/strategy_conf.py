from collections import namedtuple
from guardian.settings import UCMP_ROLE_KIND_ADMIN, UCMP_ROLE_KIND_DEPT, PLATFORM_UCMP
from guardian.settings import INIT_ROLE_ID, PROJECT_ADMIN, DEPT_ADMIN

#
MessageType = namedtuple("MessageType", ("code", "name"))
# StrategyAppName = namedtuple("StrategyAppName", ("code", "name"))
# StrategyNoticeType = namedtuple("StrategyNoticeType", ("code", "name"))
RoleType = namedtuple("RoleType", ("code", "name"))
# Unknown = namedtuple("unknown", ("code", "name"))
# MessageUnknown = Unknown("unknown", "")
#
# StrategyAppNameDict = {
#     "statis": StrategyAppName("statis", "统计分析"),
#     "statis/add": StrategyAppName("statis/add", "统计分析/建议增加配置"),
#     "statis/reduce": StrategyAppName("statis/reduce", "统计分析/建议减少配置"),
#     "statis/idle": StrategyAppName("statis/idle", "统计分析/空闲实例"),
#     "monitor": StrategyAppName("monitor", "监控告警"),
#     "monitor/alarm": StrategyAppName("monitor/alarm", "监控告警/告警"),
#     "system": StrategyAppName("system", "系统设置"),
#     "system/service_expire": StrategyAppName("system/service_expire", "服务到期"),
#     "system/license_expire": StrategyAppName("system/service_expire", "License到期"),
#     "iaas_apply": StrategyAppName("iaas_apply", "服务申请"),
#     "iaas_apply/success": StrategyAppName("iaas_apply/success", "服务申请/成功"),
#     "iaas_apply/failed": StrategyAppName("iaas_apply/failed", "服务申请/失败"),
#     "iaas_modify": StrategyAppName("iaas_modify", "服务修改"),
#     "iaas_modify/success": StrategyAppName("iaas_apply/success", "服务修改/成功"),
#     "iaas_modify/failed": StrategyAppName("iaas_apply/failed", "服务修改/失败"),
#     "iaas_delete": StrategyAppName("iaas_delete", "服务删除"),
#     "iaas_delete/success": StrategyAppName("iaas_apply/success", "服务删除/成功"),
#     "iaas_delete/failed": StrategyAppName("iaas_apply/failed", "服务删除/失败"),
# }
#
EMAIL = 0
SMS = 1
INNER_NOTICE = 2
MessageTypeDict = {
    EMAIL: "邮件",
    SMS: "短信",
    INNER_NOTICE: "站内消息"
}
#
# StrategyNoticeTypeDict = {
#     1: StrategyNoticeType(1, "单次"),
#     2: StrategyNoticeType(2, "多次"),
# }
#
APPLICANT = "applicant"
RESPONSIBLE = "responsible"
RoleTypeDict = {
    APPLICANT: "申请人",
    RESPONSIBLE: "责任人",
    "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN]: "租户管理员",
    "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN]: "部门管理员",

}

MESSAGE_CONF_FOR_UCMP = [
    {
        "id": "33874dfbdc3b47528e693625779306bf",
        "value": "%s/iaas_apply" % PLATFORM_UCMP,
        "label": "服务申请",
        "advancedOptions": True,
        "acceptRole": [{"id": APPLICANT, "label": "申请人"},
                       {"id": RESPONSIBLE, "label": "责任人"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}
                       ],
        "hasDelayTime": False,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        "children": [{"id": "cb133c9e1245425ab89111361963c1c2", "value": "success", "label": "成功",
                      "parentId": "33874dfbdc3b47528e693625779306bf"},
                     {"id": "60b4f7db6ff04bcc9c0bd35faef69921", "value": "failed", "label": "失败",
                      "parentId": "33874dfbdc3b47528e693625779306bf"}]
    },
    {
        "id": "54cb291c952d475bb067a284294d2661",
        "value": "%s/iaas_modify" % PLATFORM_UCMP,
        "label": "服务修改",
        "advancedOptions": True,
        "acceptRole": [{"id": APPLICANT, "label": "申请人"},
                       {"id": RESPONSIBLE, "label": "责任人"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}
                       ],
        "hasDelayTime": False,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        "children": [{"id": "9783583b044048a285a28851b7468a6d", "value": "success", "label": "成功",
                      "parentId": "54cb291c952d475bb067a284294d2661"},
                     {"id": "8a62e96482894ea893f1064756d6d73b", "value": "failed", "label": "失败",
                      "parentId": "54cb291c952d475bb067a284294d2661"}]
    },
    {
        "id": "7b053f97d7c446b99680ab55a86e3847",
        "value": "%s/iaas_delete" % PLATFORM_UCMP,
        "label": "服务删除",
        "advancedOptions": True,
        "acceptRole": [{"id": APPLICANT, "label": "申请人"},
                       {"id": RESPONSIBLE, "label": "责任人"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}
                       ],
        "hasDelayTime": False,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        "children": [{"id": "b4f136ecd0774987bf66b4a6acd7d54a", "value": "success", "label": "成功",
                      "parentId": "7b053f97d7c446b99680ab55a86e3847"},
                     {"id": "f7c68c33dfd542e184aeb9f74f538327", "value": "failed", "label": "失败",
                      "parentId": "7b053f97d7c446b99680ab55a86e3847"}]
    },
    {
        "id": "199addc4db3444b5bd14ebb7f8abd58c",
        "value": "%s/statis" % PLATFORM_UCMP,
        "label": "统计分析",
        "advancedOptions": True,
        "acceptRole": [{"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}],
        "hasDelayTime": False,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        "children": [{"id": "b1a8cd8502754293af6fbab9902ed46b", "value": "add", "label": "建议增加配置",
                      "parentId": "199addc4db3444b5bd14ebb7f8abd58c"},
                     {"id": "6dd0c287ad42431fa967bcdf03b21756", "value": "reduce", "label": "建议减少配置",
                      "parentId": "199addc4db3444b5bd14ebb7f8abd58c"},
                     {"id": "b98ea0df09b849f38c71493cbc80ed57", "value": "idle", "label": "空闲实例",
                      "parentId": "199addc4db3444b5bd14ebb7f8abd58c"}]
    },
    {
        "id": "001eb9ee24f54aa59423291f15843f42",
        "value": "%s/monitor" % PLATFORM_UCMP,
        "label": "监控告警",
        "advancedOptions": True,
        "acceptRole": [{"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}],
        "hasDelayTime": False,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        "children": [{"id": "c67199103bf74ff096e2cd84cff618d7", "value": "alarm", "label": "告警",
                      "parentId": "001eb9ee24f54aa59423291f15843f42"}]
    },
    {
        "id": "126050517ad0457f852d2e713a074a1a",
        "value": "%s/system" % PLATFORM_UCMP,
        "label": "系统设置",
        "advancedOptions": True,
        "acceptRole": [{"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN], "label": "租户管理员"},
                       {"id": "role_" + INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN], "label": "部门管理员"}],
        "hasDelayTime": True,
        "noticeTimes": [{"value": 1, "label": "单次"}],
        "period": [],
        # "period": [{"value": 1, "label": "1天前"},
        #            {"value": 7, "label": "7天前"},
        #            {"value": 15, "label": "15天前"},
        #            {"value": 30, "label": "30天前"}],
        "children": [{"id": "8b52d15a51f14bf2af92d2a4ee30a8d7", "value": "service_expire", "label": "服务到期",
                      "parentId": "126050517ad0457f852d2e713a074a1a"},
                     # {"id": "9d371c1b076d46b5b1c91fc07cfc59e6", "value": "license_expire", "label": "License到期",
                     #  "parentId": "126050517ad0457f852d2e713a074a1a"}
         ]
    }
]
