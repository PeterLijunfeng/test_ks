
import json
from celery.decorators import task
from celery.utils.log import get_task_logger
from guardian.common.message.mail import GuardianMail

log = get_task_logger("celery_logger")


@task(name="tasks.helloworld.task_test", queue="musir", routing_key="test.hello_test")
def hello_test():
    log.debug("worker hello")
    log.info("info worker hello")
    log.error("err worker hello")
    print("test")


