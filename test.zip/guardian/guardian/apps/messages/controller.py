import re
import math
import json
from copy import deepcopy
from flask import request
from flask import Blueprint
from celery.execute import send_task
from guardian.log4 import app_logger as log
from guardian.common.rest import restful
from guardian.common.errors import ParamsException
from guardian.settings import APIBASEURL, EMAIL_CONTENT, EMAIL_SUBJECT
from guardian.settings import PLATFORM_UCMP
from guardian.utils.dates import time_to_timestamp
from guardian.etc.strategy_conf import MESSAGE_CONF_FOR_UCMP, RoleTypeDict
from guardian.apps.messages.models import MsgStrategyModel
from guardian.apps.messages.models import MsgTemplateModel
from guardian.apps.messages.models import InnerNoticeModel
from guardian.apps.messages.models import SmsConfigModel
from guardian.apps.messages.models import InnerNoticeStatusModel
from guardian.apps.messages.models import EmailConfigModel
from guardian.apps.messages.services import send_message
from guardian.apps.messages.services import send_no_template_message
from guardian.apps import OFF, ON, IS_TLS, NOT_TLS
from guardian.apps import EMAIL_SERVER_PORT
from guardian.etc.strategy_conf import MessageTypeDict


messages_site = Blueprint('msgs', __name__, url_prefix="%s/msgs" % APIBASEURL)


@messages_site.route('/strategy', methods=['POST'])
@restful
def create_update_msgs_strategy(*args, **kwargs):

    """
    create_msgs_strategy batch
    if id, strategy exist, update strategy; else not exist, create strategy.
    [
        {
            "id": "70deda9b77364e11acc63ba6bcca19db",  # id为空新建, 不为空更新
            "strategy_app_id": "ucmp/iaas_apply/success",  # value 拼接  for Go & Java
            "strategy_app_name": "服务申请/成功",
            "title": "test1",
            "strategy_period_type": 1,
            "strategy_period_type_name": "单次",
            "accept_role_list": ["applicant", "fc37e6af5a284b01b67be6b4593f0fdf"],
            "accept_user_list": ["user_id_uuid_1", "user_id_uuid_2"],
            "send_ahead_date": 0,
            "support_message_types": [0, 1],  # 0 邮件, 1 短信, 2 站内消息
            "select_template_ids": [],
            "select_strategy_app_id": ""  # uuid  for web
        }
    ]
    :param args:
    :param kwargs:
    :return: {"rst": "ok", "data": {}}
    """
    data_list_json = request.get_json()
    must_params = ["strategy_app_id",  "title", "strategy_period_type", "strategy_period_type_name", "support_message_types",
                   "accept_role_list", "accept_user_list", "select_strategy_app_id", "select_template_ids"]
    update_strategy_list = []
    create_strategy_list = []
    user = kwargs.get("user")
    for data_info in data_list_json:
        for item in must_params:
            if item not in data_info or data_info.get(item) == "":
                raise ParamsException("{0} maybe missing".format(item))
        data_info["project_id"] = user["project_id"]
        if data_info.get("id"):
            update_strategy_list.append(data_info)
        else:
            create_strategy_list.append(data_info)

    if update_strategy_list:
        MsgStrategyModel.update_strategy_batch(update_strategy_list)

    if create_strategy_list:
        MsgStrategyModel.add_strategy_batch(create_strategy_list)
    return {}


@messages_site.route('/strategy/enable', methods=['POST'])
@restful
def enable_disable_msgs_strategy(*args, **kwargs):
    """
    {
        "id": "59657812ee79457da5fdb2502f0bc08b",
        "is_on":0
    }
    :param args:
    :param kwargs:
    :return: {"rst": "ok", "data": {"id":"5b13bdc0808748648c566d384513c9cb"}}
    """
    data_dict = request.get_json()
    strategy_id = data_dict.get("id")
    if not strategy_id:
        log.error("[id] maybe missing")
        raise ParamsException("[id] maybe missing")
    is_on = data_dict.get("is_on")
    if is_on not in [ON, OFF]:
        log.error("params [is_on] must be 0/1; but get %s" % str(is_on))
        raise ParamsException("params [is_on] must be 0/1; but get %s" % str(is_on))
    strategy_obj = MsgStrategyModel().get_one(strategy_id)
    if not strategy_obj:
        log.error("can not found anyone by id [%s]" % str(strategy_id))
        raise ParamsException("can not found anyone by id [%s]" % str(strategy_id))
    strategy_obj.enable_disable_strategy(is_on=is_on)
    return {
        "id": strategy_obj.id
    }


@messages_site.route('/strategy/del', methods=['POST'])
@restful
def del_msgs_strategy(*args, **kwargs):
    """
    {"id": "59657812ee79457da5fdb2502f0bc08b"}
    :param args:
    :param kwargs:
    :return: {"rst": "ok", "data": {"id":"59657812ee79457da5fdb2502f0bc08b"}}
    """
    data_dict = request.get_json()
    strategy_id = data_dict.get("id")
    if not strategy_id:
        log.error("[id] maybe missing")
        raise ParamsException("[id] maybe missing")
    strategy_obj = MsgStrategyModel().get_one(strategy_id)
    if not strategy_obj:
        log.error("can not found anyone by id [%s]" % str(strategy_id))
        raise ParamsException("can not found anyone by id [%s]" % str(strategy_id))
    strategy_obj.del_strategy()

    return {
        "id": strategy_obj.id
    }


@messages_site.route('/strategy/list', methods=['GET'])
@restful
def list_strategy(*args, **kwargs):
    """
    :param args: app_id, id, is_on
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'strategy_list': [{
                'id': '95b49ffb3ab64703bc394661820040f1',
                'strategy_app_id': 'ucmp/iaas_apply/success',  # value 拼接  for Go & Java
                'strategy_app_name': '服务申请/成功',
                'project_id': '0eb082df17d44c8abf46414d8a1397f8',
                'title': 'test1',
                'strategy_period_type': 1,
                'strategy_period_type_name': '单次', # 周期
                'send_ahead_date': 0,   # 提前时间（天）
                'support_message_type_ids': [1, 0],   # 0 邮件 1 短信 2 站内信
                'support_message_type_names': ['短信', '邮件'],   # 消息类型名称
                'select_message_type_list': [{
                    "id": "9a576a8621244ed0883190827bc7832d",
                    "type_id": 0,
                    "type_name": "邮件",
                    "variable": "[... ...]"
                }],
                'select_template_ids': [],
                'accept_role_list"': [{'id': 'ucmp_admin', 'lable': '租户管理员'}, {'id': 'ucmp_dept', 'lable': '部门管理员'}],
                'accept_user_list': ['user_id_uuid_1', 'user_id_uuid_2'],
                'select_strategy_app_id': '9d371c1b076d46b5b1c91fc07cfc59e6',  # uuid  for web
                'is_on': 1,   # 是否启用
                'create_at': 1552449489,   # 创建时间
                'update_at': 1552449512}],   # 更新时间
            'page': 1,
            'page_count': 1,
            'total': 1
        }
    }
    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"]
    }
    if request.args.get('app_id'):
        filters["strategy_app_id"] = request.args.get('app_id')
    if request.args.get('id'):
        filters["id"] = request.args.get('id')
    if request.args.get('is_on', "") in [OFF, ON]:
        filters["is_on"] = request.args.get('is_on')

    total_count, resp_data_list = MsgStrategyModel.get_list(page_idx=page_idx, limit=limit, **filters)
    page_count = math.ceil(total_count / limit)

    data_list = []
    for item in resp_data_list:
        strategy_item = {
            "id": item.id,
            "strategy_app_id": item.strategy_app_id,
            "strategy_app_name": item.strategy_app_name,
            "project_id": item.project_id,
            "title": item.title,
            "strategy_period_type": item.strategy_period_type,
            "strategy_period_type_name": item.strategy_period_type_name,
            "send_ahead_date": item.send_ahead_date,
            "support_message_type_ids": json.loads(item.support_message_types),
            "support_message_type_names": [MessageTypeDict.get(ms_type) for ms_type in json.loads(item.support_message_types)],
            "select_template_ids": json.loads(item.select_template_ids),
            "accept_role_list": [{"id": role, "lable": RoleTypeDict.get(role) if RoleTypeDict.get(role) else ""}
                                 for role in json.loads(item.accept_role_list)],
            "accept_user_list": json.loads(item.accept_user_list),
            "select_strategy_app_id": item.select_strategy_app_id,
            "is_on": item.is_on,
            "create_at": time_to_timestamp(item.create_at),
            "update_at": time_to_timestamp(item.update_at)
        }
        _, tpls = MsgTemplateModel.get_list(project_id=user["project_id"], template_ids=json.loads(item.select_template_ids))
        select_message_type_list = []
        for tpl_item in tpls:
            select_message_type_list.append({
                "id": tpl_item.id,
                "type_id": tpl_item.type_id,
                "type_name": tpl_item.type_name,
                "variable": tpl_item.variable,
            })
        strategy_item["select_message_type_list"] = select_message_type_list
        data_list.append(strategy_item)

    resp_data = {
        "strategy_list": data_list,
        "page": page_idx,
        "page_count": page_count,
        "total": total_count
    }
    return resp_data


@messages_site.route('/send', methods=['POST'])
@restful
def send_strategy_message(*args, **kwargs):
    """
    API for Go & Java
    notice_type_id  涉及站内信必须要传
    message_type  不传 按照策略中配置的发送； 传 只发传的类型，如 邮件，短信， 站内消息
    {
        "to_user": [
            "87cb4da3919a47688d6a0669ea366fed",  # 申请人
            "53a882c0f1384393ae651a48dc73b791"   # 责任人
        ],
        "source_info": {
            "org_id": "xxx",
        },
        "strategy_id": "87cb4da3919a47688d6a0669ea366fed",
        "notice_type_id": 1,  # 站内消息类型
        "message_type": 1,  # 发送信息的类型，邮件、短信、站内消息
        "level": 1,
        "variable": [
            {"key": "username", "value": "用户名"},
            {"key": "action", "value": "行为，如申请等"},
            {"key": "app", "value": "业务"},
            {"key": "machine_name", "value": "name"},
            {"key": "cpu", "value": "CPU"},
            {"key": "memory", "value": "10%"}
        ],
        "force":1
    }
    :param args: force:1 强制发送消息至to_user内的用户
                 force:0 需要过滤并组合所有用户并发送消息
    :param kwargs:
    通知类型(notice_type_id)：通知（notice:2），故障告警（alarm:3），产品升级维护（maintenance:4），提示 （info:1）
    信息类型(message_type)：邮件（0），短信（1），站内消息（2） # java
            # conf: python guardian/etc/strategy_conf.py
    :return:
    {
        "rst": "ok",
        "data": {}
    }
    """
    data_json = request.get_json()
    must_params = ["strategy_id", "notice_type_id", "level", "variable"]
    support_send_message = [PLATFORM_UCMP]
    for item in must_params:
        if item not in data_json or data_json.get(item) == "":
            log.error("'{0}' maybe missing".format(item))
            raise ParamsException("'{0}' maybe missing".format(item))
    if not data_json.get("to_user"):
        data_json["to_user"] = []
    source_info = data_json.get("source_info", {})
    strategy_id = data_json.get("strategy_id"),
    strategy_obj = MsgStrategyModel().get_one(strategy_id)
    if not strategy_obj:
        log.error("can not found strategy by id: {0}".format(strategy_id))
        raise ParamsException("can not found strategy by id: {0}".format(strategy_id))
    project_id = strategy_obj.project_id
    role_name_list = json.loads(strategy_obj.accept_role_list)
    user_id_list = json.loads(strategy_obj.accept_user_list)
    template_ids = json.loads(strategy_obj.select_template_ids)
    if not template_ids:
        log.error("'strategy_id': '{0}' select_template_ids is None".format(strategy_id))
        raise ParamsException("'strategy_id': '{0}' select_template_ids is None".format(strategy_id))
    platform = strategy_obj.strategy_app_id[0:strategy_obj.strategy_app_id.index("/")]
    if platform not in support_send_message:
        log.error("[%s] not support to send message" % platform)
        raise ParamsException("[%s] not support to send message" % platform)
    filters = {
        "project_id": project_id,
        "template_ids": template_ids
    }
    cnt, template_objs = MsgTemplateModel.get_list(**filters)
    if not cnt:
        log.error("can not found templates by ids: {0}".format(json.loads(strategy_obj.select_template_ids)))
        raise ParamsException(
            "can not found templates by ids: {0}".format(json.loads(strategy_obj.select_template_ids)))

    force = data_json.get("force", 0)
    log.info('force is %s', force)
    if force == 1 and not data_json.get("to_user"):
        log.error("can not found user ids: {0}".format(data_json.get("to_user")))
        raise ParamsException(
            "can not found user ids: {0}".format(data_json.get("to_user")))

    send_info = {
        "project_id": project_id,
        "to_user": data_json.get("to_user", []),
        "role_name_list": role_name_list,
        "user_id_list": user_id_list,
        "templates": template_objs,
        "notice_type_id": data_json.get("notice_type_id"),
        "level": data_json.get("level"),
        "variable": data_json.get("variable"),
        "source_info": source_info,
        "platform": platform,
        "force": force,
        "message_type":  data_json.get("message_type", "")
    }
    # celery send message
    send_message(send_info)
    return {}


@messages_site.route('/customize/send', methods=['POST'])
@restful
def send_customize_message(*args, **kwargs):
    """
    API for Java 发送自定义消息/ 非模板消息
    通知类型(notice_type_id)：  涉及站内信必须要传
        提示 （info:1）,通知（notice:2）,故障告警（alarm:3）,产品升级维护（maintenance:4）
    信息类型(message_type)：邮件（0）,短信（1）,站内消息（2）
    {
        "to_user": ["87cb4da3919a47688d6a0669ea366fed", "53a882c0f1384393ae651a48dc73b791"],
        "source_info": {
            "org_id": "xxx"
        },
        "title": "自定义消息标题",
        "content": "自定义消息内容",
        "notice_type_id": 1,  # 站内消息类型
        "message_type": 1,  # 发送信息的类型，邮件、短信、站内消息  必传
        "level": 1
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {}
    }
    """
    data_json = request.get_json()
    must_params = ["title", "content", "to_user", "notice_type_id", "message_type", "level"]
    for item in must_params:
        if item not in data_json or data_json.get(item) in ["", []] :
            log.error("'{0}' maybe missing".format(item))
            raise ParamsException("'{0}' maybe missing".format(item))
    user = kwargs.get("user")

    send_info = {
        "project_id": user["project_id"],
        "to_user": data_json.get("to_user"),
        "title": data_json.get("title"),
        "content": data_json.get("content"),
        "notice_type_id": data_json.get("notice_type_id"),
        "level": data_json.get("level"),
        "message_type": data_json.get("message_type", "")
    }
    # celery send message
    send_no_template_message(send_info)
    return {}


@messages_site.route('/strategy/conf', methods=['GET'])
@restful
def get_strategy_conf(*args, **kwargs):
    """

    :param args:
    :param kwargs:
    :return:
    """
    filters = {
        "project_id": kwargs.get("user").get("project_id")
    }
    cnt, all_temp = MsgTemplateModel.get_list(**filters)
    templates_dict = {}
    for template in all_temp:
        temp_list = templates_dict.get(template.strategy_app_id, [])
        temp_list.append({
            "id": template.id,
            "strategy_app_id": template.strategy_app_id,
            "strategy_app_name": template.strategy_app_name,
            "title": template.title,
            "project_id": template.project_id,
            "content": template.content,
            "type_id": template.type_id,
            "type_name": template.type_name,
            "variable": template.variable
        })
        templates_dict[template.strategy_app_id] = temp_list

    response_conf = deepcopy(MESSAGE_CONF_FOR_UCMP)
    for conf in response_conf:
        children_list = conf['children']
        for children in children_list:
            dict_key = conf['value'] + '/' + children['value']
            children['tempalte_list'] = templates_dict.get(dict_key)
    return response_conf


@messages_site.route('/template/update', methods=['POST'])
@restful
def update_template(*args, **kwargs):
    """
    {
        "strategy_app_id":"statis/idle",
        "template_list":[
            {
                "id":"cdfefd9dd-0d75-g2b7-8abf-2df788839c",
                "title":"模板1",
                "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%},
                网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
            },
            {
                "id":"fd9dd-0d75-g2b7-8abf-2efeofefe",
                "title":"模板",
                "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%},
                网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
            },
            {
                "id":"cdfefd9dd-0d75-g2b7-826839c-fewa",
                "title":"模板2",
                "content":"用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, 内存使用率为{%memory%},
                网络流入{%network_in%}, 网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
            }
        ]
    }
    :param args:
    :param kwargs:
    :return: {"rst": "ok", "data": {}}
    """
    data_list_json = request.get_json()
    if "template_list" not in data_list_json or data_list_json.get("template_list") == "":
        raise ParamsException("template_list maybe missing")
    template_list = data_list_json.get("template_list")
    sub_must_params = ["id", "title", "content"]
    update_template_list = []
    for data_info in template_list:
        for item in sub_must_params:
            if item not in data_info or data_info.get(item) == "":
                raise ParamsException("{0} maybe missing".format(item))
        update_template_list.append(data_info)
    if update_template_list:
        MsgTemplateModel.update_template_batch(update_template_list)
    return {}


@messages_site.route('/template/list', methods=['GET'])
@restful
def list_template(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
    "rst": "ok",
    "data": {
        "template_list":
            [{
                "strategy_app_id":"system/service_expire",
                "strategy_app_name":"服务到期",
                "template_list":[
                    {
                        "id":"oooz2ad91d-0d75-42b7-8abf-2df78826839c",
                        "strategy_app_id":"system/service_expire",
                        "strategy_app_name":"服务到期",
                        "title":"模板",
                        "content":"用户{%username%}的{%service_name%}服务{%experation_date%}到期，...",
                        "project_id":"0eb082df17d44c8abf46414d8a1397f8",
                        "type":2,
                        "type_name":"站内消息",
                        "variable":"[{"key":"username", "value":"用户名"}, ...]"
                    }
                ]
            }],
        "page": 1}
    }
    """
    limit = request.args.get('limit', default=50, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user = kwargs.get("user")
    project_id = user["project_id"]
    total_count, resp_data_list = MsgTemplateModel \
        .get_list(page_idx=page_idx, limit=limit, project_id=project_id)

    root_temp_item = {}
    for item in resp_data_list:
        sub_temp_item = {
            "id": item.id,
            "strategy_app_id": item.strategy_app_id,
            "strategy_app_name": item.strategy_app_name,
            "title": item.title,
            "content": item.content,
            "project_id": item.project_id,
            "type_id": item.type_id,
            "type_name": item.type_name,
            "variable": item.variable
        }
        if item.strategy_app_id in root_temp_item:
            root_temp_item[item.strategy_app_id].append(sub_temp_item)
        else:
            root_temp_item[item.strategy_app_id] = [sub_temp_item]

    data_list = []
    for key in root_temp_item:
        data_list.append({
            "strategy_app_id": key,
            "strategy_app_name": root_temp_item[key][0]["strategy_app_name"],
            "template_list": root_temp_item[key]
        })
    resp_data = {
        "template_list": data_list,
        "page": page_idx
    }
    return resp_data


@messages_site.route('/notice', methods=['POST'])
@restful
def create_notice(*args, **kwargs):
    """
    创建站内信
    {
        "notice_type": 2,
        "notice_type_name": "通知",
        "title": "test_1",
        "content": "123456"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id": "66749960e6fb4585bf8b2dcf705ea199"
        }
    }
    """
    data = request.get_json()
    must_params = ["notice_type", "notice_type_name", "title", "content"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            raise ParamsException("{0} maybe missing".format(item))
    user = kwargs.get("user")
    project_id = user["project_id"]
    data["project_id"] = project_id
    notice_obj = InnerNoticeModel.add_notice(**data)
    return {
        "id": notice_obj.id
    }


@messages_site.route('/notice', methods=['GET'])
@restful
def list_notice(*args, **kwargs):
    """
    ?type=  提示(1)， 通知(2), 故障告警(3), 产品升级维护(4),
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "notices": [
                {
                    "id":"1c2f1e3dec0c4420bfc329a58a780590",
                    "project_id":"87cb4da3919a47688d6a0669ea366fed",
                    "title":"模板"
                    "content":"用户{%username%}的{%service_name%}...",
                    "notice_type": 2,
                    "notice_type_name":"提示",
                    "is_read": 1,
                    "create_at":"2019-01-29 09:00:13",
                }
            ],
            "page": 1,
            "page_count": 1,
            "total": 1
        }
    }
    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user = kwargs.get("user")
    filters = {
        "user_id": user["id"],
        "project_id": user["project_id"],
        "notice_type": request.args.get("type", ""),
    }
    total_count, notice_list = InnerNoticeModel.query_notice(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for notice, notice_status in notice_list:
        rst.append({
            "id": notice_status.id if notice_status else None,
            "notice_id": notice.id,
            "project_id": notice.project_id,
            "title": notice.title,
            "content": notice.content,
            "notice_type": notice.notice_type,
            "notice_type_name": notice.notice_type_name,
            "is_read": notice_status.is_read if notice_status else None,
            "create_at": time_to_timestamp(notice.create_at)
        })
    return {
        "notices": rst,
        "page": page_idx,
        "page_count": math.ceil((total_count) / limit),
        "total": total_count
    }


@messages_site.route('/notice/notread', methods=['GET'])
@restful
def list_notice_not_read(*args, **kwargs):
    """/msgs/notice/notread?type=&limit=20&page=1
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "notices": [
                {
                    "id": null,
                    "notice_id": "df79bc9ed36041e899dcbf16333a6f4f",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "title": "\"\\u6a21\\u677f\"",
                    "content": "用户管理员的云主机出现告警，告警来源：192.168.6.7 告警类型:性能，告警级别:提示，请尽快前往进行处理",
                    "notice_type": "3",
                    "notice_type_name": "故障告警",
                    "is_read": null,
                    "create_at": 1553503189
                }
            ],
            "page": 1,
            "page_count": 1,
            "total": 1
        }
    }
    # notice type: 1 info提示, 2 notice 通知, 3 alarm 告警, 4 maintenance产品升级维护
    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user = kwargs.get("user")
    filters = {
        "user_id": user["id"],
        "project_id": user["project_id"]
    }
    total_count, notice_list = InnerNoticeModel.query_notice_not_read(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for notice, notice_status in notice_list:
        rst.append({
            "notice_id": notice.id,
            "title": notice.title,
            "content": notice.content,
            "notice_type": notice.notice_type,
            "create_at": time_to_timestamp(notice.create_at)
        })
    return {
        "notice_list": rst,
        "not_read_count": total_count
    }


@messages_site.route('/notice/read', methods=['POST'])
@restful
def mark_notice_read(*args, **kwargs):
    """
    {"notice_ids":["2f0f79c1e41447f6bc148d7484456b27"]}
    :param args:
    :param kwargs:
    :return:
    """
    data = request.get_json()
    if "notice_ids" not in data or data.get("notice_ids") == []:
        raise ParamsException("notice_ids maybe missing")
    user = kwargs.get("user")
    filters = {
        "notice_ids": data.get("notice_ids"),
        "user_id": user["id"],
        "project_id": user["project_id"]
    }
    read_info_list = InnerNoticeStatusModel.get_notice_id_by_status_info(**filters)
    notice_not_read_list = []
    for notice_id in data.get("notice_ids"):
        if (notice_id,) not in read_info_list:
            notice_not_read_list.append(notice_id)
    if notice_not_read_list:
        InnerNoticeStatusModel.add_notice_status_batch(user["id"], notice_not_read_list)
    return {}


@messages_site.route('/notice/del', methods=['DELETE'])
@restful
def del_notice_status(*args, **kwargs):
    """
    {"notice_ids":["2f0f79c1e41447f6bc148d7484456b27"]}
    :param args:
    :param kwargs:
    :return:
    """
    user = kwargs.get("user")
    data = request.get_json()
    if "notice_ids" not in data or data.get("notice_ids") == []:
        raise ParamsException("notice_ids maybe missing")
    filters = {
        "notice_ids": data.get("notice_ids"),
        "user_id": user["id"],
        "project_id": user["project_id"]
    }
    status_info_list = InnerNoticeStatusModel.get_list_by_status_info(**filters)
    notice_id_list = []
    status_id_list = []
    for status_id, notice_id in status_info_list:
        status_id_list.append(status_id)
        notice_id_list.append(notice_id)

    id_in_status_list = []
    id_not_in_status_list = []
    for notice_id in data.get("notice_ids"):
        if notice_id in notice_id_list:
            id_in_status_list.append(status_id_list[notice_id_list.index(notice_id)])
        else:
            id_not_in_status_list.append(notice_id)
    if id_in_status_list:
        InnerNoticeStatusModel.del_notice_info_batch(id_in_status_list)
    if id_not_in_status_list:
        InnerNoticeStatusModel.del_notice_status_batch(user["id"], id_not_in_status_list)
    return {}


@messages_site.route('/sms_conf', methods=['POST'])
@restful
def create_update_sms_conf(*args, **kwargs):
    """
    {
        "id":"425c91fc27c647b4b5c397cad8d7ba15",
        "server_addr":"123",
        "server_port":22,
        "account_id":"12345",
        "account_token":"123",
        "test_phone":"18629876785",
        "extra_params":[
            {
                "key":"test",
                "value":"test"
            }
        ]
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id": "66749960e6fb4585bf8b2dcf705ea199"
        }
    }
    """
    data = request.get_json()
    must_params = ["account_id", "account_token", "test_phone"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            log.error("params '{0}' maybe missing".format(item))
            raise ParamsException("{0} maybe missing".format(item))
    if not re.match(r"1[3456789]\d{9}", data.get("test_phone")):
        log.error("test phone number is wrong")
        raise ParamsException("test phone number is wrong")
    if "id" in data and data.get("id") != "":
        sms_obj = SmsConfigModel(id=data.get("id")).get_one()
        if not sms_obj:
            log.error("can not found anyone by id [%s]" % str(data.get("id")))
            raise ParamsException("can not found anyone by id [%s]" % str(data.get("id")))
        sms_obj.update_sms_conf(**data)
    else:
        user = kwargs.get("user")
        data["project_id"] = user["project_id"]
        sms_obj = SmsConfigModel.add_sms_conf(**data)
    return {
        "id": sms_obj.id
    }


@messages_site.route('/sms_conf', methods=['GET'])
@restful
def get_sms_conf(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id":"",
            "project_id":"",
            "server_addr":"123",
            "server_port":22,
            "app_id":"12345",
            "account_token":"123",
            "to_phone":"18629876785",
            "extra_params":[
                {
                    "key":"test",
                    "value":"test"
                }
            ]
        }
    }
    """
    user = kwargs.get("user")
    sms_obj = SmsConfigModel(project_id=user["project_id"]).get_one_by_project_id()
    if not sms_obj:
        return {
            "id": "",
            "project_id": user["project_id"],
            "server_addr": "",
            "server_port": "",
            "account_id": "",
            "account_token": "",
            "test_phone": "",
            "extra_params": []
        }
    return {
        "id": sms_obj.id,
        "project_id": sms_obj.project_id,
        "server_addr": sms_obj.server_addr,
        "server_port": sms_obj.server_port,
        "account_id": sms_obj.account_id,
        "account_token": sms_obj.account_token,
        "test_phone": sms_obj.test_phone,
        "extra_params": json.loads(sms_obj.extra_params) if sms_obj.extra_params else []
    }


@messages_site.route('/email/conf', methods=['POST'])
@restful
def create_update_email_conf(*args, **kwargs):
    """
    {
        "id": "",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "server_addr":"smtp.mxhichina.com",
        "server_port":465,
        "is_tls":1,
        "user_name":"云管测试",
        "from_user_addr":"junfeng.li@leaptocloud.com",
        "user_pass":"×××××××",
        "test_to_user_addr":"junfeng.li@leaptocloud.com"
    }
    :param args:
    :param kwargs:
    :return:
    """
    data = request.get_json()
    must_params = ["server_addr", "user_pass", "from_user_addr", "test_to_user_addr"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            log.error("params '{0}' maybe missing".format(item))
            raise ParamsException("{0} maybe missing".format(item))
    if "server_port" not in data or data.get("server_port") == "":
        log.info("params [server_port] not in request data or is ''")
        data["server_port"] = EMAIL_SERVER_PORT
    if "is_tls" not in data or data.get("is_tls") not in [IS_TLS, NOT_TLS]:
        log.info("params [is_tls] not in request data or is ''")
        data["is_tls"] = IS_TLS

    user = kwargs.get("user")
    if "id" in data and data.get("id") != "":
        email_id = data.get("id")
        email_obj = EmailConfigModel(id=email_id).get_one()
        if not email_obj:
            log.info("can not found anyone by id [%s]" % email_id)
            raise ParamsException("can not found anyone by id [%s]" % email_id)
        email_obj.update_email(**data)
    else:
        data["project_id"] = user["project_id"]
        email_obj = EmailConfigModel.add_email(**data)
    return {
        "id": email_obj.id
    }


@messages_site.route('/email', methods=['GET'])
@restful
def get_email_conf(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id": "9d8b6b03cd864e7fb613f3ea198373a7",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "server_addr":"smtp.mxhichina.com",
            "server_port":465,
            "is_tls":1,
            "user_name":"云管测试",
            "from_user_addr":"junfeng.li@leaptocloud.com",
            "user_pass":"×××××××",
            "test_to_user_addr":"junfeng.li@leaptocloud.com"
        }
    }
    """
    user = kwargs.get("user")
    filters = {"project_id": user["project_id"]}
    email_obj = EmailConfigModel().get_one_by_project_id(**filters)
    if not email_obj:
        return {
            "id": "",
            "project_id": user["project_id"],
            "server_addr": "",
            "server_port": EMAIL_SERVER_PORT,
            "is_tls": IS_TLS,
            "user_name": "",
            "from_user_addr": "",
            "user_pass": "",
            "test_to_user_addr": ""
        }
    return {
        "id": email_obj.id,
        "project_id": email_obj.project_id,
        "server_addr": email_obj.server_addr,
        "server_port": email_obj.server_port,
        "is_tls": email_obj.is_tls,
        "user_name": email_obj.user_name,
        "from_user_addr": email_obj.from_user_addr,
        "user_pass": email_obj.user_pass,
        "test_to_user_addr": email_obj.test_to_user_addr
    }


@messages_site.route('/email/test', methods=['POST'])
@restful
def test_email_conf(*args, **kwargs):
    """
    {
        "id": "9d8b6b03cd864e7fb613f3ea198373a7",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "server_addr":"smtp.mxhichina.com",
        "server_port":465,
        "is_tls":1,
        "user_name":"云管测试",
        "user_pass":"×××××××",
        "from_user_addr":"junfeng.li@leaptocloud.com",
        "test_to_user_addr":"junfeng.li@leaptocloud.com"
    }
    :param args:
    :param kwargs:
    :return:
    """
    data = request.get_json()
    must_params = ["server_addr", "server_port", "is_tls", "user_pass", "from_user_addr", "test_to_user_addr"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            log.error("params '{0}' maybe missing".format(item))
            raise ParamsException("{0} maybe missing".format(item))
    send_mail_info = {
        "mail_host": data["server_addr"],
        "smtp_port": int(data["server_port"]),
        "is_tls": data["is_tls"],
        "user_name": data["user_name"] if data.get("user_name") else data["from_user_addr"],
        "from_addr": data["from_user_addr"],
        "mail_pass": data["user_pass"],
        "to_addr": [data["test_to_user_addr"]],
        "sub": EMAIL_SUBJECT,
        "content": EMAIL_CONTENT}
    log.debug("send_mail_info is %s" % json.dumps(send_mail_info))
    send_task('tasks.message.celery_send_mail', [json.dumps(send_mail_info)], queue="gd_message")
    return {}


@messages_site.route('/email/send', methods=['POST'])
@restful
def send_email(*args, **kwargs):
    """
    {"to_user_addrs": ['cloud@163.com'],
     "sub": "Title",
     "content": "mail content."
    }
    :param args:
    :param kwargs:
    :return:
    """
    data = request.get_json()
    if "to_user_addrs" not in data or data.get("to_user_addrs") == []:
        log.error("params 'to_user_addrs' maybe missing")
        raise ParamsException("'to_user_addrs' maybe missing")

    user = kwargs.get("user")
    filters = {"project_id": user["project_id"]}
    email_obj = EmailConfigModel().get_one_by_project_id(**filters)
    if not email_obj:
        log.error("can not found anyone by project_id [%s]" % user["project_id"])
        raise ParamsException("can not found anyone by project_id [%s]" % user["project_id"])
    send_mail_info = {
        "mail_host": email_obj.server_addr,
        "smtp_port": int(email_obj.server_port),
        "is_tls": email_obj.is_tls,
        "user_name": email_obj.user_name,
        "from_addr": email_obj.from_user_addr,
        "mail_pass": email_obj.user_pass,
        "to_addr": data["to_user_addrs"],
        "sub": data.get("sub") if data.get("sub") else EMAIL_SUBJECT,
        "content": data.get("content") if data.get("content") else EMAIL_CONTENT
    }

    log.debug("send params : %s" % json.dumps(send_mail_info))

    send_task('tasks.message.celery_send_mail', args=[send_mail_info], queue="gd_message")
    return {}
