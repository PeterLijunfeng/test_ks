import json
from time import time
from guardian.settings import cache
from guardian.settings import TOKEN_MAX_TIME
from guardian.settings import UCMP_ROLE_KIND_DEPT
from guardian.settings import KEYSTONE_DEFAULT_ROLE_NAME
from guardian.settings import INIT_ADMIN_NAME
from guardian.settings import LOGIN_DEFAULT_DOMAIN_NAME
from guardian.settings import UCMP_ROLE_KIND_ROOT
from guardian.settings import UCMP_ROLE_KIND_ADMIN
from guardian.settings import UCMP_ROLE_KIND_USER
from guardian.settings import CMDB_ROLE_KIND_ROOT
from guardian.settings import CMDB_ROLE_KIND_ADMIN
from guardian.settings import CMDB_ROLE_KIND_USER
from guardian.settings import ATOMFLOW_ROLE_KIND_ROOT
from guardian.settings import ATOMFLOW_ROLE_KIND_ADMIN
from guardian.settings import ATOMFLOW_ROLE_KIND_USER
from guardian.settings import GUARDIAN_ROLE_KIND_ROOT
from guardian.settings import GUARDIAN_ROLE_KIND_ADMIN
from guardian.settings import GUARDIAN_ROLE_KIND_USER
from guardian.utils.dates import time_to_timestamp, parse_execution_date
from guardian.apps.users.models import query_role_join_user, get_dept_user_by_org_id
from guardian.apps.users.models import get_user_by_org_id_and_role_id
from guardian.apps.users.models import get_user_by_org_id_and_role_data
from guardian.common.ucmp.ucmp_api import chk_resource_in_orgs
from guardian.common.keystone.role_mgt import create_role as keystone_create_role
from guardian.common.keystone.role_mgt import query_role_by_role_name as keystone_query_role
from guardian.common.keystone.role_mgt import assign_role_project as keystone_binding_role
from guardian.common.keystone.domain_mgt import list_domain as keystone_list_domain
from guardian.common.keystone.authentication import validate
from guardian.common.errors import AuthException
from guardian.common.errors import ReferenceException
from guardian.common.keystone.authentication import user_login_scope_project
from guardian.common.errors import ParamsException
from guardian.common.keystone.authentication import login_user_token
from guardian.log4 import app_logger as log
from guardian.apps.users.models import UsersModel
from guardian.apps.users.models import UsersOrgsModel
from guardian.apps.business.models import BusinessModel


def token_validate(token):
    cache_user = cache.get("Token_%s" % token)
    if cache_user:
        return json.loads(cache_user)
    token, token_info = validate(token)
    user = gen_user_from_token_and_make_cache(token, token_info)
    return user


def user_login(user, passwd, domain, user_id, project_id):
    token, token_info = login_user_token(user, passwd, domain, user_id, project_id)
    if token:
        user = gen_user_from_token_and_make_cache(token, token_info)
        return user.get('token')
    else:
        log.error('user login authenticate failed')
        return None


def login_scope_project(user_id, project_id, password):
    token, token_info = user_login_scope_project(user_id=user_id, password=password, project_id=project_id)
    if token:
        user = gen_user_from_token_and_make_cache(token, token_info)
        return user.get('token')
    else:
        log.error('user login failed')
        raise AuthException('user login failed')


def clear_user_token_relationcache(user_ids_list):
    for user_id in user_ids_list:
        cache_user_token_relation = cache.get("User_%s" % user_id)
        if cache_user_token_relation:
            tokens = json.loads(cache_user_token_relation)
            tokens_list = ["Token_%s" % token for token in tokens]
            tokens_tuple = tuple(tokens_list)
            cache.delete_many(*tokens_tuple)
            cache.delete("User_%s" % user_id)


def query_dept_role_users_by_org_id(org_id):
    # get org array
    org_array = []
    org_node_array = []
    org_obj = UsersOrgsModel(id=org_id).get_one()
    if org_obj.parent_code:
        org_node_array = org_obj.parent_code.split('-')
    org_node_array.append(org_obj.node_id)
    filters = {
        "node_ids": org_node_array
    }
    orgs = UsersOrgsModel.get_org_by_id_fuzzy_name_or_node_ids(**filters)
    for org in orgs:
        org_array.append(org.id)
    users_info = get_user_by_org_id_and_role_data(org_ids=org_array, role_data=UCMP_ROLE_KIND_DEPT)
    return users_info


def query_dept_role_users_by_local_org_id(org_id):
    users_info = get_dept_user_by_org_id(org_ids=org_id, role_data=UCMP_ROLE_KIND_DEPT)
    return users_info


def query_init_dept_role_users_by_org_id(org_id, role_id):
    # get org array
    org_array = []
    org_node_array = []
    org_obj = UsersOrgsModel(id=org_id).get_one()
    if org_obj.parent_code:
        org_node_array = org_obj.parent_code.split('-')
    org_node_array.append(org_obj.node_id)
    filters = {
        "node_ids": org_node_array
    }
    orgs = UsersOrgsModel.get_org_by_id_fuzzy_name_or_node_ids(**filters)
    for org in orgs:
        org_array.append(org.id)
    users_info = get_user_by_org_id_and_role_id(org_ids=org_array, role_id=role_id)
    # filter the nearest level org users
    if not users_info:
        log.error('No user with the role of department administrator was found')
        return []
    user_org_relation = {}
    user_org_ids = []
    for user in users_info:
        user_array = []
        user_org_ids.append(user.org_id)
        if user.org_id in user_org_relation.keys():
            user_org_relation[user.org_id].append(user)
            continue
        user_array.append(user)
        user_org_relation[user.org_id] = user_array
    # sort org by create time
    orgs_info = UsersOrgsModel.get_org_by_org_ids(org_ids=user_org_ids)
    nearest_level_org_users = user_org_relation.get(orgs_info[0].id)
    return nearest_level_org_users


def get_roles_by_user_id(user_id):
    roles_obj = query_role_join_user(user_id=user_id)
    obj_list = [dict(zip(result.keys(), result)) for result in roles_obj]
    role_info = {}
    for role_obj in obj_list:
        role_obj = role_obj.get('UserRolesModel').__dict__
        role = {'id': role_obj.get('id'),
                'name': role_obj.get('name'),
                'role_ctl': json.loads(role_obj.get('role_ctl')),
                'role_data': role_obj.get('role_data'),
                'comments': role_obj.get('comments')}
        role_info[role_obj.get('platform_name')] = role
    return role_info


def gen_user_from_token_and_make_cache(token, token_info):
    """
    {
        "token": {
            "methods": [
                "token"
            ],
            "roles":[
             {
                    "id": "5090055d6bd547dc83e0e8f070803708",
                    "name": "admin"
                }
            ],
            "expires_at": "2015-11-05T22:00:11.000000Z",
            "project": {
                "domain": {
                    "id": "default",
                    "name": "Default"
                },
                "id": "5b50efd009b540559104ee3c03bbb2b7",
                "name": "admin"
            },
            "is_domain": false,
            "catalog": [
                {
                    "endpoints": [
                        {
                            "region_id": "RegionOne",
                            "url": "http://23.253.248.171:9292",
                            "region": "RegionOne",
                            "interface": "admin",
                            "id": "b2605da9b25943beb49b2bd86aca2202"
                        }
                    ],
                    "type": "image",
                    "id": "495df2483dc145dbb6b34bfbdd787aae",
                    "name": "glance"
                }
            ],
            "user": {
                "domain": {
                    "id": "default",
                    "name": "Default"
                },
                "id": "10a2e6e717a245d9acad3e5f97aeca3d",
                "name": "admin",
                "password_expires_at": null
            },
            "audit_ids": [
                "mAjXQhiYRyKwkB4qygdLVg"
            ],
            "issued_at": "2015-11-05T21:00:33.819948Z"
            }
        }
    :param token_info:
    :return:
    """
    token_obj = token_info['token']
    userobj = token_obj.get("user", {})
    roles_obj = query_role_join_user(user_id=userobj.get('id'))
    obj_list = [dict(zip(result.keys(), result)) for result in roles_obj]
    role_info = {}
    for role_obj in obj_list:
        role_obj = role_obj.get('UserRolesModel').__dict__
        role = {'id': role_obj.get('id'),
                'name': role_obj.get('name'),
                'role_ctl': json.loads(role_obj.get('role_ctl')),
                'role_data': role_obj.get('role_data'),
                'comments': role_obj.get('comments')}
        role_info[role_obj.get('platform_name')] = role

    user = {
        "id": userobj.get('id'),
        "name": userobj.get('name', ''),
        "roles": role_info,
        "token": token,
        "project_id": token_obj['project']['id'],
        "project_name": token_obj['project']['name'],
        "domain_id": userobj['domain']['id'],
        "domain_name": userobj['domain']['name'],
        "token_expires_at": token_obj["expires_at"],
    }
    cache_timeout = time_to_timestamp(parse_execution_date(token_obj["expires_at"])) - int(time())
    if cache_timeout < 0:
        raise Exception('Please adjust keystone host time and UCMP host time')
    time_out = min(cache_timeout, TOKEN_MAX_TIME)
    cache.set("Token_%s" % token, json.dumps(user), timeout=time_out)
    # add user binding token relationship cache
    tokens = []
    cache_user_token_relation = cache.get("User_%s" % userobj.get('id'))
    if cache_user_token_relation:
        if token not in json.loads(cache_user_token_relation):
            tokens = json.loads(cache_user_token_relation)
            tokens.append(token)
            cache.set("User_%s" % userobj.get('id'), json.dumps(tokens),
                      timeout=time_out)
    else:
        tokens.append(token)
        cache.set("User_%s" % userobj.get('id'), json.dumps(tokens),
                  timeout=time_out)
    return user


def judge_user_referenece_org(org_id_list, **filters):
    """True: 组织机构下存在用户信息"""
    filters["org_id_list"] = org_id_list
    cnt, user_objs = UsersModel.get_list(**filters)
    if not cnt:
        return False, None
    else:
        user_names = []
        for user in user_objs:
            user_names.append(user.username)
        return True, user_names


def judge_business_referenece_org(org_id_list, **filters):
    """True: 组织机构下存在业务信息"""
    filters["org_ids"] = org_id_list
    cnt, business_objs = BusinessModel.get_list(**filters)
    if not cnt:
        return False, None
    else:
        business_names = []
        for business in business_objs:
            business_names.append(business.username)
        return True, business_names


def get_sub_org_ids(org_id, node_id, parent_code, **filter):
    id_list_obj = UsersOrgsModel.get_sub_orgs(node_id, parent_code, **filter)
    id_list = [org_id]
    for org in id_list_obj:
        id_list.append(org.id)
    return id_list


def get_sub_org_ids_batch(org_info_list, **filter):
    """
    org_info_list = [{
            "id": "",
            "node_id": "",
            "parent_code": ""
        },
        ...
    ]
    :param org_info_list:
    :param filter:
    :return:
    """
    id_list = []
    for org_info in org_info_list:
        id_list_obj = UsersOrgsModel.get_sub_orgs(org_info.get("node_id"), org_info.get("parent_code"), **filter)
        id_list.append(org_info.get("id"))
        for org in id_list_obj:
            id_list.append(org.id)
    return id_list


def delete_orgs(org_id, node_id, parent_code, token, **filters):
    org_id_list = get_sub_org_ids(org_id, node_id, parent_code, **filters)
    user_boolean, user_names = judge_user_referenece_org(org_id_list, **filters)
    business_boolean, business_names = judge_business_referenece_org(org_id_list, **filters)
    java_ucmp_count = chk_resource_in_orgs(token, org_id_list)

    if user_boolean:
        log.error("User reference exist: {0}".format(user_names))
        raise ReferenceException("User reference exist: {0}".format(user_names))
    elif business_boolean:
        log.error("Business reference exist: {0}".format(business_names))
        raise ReferenceException("Business reference exist: {0}".format(business_names))
    elif java_ucmp_count:
        log.error("Ucmp reference exist")
        raise ReferenceException("Ucmp reference exist Count:{0}".format(java_ucmp_count))
    else:
        id_list = UsersOrgsModel.del_org_patch(org_id_list)
    return id_list


def delete_orgs_patch(org_info_list, token, **filters):
    org_id_list = get_sub_org_ids_batch(org_info_list, **filters)
    user_boolean, user_names = judge_user_referenece_org(org_id_list, **filters)
    business_boolean, business_names = judge_business_referenece_org(org_id_list, **filters)
    java_ucmp_count = chk_resource_in_orgs(token, org_id_list)

    if user_boolean:
        log.error("User reference exist: {0}".format(user_names))
        raise ReferenceException("User reference exist: {0}".format(user_names))
    elif business_boolean:
        log.error("Business reference exist: {0}".format(business_names))
        raise ReferenceException("Business reference exist: {0}".format(business_names))
    elif java_ucmp_count:
        log.error("Ucmp reference exist")
        raise ReferenceException("Ucmp reference exist Count:{0}".format(java_ucmp_count))
    else:
        id_list = UsersOrgsModel.del_org_patch(org_id_list)
    return id_list


def build_sub_orgs(maxlevel, leaf_org_id_list, org_id_dict):
    all_parent_id_list = []
    new_leaf_list = leaf_org_id_list
    for i in range(maxlevel):
        for org_id in new_leaf_list:
            org_info = org_id_dict.get(org_id)
            parent_id = org_info.get("parent_id", "")
            if parent_id and parent_id in all_parent_id_list:
                sub_orgs = org_id_dict.get(parent_id).get("sub_orgs", [])
                sub_orgs.append(org_info)
                org_id_dict[parent_id]["sub_orgs"] = sub_orgs
            elif parent_id:
                all_parent_id_list.append(parent_id)
                new_leaf_list.append(parent_id)
                sub_orgs = org_id_dict.get(parent_id).get("sub_orgs", [])
                sub_orgs.append(org_info)
                org_id_dict[parent_id]["sub_orgs"] = sub_orgs
            else:
                continue
            new_leaf_list.remove(org_id)
    return org_id_dict


def get_org_info(project_id, parent_code_list, maxlevel, org_business_dict=None):
    filters = {
        "project_id": project_id,
        "node_ids": parent_code_list
    }
    orgs = UsersOrgsModel.get_org_by_id_fuzzy_name_or_node_ids(**filters)

    org_id_list = []
    org_parent_id_list = []
    root_id_list = []
    org_id_dict = dict()
    for org in orgs:
        org_id_list.append(org.id)
        org_id_dict[org.id] = {
            "id": org.id,
            "parent_id": org.parent_id if org.parent_id else "",
            "org_name": org.org_name,
            "sub_orgs": []
        }
        if org_business_dict and org_business_dict.get(org.id):
            org_id_dict[org.id]["business"] = org_business_dict.get(org.id)
        if org.parent_id:
            org_parent_id_list.append(org.parent_id)
        else:
            root_id_list.append(org.id)

    leaf_org_id_list = list(set(org_id_list) ^ set(org_parent_id_list))
    org_id_dict = build_sub_orgs(maxlevel, leaf_org_id_list, org_id_dict)

    org_list = []
    for root_id in root_id_list:
        org_list.append(org_id_dict.get(root_id))
    return org_list


def get_all_node_org_info(org_name, org_id, project_id):
    filters = {
        "project_id": project_id,
        "fuzzy_org_name": org_name,
        "org_id": org_id
    }
    fuzzy_org_objs = UsersOrgsModel.get_org_by_id_fuzzy_name_or_node_ids(**filters)
    if fuzzy_org_objs:
        maxlevel = 0
        parent_code_list = []
        for org_obj in fuzzy_org_objs:
            if org_obj.parent_code:
                parent_code_str = "%s-%s" % (org_obj.parent_code, org_obj.node_id)
            else:
                parent_code_str = "%s" % org_obj.node_id

            maxlevel = parent_code_str.count("-") + 1 if (parent_code_str.count("-") + 1) > maxlevel else maxlevel
            node_id_list = parent_code_str.split("-")
            node_id_list = list(map(int, node_id_list))
            parent_code_list = parent_code_list + node_id_list
        parent_code_list = list(set(parent_code_list))

        root_info_list = get_org_info(project_id, parent_code_list, maxlevel)
    else:
        root_info_list = []
    return root_info_list


def get_org_tree(project_id):
    filters = {
        "project_id": project_id
    }
    rst = UsersOrgsModel.get_org_id_name_by_project(**filters)
    if rst:
        maxlevel = 0
        parent_code_list = []
        for org_obj in rst:
            if org_obj.parent_code:
                parent_code_str = "%s-%s" % (org_obj.parent_code, org_obj.node_id)
            else:
                parent_code_str = "%s" % org_obj.node_id

            maxlevel = parent_code_str.count("-") + 1 if (parent_code_str.count("-") + 1) > maxlevel else maxlevel
            node_id_list = parent_code_str.split("-")
            node_id_list = list(map(int, node_id_list))
            parent_code_list = parent_code_list + node_id_list
        parent_code_list = list(set(parent_code_list))
        root_info_list = get_org_info(project_id, parent_code_list, maxlevel)
    else:
        root_info_list = []
    return root_info_list


def get_trees_org_business(project_id):
    filters = {
        "project_id": project_id
    }
    rst = UsersOrgsModel.get_org_id_name_by_project(**filters)
    busi_org_rst = BusinessModel.get_business_by_project(**filters)
    org_business_dict = {}
    for busi_id, busi_name, org_id in busi_org_rst:
        sub = org_business_dict.get(org_id, [])
        sub.append({
            "business_id": busi_id,
            "business_name": busi_name,
        })
        org_business_dict[org_id] = sub
    if rst:
        maxlevel = 0
        parent_code_list = []
        for org_obj in rst:
            if org_obj.parent_code:
                parent_code_str = "%s-%s" % (org_obj.parent_code, org_obj.node_id)
            else:
                parent_code_str = "%s" % org_obj.node_id

            maxlevel = parent_code_str.count("-") + 1 if (parent_code_str.count("-") + 1) > maxlevel else maxlevel
            node_id_list = parent_code_str.split("-")
            node_id_list = list(map(int, node_id_list))
            parent_code_list = parent_code_list + node_id_list
        parent_code_list = list(set(parent_code_list))
        root_info_list = get_org_info(project_id, parent_code_list, maxlevel, org_business_dict)
    else:
        root_info_list = []
    return root_info_list


def assign_role_project_to_superuser(project_id):
    # binding keystone default role in order to authentication token
    role_id = keystone_query_role(KEYSTONE_DEFAULT_ROLE_NAME)
    if role_id:
        role_id = role_id[0].get('id')
    else:
        role_id, name = keystone_create_role(KEYSTONE_DEFAULT_ROLE_NAME)

    data = keystone_list_domain()
    domain_list = data.get("domains")
    for domain in domain_list:
        if domain.get("name") == LOGIN_DEFAULT_DOMAIN_NAME:
            domain_id = domain.get("id")
            break
    else:
        raise ParamsException("can not found domian_id by domain name: {0}".format(LOGIN_DEFAULT_DOMAIN_NAME))
    user_obj = UsersModel.get_user_by_username_domain(INIT_ADMIN_NAME, domain_id)
    if not user_obj:
        raise ParamsException("can not found user_id by user_name: {0}".format(INIT_ADMIN_NAME))

    keystone_binding_role(project_id=project_id, userid=user_obj.user_id, roleid=role_id)


def judge_allow_role_list(user_role):
    allow_role_data_list = []
    role_data = {UCMP_ROLE_KIND_ROOT: [UCMP_ROLE_KIND_ADMIN, UCMP_ROLE_KIND_DEPT, UCMP_ROLE_KIND_USER],
                 UCMP_ROLE_KIND_ADMIN: [UCMP_ROLE_KIND_DEPT, UCMP_ROLE_KIND_USER],
                 UCMP_ROLE_KIND_DEPT: [UCMP_ROLE_KIND_USER],
                 UCMP_ROLE_KIND_USER: [],
                 CMDB_ROLE_KIND_ROOT: [CMDB_ROLE_KIND_ADMIN, CMDB_ROLE_KIND_USER],
                 CMDB_ROLE_KIND_ADMIN: [CMDB_ROLE_KIND_USER],
                 CMDB_ROLE_KIND_USER: [],
                 ATOMFLOW_ROLE_KIND_ROOT: [ATOMFLOW_ROLE_KIND_ADMIN, ATOMFLOW_ROLE_KIND_USER],
                 ATOMFLOW_ROLE_KIND_ADMIN: [ATOMFLOW_ROLE_KIND_USER],
                 ATOMFLOW_ROLE_KIND_USER: [],
                 GUARDIAN_ROLE_KIND_ROOT: [GUARDIAN_ROLE_KIND_ADMIN, GUARDIAN_ROLE_KIND_USER],
                 GUARDIAN_ROLE_KIND_ADMIN: [GUARDIAN_ROLE_KIND_USER],
                 GUARDIAN_ROLE_KIND_USER: []}
    for role in user_role.values():
        allow_role_data_list.extend(role_data[role.get('role_data')])
    return allow_role_data_list
