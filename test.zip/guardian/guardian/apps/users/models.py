import json
from sqlalchemy import Boolean, Column, Integer, String, desc, Text, or_
from guardian.settings import PLATFORM_UCMP
from guardian.utils.db import provide_session
from guardian.utils.db import UUID_LEN
from guardian.apps import CommonModel
from guardian.apps import BaseModel
from guardian.apps import DEL, N_DEL, ON, OFF


class UsersModel(BaseModel, CommonModel):
    __tablename__ = "users"

    user_id = Column(String(UUID_LEN), primary_key=True, index=True, nullable=False)
    default_project_id = Column(String(250), doc="默认租户ID,用于用户登录进入默认租户")
    user_code = Column(String(UUID_LEN), doc="用户工号")
    username = Column(String(50), doc="用户名")
    realname = Column(String(50), doc="真实姓名")
    email = Column(String(100), doc="邮箱")
    tel = Column(String(20), doc="电话")
    phone = Column(String(20), doc="手机")
    first_login = Column(Boolean, default=False, doc="首次登录")
    org_id = Column(String(40), doc="组织ID")
    org_name = Column(String(50), doc="组织名称")
    comments = Column(String(250), doc="备注")
    object_suid = Column(String(UUID_LEN), doc="第三方系统中的ID")
    domain_id = Column(String(70), doc="域ID")
    dn = Column(String(1000), doc="AD域用户信息")
    enable = Column(Integer, default=0, doc="可用")
    org_array = Column(Text, doc="组织列表")
    lower_username = Column(String(50), doc="小写用户名")

    def __init__(self, *args, **kwargs):
        super(UsersModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.user_id}>".format(self=self)

    @classmethod
    @provide_session
    def get_one(cls, user_id, session=None):
        qry = session.query(UsersModel)
        qry = qry.filter(cls.user_id == user_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_user_by_username_domain(cls, username, domain_id, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.username == username).filter(cls.domain_id == domain_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_user_by_email_domain(cls, email, domain_id, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.email == email).filter(cls.domain_id == domain_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_user_by_lower_username_domain(cls, username, domain_id, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.lower_username == username).filter(cls.domain_id == domain_id)
        return qry.first()

    @classmethod
    @provide_session
    def fuzzy_get_users_by_dn(cls, include_del=False, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.default_project_id == kwargs.get('project_id'))
        if kwargs.get('dn'):
            qry = qry.filter(cls.dn.endswith(kwargs.get('dn')))
        if kwargs.get('dn_list'):
            qry = qry.filter(cls.dn.in_(kwargs.get('dn_list')))
        if not include_del:
            qry = qry.filter(cls.enable == ON)
        return qry.order_by(desc(cls.create_at)).all()

    @classmethod
    @provide_session
    def get_one_user_join_org(cls, user_id, session=None):
        qry = session.query(cls, UsersOrgsModel)
        qry = qry.join(UsersOrgsModel, cls.org_id == UsersOrgsModel.id).filter(cls.user_id == user_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=100, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('user_id'):
            qry = qry.filter(cls.user_id == kwargs.get('user_id'))
        if kwargs.get('user_ids'):
            qry = qry.filter(cls.user_id.in_(kwargs.get('user_ids').split(',')))
        if kwargs.get('user_id_list'):
            qry = qry.filter(cls.user_id.in_(kwargs.get('user_id_list')))
        if kwargs.get('username') and kwargs.get('realname'):
            qry = qry.filter(or_(cls.username.like('%' + kwargs.get('username') + '%'),
                                 cls.realname.like('%' + kwargs.get('realname') + '%')))
        if kwargs.get('email'):
            qry = qry.filter(cls.email == kwargs.get('email'))
        if kwargs.get('tel'):
            qry = qry.filter(cls.tel == kwargs.get('tel'))
        if kwargs.get('phone'):
            qry = qry.filter(cls.phone == kwargs.get('phone'))
        if kwargs.get('org_id'):
            qry = qry.filter(cls.org_id == kwargs.get('org_id'))
        if kwargs.get('org_name'):
            qry = qry.filter(cls.org_name == kwargs.get('org_name'))
        if kwargs.get('org_ids'):
            qry = qry.filter(cls.org_id.in_(kwargs.get('org_ids').split(',')))
        if kwargs.get('org_id_list'):
            qry = qry.filter(cls.org_id.in_(kwargs.get('org_id_list')))
        if kwargs.get('domain_id'):
            qry = qry.filter(cls.domain_id == kwargs.get('domain_id'))
        if kwargs.get('object_suid'):
            qry = qry.filter(cls.object_suid == kwargs.get('object_suid'))
        if kwargs.get('enable'):
            qry = qry.filter(cls.enable == kwargs.get('enable'))
        if kwargs.get('default_project_id'):
            qry = qry.filter(cls.default_project_id == kwargs.get('default_project_id'))
        if kwargs.get('user_code'):
            qry = qry.filter(cls.user_code == kwargs.get('user_code'))
        res = qry.order_by(desc(UsersModel.create_at))
        qry = res.limit(limit).offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def create_user(cls, user_id, username, realname, email, tel, phone, org_id, org_name, domain_id, enable,
                    first_login,
                    comments, org_array, object_suid, dn, user_code, default_project_id, lower_name, session=None):

        user_obj = UsersModel(user_id=user_id,
                              username=username,
                              realname=realname,
                              email=email,
                              tel=tel,
                              phone=phone,
                              org_id=org_id,
                              domain_id=domain_id,
                              enable=enable,
                              first_login=first_login,
                              comments=comments,
                              org_array=json.dumps(org_array), object_suid=object_suid, dn=dn, user_code=user_code,
                              default_project_id=default_project_id, lower_username=lower_name, org_name=org_name)

        session.add(user_obj)
        session.commit()

    @classmethod
    @provide_session
    def create_user_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "user_id": data_info.get("user_id") if data_info.get("user_id") else cls().gen_uuid(),
                "default_project_id": data_info.get("default_project_id"),
                "user_code": data_info.get("user_code"),
                "username": data_info.get("username"),
                "realname": data_info.get("realname"),
                "email": data_info.get("email"),
                "tel": data_info.get("tel"),
                "phone": data_info.get("phone"),
                "first_login": data_info.get("first_login"),
                "org_id": data_info.get("org_id"),
                "comments": data_info.get("comments"),
                "object_suid": data_info.get("object_suid"),
                "domain_id": data_info.get("domain_id"),
                "dn": data_info.get("dn"),
                "enable": data_info.get("enable"),
                "org_array": json.dumps(data_info.get("org_array")),
                "lower_username": data_info.get("lower_username")
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def create_user_batch_update(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "user_id": data_info.get("user_id") if data_info.get("user_id") else cls().gen_uuid(),
                "default_project_id": data_info.get("default_project_id"),
                "user_code": data_info.get("user_code"),
                "username": data_info.get("username"),
                "realname": data_info.get("realname"),
                "email": data_info.get("email"),
                "tel": data_info.get("tel"),
                "phone": data_info.get("phone"),
                "first_login": data_info.get("first_login"),
                "org_id": data_info.get("org_id"),
                "comments": data_info.get("comments"),
                "object_suid": data_info.get("object_suid"),
                "domain_id": data_info.get("domain_id"),
                "dn": data_info.get("dn"),
                "enable": data_info.get("enable"),
                "org_array": json.dumps(data_info.get("org_array")),
                "lower_username": data_info.get("lower_username"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),

            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def update_user(cls, entry, session=None, **kwargs):
        can_edit = ["realname", "email", "tel",
                    "phone", "org_id", "org_name",
                    "enable", "first_login",
                    "comments", "org_array", "default_project_id"]
        for k, v in kwargs.get('kwargs').items():
            if k in can_edit and v is not None:
                setattr(entry, k, v)
        session.merge(entry)
        session.commit()

    @classmethod
    @provide_session
    def update_user_org_name_by_org_id(cls, org_id, org_name, session=None):
        qry = session.query(cls)
        users = qry.filter(cls.org_id == org_id).all()
        for user in users:
            user.org_name = org_name
        session.commit()

    @classmethod
    @provide_session
    def update_user_batch(cls, users_list, session=None, **kwargs):
        data_list = []
        can_edit = ["username", "realname", "email", "tel", "object_suid",
                    "phone", "org_id", "enable", "first_login", "lower_name",
                    "comments", "org_array", "default_project_id"]
        for data_info in users_list:
            msg_template_dict = dict()
            msg_template_dict["user_id"] = data_info.get("user_id")
            for k, v in data_info.items():
                if k in can_edit and v is not None:
                    msg_template_dict[k] = v
            data_list.append(msg_template_dict)
        session.bulk_update_mappings(cls, data_list)

    @provide_session
    def update_user_first_login(self, first_login=True, session=None):
        self.first_login = first_login
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def delete_user(cls, user_id, session=None):
        qry = session.query(UsersModel)
        user_info = qry.filter(cls.user_id == user_id).first()
        session.delete(user_info)
        session.commit()

    @classmethod
    @provide_session
    def delete_user_batch(cls, user_id_list, session=None):
        data_list = []
        for user_id in user_id_list:
            user_info_dict = dict()
            user_info_dict["user_id"] = user_id
            user_info_dict["enable"] = OFF
            data_list.append(user_info_dict)
        session.bulk_update_mappings(cls, data_list)


class UsersOrgsModel(BaseModel, CommonModel):
    __tablename__ = "users_orgs"

    id = Column(String(40), nullable=False, primary_key=True, index=True)
    org_name = Column(String(50), doc="组织名称")
    parent_id = Column(String(40), doc="父ID")
    project_id = Column(String(64), doc="租户ID")
    domain_id = Column(String(250), doc="域ID")
    object_uid = Column(String(250), doc="第三方系统的组织ID")
    dn = Column(String(250), doc="AD域信息")
    mgr_user_id = Column(Text, doc="组织负责人ids")
    node_id = Column(Integer, nullable=False, unique=True, doc="节点ID")
    parent_code = Column(String(100), nullable=False, doc="逐层节点ID")
    is_del = Column(Integer, default=N_DEL, doc="是否已删")

    def __init__(self, *args, **kwargs):
        super(UsersOrgsModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_org_by_name(cls, org_name, session=None):
        qry = session.query(UsersOrgsModel)
        qry = qry.filter(cls.org_name == org_name)
        return qry.first()

    @provide_session
    def get_one(self, session=None):
        qry = session.query(UsersOrgsModel)
        if self.id:
            qry = qry.filter(UsersOrgsModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_one_org_by_dn(cls, include_del=False, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('dn'):
            qry = qry.filter(cls.dn == kwargs.get('dn'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.order_by(desc(UsersOrgsModel.create_at)).first()

    @classmethod
    @provide_session
    def get_orgs_by_dn(cls, include_del=False, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('dn'):
            qry = qry.filter(cls.dn.endswith(kwargs.get('dn')))
        if kwargs.get('dn_list'):
            qry = qry.filter(cls.dn.in_(kwargs.get('dn_list')))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.order_by(desc(UsersOrgsModel.create_at)).all()

    @classmethod
    @provide_session
    def get_count(cls, include_del=False, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('org_name'):
            qry = qry.filter(cls.org_name == kwargs.get('org_name'))
        if "parent_id" in kwargs:
            qry = qry.filter(cls.parent_id == kwargs.get('parent_id'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.count()

    @classmethod
    @provide_session
    def get_org_by_id_fuzzy_name_or_node_ids(cls, include_del=False, session=None, **kwargs):
        """通过组织机构名称模糊匹配或者node_id列表查询"""
        qry = session.query(cls)
        if kwargs.get('fuzzy_org_name'):
            qry = qry.filter(cls.org_name.ilike("%{0}%".format(kwargs.get('fuzzy_org_name'))))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('org_id'):
            qry = qry.filter(cls.id == kwargs.get('org_id'))
        if kwargs.get('node_ids'):
            qry = qry.filter(cls.node_id.in_(kwargs.get('node_ids')))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.order_by(desc(UsersOrgsModel.create_at)).all()

    @classmethod
    @provide_session
    def get_org_by_org_ids(cls, org_ids, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.id.in_(org_ids))
        return qry.order_by(desc(UsersOrgsModel.create_at)).all()

    @classmethod
    @provide_session
    def get_org_id_name_by_project(cls, include_del=False, session=None, **kwargs):
        qry = session.query(cls.id, cls.parent_id, cls.org_name, cls.parent_code, cls.node_id)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.all()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=100, is_sort=True, include_del=False, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('ids'):
            qry = qry.filter(cls.id.in_(kwargs.get('ids').split(',')))
        if kwargs.get('org_name'):
            qry = qry.filter(cls.org_name == kwargs.get('org_name'))
        if "parent_id" in kwargs:
            qry = qry.filter(cls.parent_id == kwargs.get('parent_id'))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('domain_id'):
            qry = qry.filter(cls.domain_id == kwargs.get('domain_id'))
        if kwargs.get('object_uid'):
            qry = qry.filter(cls.object_uid == kwargs.get('object_uid'))
        if kwargs.get('dn'):
            qry = qry.filter(cls.dn == kwargs.get('dn'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        if is_sort:
            qry = qry.order_by(desc(UsersOrgsModel.create_at))
        return qry.count(), qry.limit(limit).offset((page_idx - 1) * limit).all()

    @classmethod
    @provide_session
    def get_max_node_id(cls, session=None, **kwargs):
        qry = session.query(cls)
        return qry.order_by(desc(UsersOrgsModel.node_id)).first()

    @classmethod
    @provide_session
    def get_sub_orgs(cls, parent_node_id, parent_parent_code, include_del=False, session=None, **kwargs):
        if parent_parent_code:
            parent_code = str(parent_parent_code) + "-" + str(parent_node_id) if parent_node_id else ""
        else:
            parent_code = str(parent_node_id) if parent_node_id else ""
        qry = session.query(cls)
        if parent_code:
            qry = qry.filter(cls.parent_code.startswith(parent_code))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.order_by(desc(UsersOrgsModel.create_at)).all()

    @classmethod
    @provide_session
    def create_org(cls, parent_parent_code, parent_node_id, session=None, **kwargs):
        entry = UsersOrgsModel()
        entry.id = kwargs.get("id") if kwargs.get("id") else cls().gen_uuid()
        if parent_parent_code:
            entry.parent_code = parent_parent_code + "-" + str(parent_node_id) if parent_node_id else ""
        else:
            entry.parent_code = str(parent_node_id) if parent_node_id else ""

        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v is not None:
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_org(self, session=None, **kwargs):
        can_edit = ["org_name", "sort_by"]
        for k, v in kwargs.items():
            if k in can_edit and v is not None:
                setattr(self, k, v)
        session.merge(self)
        session.commit()
        return self

    @classmethod
    @provide_session
    def update_org_batch(cls, data, session=None):
        data_list = []
        can_edit = ["org_name", "parent_id", "object_uid", "dn", "mgr_user_id", "node_id", "parent_code"]
        for data_info in data:
            msg_template_dict = dict()
            msg_template_dict["id"] = data_info.get("id")
            for k, v in data_info.items():
                if k in can_edit and v is not None:
                    msg_template_dict[k] = v
            data_list.append(msg_template_dict)
        session.bulk_update_mappings(cls, data_list)

    @classmethod
    @provide_session
    def del_org_patch(cls, id_list, session=None):
        data_list = []
        for org_id in id_list:
            org_dict = dict()
            org_dict["id"] = org_id
            org_dict["is_del"] = DEL
            data_list.append(org_dict)
        session.bulk_update_mappings(cls, data_list)
        return id_list

    @classmethod
    @provide_session
    def add_org_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "org_name": data_info.get("org_name"),
                "parent_id": data_info.get("parent_id"),
                "project_id": data_info.get("project_id"),
                "domain_id": data_info.get("domain_id"),
                "object_uid": data_info.get("object_uid"),
                "mgr_user_id": data_info.get("mgr_user_id"),
                "dn": data_info.get("dn"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
                "node_id": data_info.get("node_id"),
                "parent_code": data_info.get("parent_code"),
                "is_del": N_DEL,

            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class UserRolesModel(BaseModel, CommonModel):
    __tablename__ = "user_roles"

    id = Column(String(50), primary_key=True, nullable=False, index=True)
    name = Column(String(50), doc="角色名称")
    role_data = Column(String(20), doc="角色数据范围")
    role_ctl = Column(Text, doc="角色控制权限")
    comments = Column(String(250), doc="备注")
    project_id = Column(String(32), doc="租户id")
    platform_name = Column(String(20), doc="平台信息")

    def __init__(self, *args, **kwargs):
        super(UserRolesModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(UserRolesModel)
        qry = qry.filter(UserRolesModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_all(cls, role_ids, session=None):
        qry = session.query(UserRolesModel)
        qry = qry.filter(cls.id.in_(role_ids))
        return qry.all()

    @classmethod
    @provide_session
    def get_role_by_name(cls, role_name, session=None):
        qry = session.query(UserRolesModel)
        qry = qry.filter(cls.name == role_name)
        return qry.first()

    @classmethod
    @provide_session
    def filter_role_by_project(cls, project_id, role_ids, session=None):
        qry = session.query(UserRolesModel)
        qry = qry.filter(cls.id.in_(role_ids)).filter(cls.project_id == project_id)
        return qry.all()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=100, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('role_id_list'):
            qry = qry.filter(cls.id.in_(kwargs.get('role_id_list')))
        if kwargs.get('platforms'):
            qry = qry.filter(cls.platform_name.in_(kwargs.get('platforms')))
        if kwargs.get('project_id'):
            qry = qry.filter(or_(cls.project_id == kwargs.get('project_id'), cls.project_id.is_(None)))
        if kwargs.get('role_data_list'):
            qry = qry.filter(cls.role_data.in_(kwargs.get('role_data_list')))
        if kwargs.get('name'):
            qry = qry.filter(cls.name.like('%' + kwargs.get('name') + '%'))
        if kwargs.get('role_data_allow_list'):
            qry = qry.filter(cls.role_data.in_(kwargs.get('role_data_allow_list')))
        res = qry.order_by(desc(UserRolesModel.create_at))
        qry = res.limit(limit).offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @provide_session
    def create_role(self, role_data, session=None):
        role_obj = UserRolesModel(id=self.gen_uuid(),
                                  name=role_data.get("name"),
                                  role_ctl=json.dumps(role_data.get("role_ctl")),
                                  role_data=role_data.get("role_data"),
                                  comments=role_data.get("comments", ""),
                                  project_id=role_data.get("project_id", ""),
                                  platform_name=role_data.get("platform_name", PLATFORM_UCMP))
        session.add(role_obj)
        session.commit()
        return role_obj.id

    @classmethod
    @provide_session
    def create_role_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id") if data_info.get("id") else cls().gen_uuid(),
                "name": data_info.get("name"),
                "role_ctl": json.dumps(data_info.get("role_ctl")),
                "role_data": data_info.get("role_data"),
                "comments": data_info.get("comments"),
                "project_id": data_info.get("project_id"),
                "platform_name": data_info.get("platform_name", PLATFORM_UCMP)
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def add_create_role_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id") if data_info.get("id") else cls().gen_uuid(),
                "name": data_info.get("name"),
                "role_data": data_info.get("role_data"),
                "comments": data_info.get("comments"),
                "project_id": data_info.get("project_id"),
                "platform_name": data_info.get("platform_name"),
                "role_ctl": data_info.get("role_ctl")
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def update_role(cls, entry, session=None, **kwargs):
        can_edit = ["name",
                    "role_ctl", "role_data",
                    "comments"]
        for k, v in kwargs.get('kwargs').items():
            if k in can_edit and v is not None:
                setattr(entry, k, v)
        session.merge(entry)
        session.commit()

    @classmethod
    @provide_session
    def delete_role(cls, role_obj, session=None):
        session.delete(role_obj)
        session.commit()


class UserRoleRelationShip(BaseModel, CommonModel):
    __tablename__ = "user_role_relationship"

    id = Column(Integer, primary_key=True, nullable=False)
    user_id = Column(String(64), nullable=False, doc="用户id")
    role_id = Column(String(50), nullable=False, doc="角色id")
    comments = Column(String(250), doc="备注")

    def __init__(self, *args, **kwargs):
        super(UserRoleRelationShip, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_user_ids_join_role(cls, session=None, **kwargs):
        qry = session.query(cls, UserRolesModel) \
            .join(UserRolesModel, cls.role_id == UserRolesModel.id)
        if kwargs.get('role_datas'):
            qry = qry.filter(UserRolesModel.role_data.in_(kwargs.get('role_datas')))
        return qry.count(), qry.all()

    @classmethod
    @provide_session
    def get_relation_by_user_role_ids(cls, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get("user_id"):
            qry = qry.filter(cls.user_id == kwargs.get("user_id"))
        if kwargs.get("role_ids"):
            qry = qry.filter(cls.role_id.in_(kwargs.get("role_ids")))
        return qry.all()

    @classmethod
    @provide_session
    def delete_relation_by_role_id(cls, role_id, session=None):
        qry = session.query(cls)
        qry.filter(cls.role_id == role_id).delete()
        session.commit()

    @classmethod
    @provide_session
    def get_role_by_user(cls, user_id, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.user_id == user_id)
        return qry.all()

    @classmethod
    @provide_session
    def get_one_by_role_id(cls, role_id, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.role_id == role_id)
        return qry.all()

    @classmethod
    @provide_session
    def get_users_by_role_id(cls, role_id, org_id=None, session=None):
        qry = session.query(UserRoleRelationShip, UsersModel)
        qry = qry.join(UsersModel, UserRoleRelationShip.user_id == UsersModel.user_id).filter(
            UserRoleRelationShip.role_id == role_id)
        if org_id:
            qry = qry.filter(UsersModel.org_id == org_id)
        return qry.all()

    @classmethod
    @provide_session
    def add_relation(cls, user_id, role_ids, session=None):
        relation_data = []
        for role_id in role_ids:
            data = {"user_id": user_id,
                    "role_id": role_id}
            relation_data.append(data)
        session.execute(
            UserRoleRelationShip.__table__.insert(),
            relation_data
        )
        session.commit()

    @classmethod
    @provide_session
    def delete_relation(cls, user_id, role_ids, session=None):
        qry = session.query(cls)
        qry.filter(cls.user_id == user_id).filter(cls.role_id.in_(role_ids)).delete(synchronize_session=False)
        session.commit()

    @classmethod
    @provide_session
    def create_role_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "user_id": data_info.get("user_id"),
                "role_id": data_info.get("id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class UserRolePermissionModel(BaseModel, CommonModel):
    __tablename__ = "user_role_permission"

    id = Column(String(50), primary_key=True, nullable=False, index=True)
    role_id = Column(String(50), nullable=False, doc="角色id")
    module_id = Column(String(50), doc="模块id")
    menu_id = Column(String(50), doc="菜单id")

    def __init__(self, *args, **kwargs):
        super(UserRolePermissionModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(UserRolePermissionModel)
        if self.id:
            qry = qry.filter(UserRolePermissionModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def create_menu_premission(cls, relation_data, session=None):
        session.execute(
            UserRolePermissionModel.__table__.insert(),
            relation_data
        )
        session.commit()

    @classmethod
    @provide_session
    def update_menu_premission(cls, role_id, relation_data, session=None):
        qry = session.query(UserRolePermissionModel)
        qry.filter(UserRolePermissionModel.role_id == role_id).delete()
        if relation_data:
            session.execute(
                UserRolePermissionModel.__table__.insert(),
                relation_data
            )
        session.commit()

    @classmethod
    @provide_session
    def delete_menu_preemission_by_role(cls, role_id, session=None):
        qry = session.query(UserRolePermissionModel)
        qry.filter(UserRolePermissionModel.role_id == role_id).delete()
        session.commit()

    @classmethod
    @provide_session
    def create_role_permission_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": cls().gen_uuid(),
                "role_id": data_info.get("role_id"),
                "menu_id": data_info.get("menu_id"),
                "module_id": data_info.get("module_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


@provide_session
def query_role_join_user(session=None, user_id=None):
    qry = session.query(UserRoleRelationShip, UserRolesModel)
    data = qry.join(UserRolesModel, UserRolesModel.id == UserRoleRelationShip.role_id).filter(
        UserRoleRelationShip.user_id == user_id).all()
    return data


@provide_session
def get_menu_by_user_id(user_id, session=None):
    qry = session.query(UserRolePermissionModel)
    qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.role_id == UserRolePermissionModel.role_id).filter(
        UserRoleRelationShip.user_id == user_id)
    return qry.all()


@provide_session
def get_users_by_role_data(role_data, project_id=None, session=None):
    qry = session.query(UsersModel)
    if project_id:
        qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.user_id == UsersModel.user_id). \
            join(UserRolesModel, UserRoleRelationShip.role_id == UserRolesModel.id).filter(
            UserRolesModel.role_data == role_data).filter(UsersModel.default_project_id == project_id)
    else:
        qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.user_id == UsersModel.user_id). \
            join(UserRolesModel, UserRoleRelationShip.role_id == UserRolesModel.id).filter(
            UserRolesModel.role_data == role_data)
    return qry.all()


@provide_session
def get_user_by_org_id_and_role_data(org_ids, role_data, session=None):
    qry = session.query(UsersModel)
    qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.user_id == UsersModel.user_id). \
        join(UserRolesModel, UserRoleRelationShip.role_id == UserRolesModel.id).filter(
        UsersModel.org_id.in_(org_ids)).filter(UserRolesModel.role_data == role_data)
    return qry.all()


@provide_session
def get_dept_user_by_org_id(org_ids, role_data, session=None):
    qry = session.query(UsersModel)
    qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.user_id == UsersModel.user_id). \
        join(UserRolesModel, UserRoleRelationShip.role_id == UserRolesModel.id).filter(
        UsersModel.org_id == org_ids).filter(UserRolesModel.role_data == role_data)
    return qry.all()


@provide_session
def get_user_by_org_id_and_role_id(org_ids, role_id, session=None):
    qry = session.query(UsersModel)
    qry = qry.join(UserRoleRelationShip, UserRoleRelationShip.user_id == UsersModel.user_id) \
        .filter(UsersModel.org_id.in_(org_ids)).filter(UserRoleRelationShip.role_id == role_id)
    return qry.all()
