import os
import json
from flask import request
from flask import Blueprint
from flask import send_file
from celery.execute import send_task
from guardian.log4 import app_logger as log
from guardian.settings import APIBASEURL
from guardian.settings import FILE_UPLOAD_PATH
from guardian.settings import STATIC_PATH
from guardian.settings import PLATFORM_UCMP
from guardian.settings import PLATFORM_CMDB
from guardian.settings import PLATFORM_ATOMFLOW
from guardian.settings import PLATFORM_APPCEMTER
from guardian.settings import PLATFORM_GUARDIAN
from guardian.utils.uuid_util import gen_uuid
from guardian.common.rest import restful
from guardian.common.errors import ApiException
from guardian.common.errors import ParamsException
from guardian.common.errors import DBHandleException
from guardian.common.errors import UcmpHandleException
from guardian.common.errors import FileHandleException
from guardian.common.ldap_domain.myldap import ldap_conn
from guardian.apps import LDAP_SERVER_PORT, N_SSL, IS_SSL
from guardian.apps import DOING, SYNC_USER, SYNC_ORG, ON, OFF
from guardian.apps import SUCCESS, FAILED, IS_PUBLIC, N_PUBLIC
from guardian.apps import SYNC_NOT_ORG, SYNC_ORG_DOING, SYNC_ORG_FAILED
from guardian.apps.sys_config.models import SysInfoConfModel
from guardian.apps.sys_config.models import LicenseModel
from guardian.apps.sys_config.models import SysModuleModel
from guardian.apps.sys_config.models import SysMenuModel
from guardian.apps.sys_config.models import LdapConfigModel
from guardian.apps.sys_config.models import SyncLdapStatusModel
from guardian.apps.sys_config.services import check_license_by_hacksaw
from guardian.apps.sys_config.services import get_menu_by_role_ids
from guardian.apps.sys_config.services import get_roles_by_user_project
from guardian.apps.sys_config.services import reset_keystone_basedn
from guardian.apps.sys_config.services import get_conf_file
from guardian.apps.sys_config.models import get_menu_by_platform

sys_config_site = Blueprint('sys_config', __name__, url_prefix="%s/sys" % APIBASEURL)


@sys_config_site.route('/file', methods=['POST'])
@restful
def upload_file(*args, **kwargs):
    """
    :param args: file
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'name': '0e042208589c4660a06d94340d08e52a.png',
            'url': '/gd_static/89eb5337a17d49098951a9b09e6a7e83.png',  # logo static url
        }
    }
    """
    if 'file' not in request.files:
        log.error("can not found [file] key in request body")
        raise ParamsException("can not found [file] key in request body")
    file = request.files['file']
    filename = file.filename
    if filename == '':
        log.error("file body not found in request body")
        raise ParamsException("file body not found in request body")
    file_ex = filename.rsplit('.', 1)[1].lower()
    if '.' not in filename or file_ex not in ["png", "jpg", "jpeg", "gif"]:
        log.error("not support file type [%s]" % filename.rsplit('.', 1)[1].lower())
        raise ParamsException("not support file type [%s]" % filename.rsplit('.', 1)[1].lower())
    rename_file = "%s.%s" % (gen_uuid(), file_ex)
    file.save(os.path.join(FILE_UPLOAD_PATH, rename_file))
    return {
        "name": rename_file,
        "url": rename_file
    }


@sys_config_site.route('/logo/<img_name>', methods=['GET'])
def get_logo(img_name, *args, **kwargs):
    """
    http://192.168.3.127:9090/gd/v2/sys/logo/49a74bb173e64f97a0860c35d4c2caa2.png
    :param args:
    :param kwargs:
    :return:
    """
    file_path = os.path.join(FILE_UPLOAD_PATH, img_name)
    return send_file(file_path)


@sys_config_site.route('/conf', methods=['GET'])
@restful
def get_system_conf(*args, **kwargs):
    """
    API OPEN, no project_id
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'copyright': 'Copyright©2018',
            'sys_logo': '/gd_static/89eb5337a17d49098951a9b09e6a7e83.png',  # logo static url
            'log_delete_time': '10',
            'surport_tel': '400-000-0000',
            'surport_mail': 'support@domain.com',
            'session_expire': 30,
            'sys_name': 'IT运营管理中',
            'version': "V3.0",
            'id': 'f715c4a59d7d4afea69434117d318853',
            'case_sensitive': 1,
            'license_expire': 10
        }
    }
    """
    sys_conf = SysInfoConfModel.get_conf_by_project_id()
    if sys_conf:
        return {
            "id": sys_conf.id,
            "sys_logo": sys_conf.sys_logo,
            "sys_name": sys_conf.sys_name,
            "version": sys_conf.version,
            "copyright": sys_conf.copyright,
            "surport_mail": sys_conf.surport_mail,
            "surport_tel": sys_conf.surport_tel,
            "log_delete_time": sys_conf.log_delete_time,
            "session_expire": sys_conf.session_expire,
            "case_sensitive": sys_conf.case_sensitive,
            "license_expire": sys_conf.license_expire,
            "project_id": sys_conf.project_id
        }
    else:
        return {}


@sys_config_site.route('/conf/save', methods=['POST'])
@restful
def edit_system_conf(*args, **kwargs):
    """
    {
        "copyright": "Copyright©2018",
        "log_delete_time": "10",
        "session_expire": 30,
        "surport_mail": "support@domain.com",
        "surport_tel": "400-000-0000",
        "sys_logo": "/gd_static/89eb5337a17d49098951a9b09e6a7e83.png",  # logo static url
        "sys_name": "IT运营管理中",
        "version": "V3.0",
        "case_sensitive": 1,  # 只接收 0 不区分， 1 区分
        "license_expire": 10
    }
    :param args:
    :param kwargs:
    :return:
    """
    enable_edit = ["sys_logo", "sys_name", "version", "copyright", "surport_mail", "surport_tel",
                   "log_delete_time", "session_expire", "case_sensitive", "license_expire"]
    data = request.get_json()
    if "case_sensitive" in data and data.get("case_sensitive") not in [ON, OFF]:
        raise ParamsException("'case_sensitive' maybe missing")
    user = kwargs.get("user")
    project_id = user["project_id"]
    filters = {
        "project_id": user["project_id"]
    }
    sys_conf = SysInfoConfModel().get_conf_by_project_id(**filters)
    if sys_conf:
        for k, v in data.items():
            if k in enable_edit and v is not None:
                setattr(sys_conf, k, v)
        conf_id = sys_conf.update_item()
    else:
        sys_conf = SysInfoConfModel()
        for k, v in data.items():
            if k in enable_edit and v is not None:
                setattr(sys_conf, k, v)
        sys_conf.project_id = project_id
        conf_id = sys_conf.add_item()

    return {
        "id": conf_id,
        "copyright": sys_conf.copyright,
        "log_delete_time": sys_conf.log_delete_time,
        "session_expire": sys_conf.session_expire,
        "surport_mail": sys_conf.surport_mail,
        "surport_tel": sys_conf.surport_tel,
        "sys_logo": sys_conf.sys_logo,
        "sys_name": sys_conf.sys_name,
        "version": sys_conf.version,
        "case_sensitive": sys_conf.case_sensitive,
        "license_expire": sys_conf.license_expire
    }


@sys_config_site.route('/license', methods=['GET'])
@restful
def get_license(*args, **kwargs):
    """
    :param args: module_id
    :param kwargs:
    :return:
    存在
    {
        'rst': 'ok',
        'data': {
            'version': '普通版',
            'authObject': 'test',
            'status': 'invalid',
            'authItem': [
                {'type': '物理机CPU核数', 'status': 'active', 'total': '100000', 'left': '99908', 'unit': '核', 'message': ''},
                {'type': '有效截止日期', 'status': 'invalid', 'total': '2019-01-27', 'left': '0', 'unit': '天', 'message': '已过期'}
            ]
        }
    }
    不存在 返回 {}
    """
    module_id = request.args.get('module_id')
    if not module_id:
        log.error("[module_id] maybe missing!")
        raise ParamsException("need app_id")
    user = kwargs.get("user")
    # project_id = user["project_id"]
    license_model = LicenseModel.get_one_by_module_id(module_id)
    if license_model:
        license_data = license_model.license_data
        if not license_data:
            raise DBHandleException('get license failed, module_id :[%s]' % str(module_id))
        token = user["token"]
        license_info, state = check_license_by_hacksaw(license_data, token)
        if not license_info:
            raise UcmpHandleException('check license failed')
        update_license = {'license_info': json.dumps(license_info, ensure_ascii=False), 'status': state}
        license_model.update_license_file(**update_license)
        return license_info
    else:
        log.error("Can not found license by module_id [%s]" % str(module_id))
        return {}


@sys_config_site.route('/license', methods=['POST'])
@restful
def upload_license(*args, **kwargs):
    """
    files: file
    'file': ('1550565606.lic', open('/home/peter/Desktop/1550565606.lic', 'rb'))
    :param args: module_id
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'version': '普通版',
            'authObject': 'test',
            'status': 'invalid',
            'authItem': [
                {'type': '物理机CPU核数', 'status': 'active', 'total': '100000', 'left': '99908', 'unit': '核', 'message': ''},
                {'type': '有效截止日期', 'status': 'invalid', 'total': '2019-01-27', 'left': '0', 'unit': '天', 'message': '已过期'}
            ]
        }
    }
    """
    request_json = request.form
    if 'module_id' not in request_json:
        log.error("can not found [module_id] key in request body")
        raise ParamsException("can not found [module_id] key in request body")
    module_id = request_json['module_id']
    if 'file' not in request.files:
        log.error("can not found [file] key in request body")
        raise ParamsException("can not found [file] key in request body")
    file = request.files['file']
    filename = file.filename
    if filename == '':
        log.error("file body not found in request body")
        raise ParamsException("file body not found in request body")
    file_ex = filename.rsplit('.', 1)[1].lower()
    if file_ex != 'lic':
        raise FileHandleException("suffix is not .lic")
    data = file.read()
    user = kwargs.get("user")
    token = user["token"]
    project_id = user["project_id"]
    license_info, state = check_license_by_hacksaw(data, token)
    if not license_info:
        raise UcmpHandleException('check license failed')
    LicenseModel.upload_license_file(module_id, data, license_info, state, project_id)
    return license_info


@sys_config_site.route('/modules', methods=['GET'])
@restful
def get_modules(*args, **kwargs):
    """
    获取用户的module信息
    :param args: project_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": [
            {
                "id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                "module_name": "企业通用云管理平台",
                "description": null,
                "module_url": "ucmp",
                "sortby": 0,
                "remote_url": null
            },
            {
                "id": "960a89cc-044f-4233-ad7e-50c14a290071",
                "module_name": "主动式配置管理数据库平台",
                "description": null,
                "module_url": "cmdb",
                "sortby": 7,
                "remote_url": null
            }
            ...
        ]
    }
    """
    user_id = kwargs.get("user").get("id")
    module_id_list = get_roles_by_user_project(user_id)
    not_public_filters = {
        "is_public": N_PUBLIC,
    }
    count, no_public_arr = SysModuleModel.get_list(**not_public_filters)
    is_public_filters = {
        "is_public": IS_PUBLIC,
    }
    count, is_public_arr = SysModuleModel.get_list(**is_public_filters)
    modules = []
    for module in no_public_arr:
        if module.id in module_id_list:
            modules.append({
                'id': module.id,
                'module_name': module.module_name,
                'description': module.description,
                'module_url': module.module_url,
                'sortby': module.sortby,
                'remote_url': module.remote_url
            })
    for module in is_public_arr:
        modules.append({
            'id': module.id,
            'module_name': module.module_name,
            'description': module.description,
            'module_url': module.module_url,
            'sortby': module.sortby,
            'remote_url': module.remote_url
        })
    modules.sort(key=lambda k: (k.get('sortby', 0)), reverse=True)
    return modules


@sys_config_site.route('/menus', methods=['GET'])
@restful
def get_menus(*args, **kwargs):
    get_platform = request.args.get('platform')
    platform = list()
    platform.append(get_platform)
    if not get_platform:
        platform = [PLATFORM_UCMP, PLATFORM_CMDB, PLATFORM_ATOMFLOW, PLATFORM_APPCEMTER, PLATFORM_GUARDIAN]
    count, menus = get_menu_by_platform(platform=platform)
    map_menus = dict()
    arr_menus = []
    for menu in menus:
        if menu.parent_id is not None:
            sub_menus = map_menus.get(menu.parent_id, [])
            obj = {
                'id': menu.id,
                'title': menu.title,
                'parent_id': menu.parent_id,
                'url': menu.url,
                'sys_module_id': menu.sys_module_id,
                'icon': menu.icon,
                'sortby': menu.sortby,
            }
            sub_menus.append(obj)
            map_menus[menu.parent_id] = sub_menus
        else:
            arr_menus.append({
                'id': menu.id,
                'title': menu.title,
                'parent_id': menu.parent_id,
                'url': menu.url,
                'sys_module_id': menu.sys_module_id,
                'icon': menu.icon,
                'sortby': menu.sortby,
                'subMenus': [],
            })
    for menu in arr_menus:
        menu["subMenus"] = map_menus.get(menu["id"], [])
    return arr_menus


@sys_config_site.route('/role/menus', methods=['GET'])
@restful
def get_role_asigned_menus(*args, **kwargs):
    """
    role_id
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": [
            {
                "id": "aa562131-7545-4350-bc46-67c6ab6ea042",
                "title": "云厂商容量概况",
                "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                "url": "resource_overview",
                "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                "icon": "ucmp-icon-sys_menu-statistic-analysis",
                "sortby": 360
            },
            {
                "id": "673e57e2-b43e-47c3-9150-a519d1b30ac8",
                "title": "云厂商资源概况",
                "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                "url": "provider_resource",
                "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                "icon": "ucmp-icon-capacity-mgmt",
                "sortby": 359
            }
        ]
    }
    """
    role_id = request.args.get('role_id')
    if not role_id:
        raise ParamsException("'role_id' maybe missing")
    filters = {
        "role_ids": [role_id]
    }
    menus = SysMenuModel.get_menu_info_by_role_ids(**filters)
    arr_menus = []
    for menu in menus:
        obj = {
            'id': menu.id,
            'title': menu.title,
            'parent_id': menu.parent_id,
            'url': menu.url,
            'sys_module_id': menu.sys_module_id,
            'icon': menu.icon,
            'sortby': menu.sortby,
        }
        arr_menus.append(obj)
    return arr_menus


@sys_config_site.route('/user/menus', methods=['GET'])
@restful
def get_user_menus(*args, **kwargs):
    """

        :param args:
        :param kwargs:
        :return:
        {
            "rst": "ok",
            "data": [
                {
                    "id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                    "title": "总览",
                    "parent_id": null,
                    "url": "dashboard",
                    "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                    "icon": "ucmp-icon-sys_menu-dashboard",
                    "sortby": 350,
                    "subMenus": [
                        {
                            "id": "aa562131-7545-4350-bc46-67c6ab6ea042",
                            "title": "云厂商容量概况",
                            "parent_id": "a7a053ba-2473-49be-8e94-9826a24b484b",
                            "url": "resource_overview",
                            "sys_module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                            "icon": "ucmp-icon-sys_menu-statistic-analysis",
                            "sortby": 360
                        }
                    ]
                }
            ]
        }
        """
    user_id = kwargs.get("user").get('id')
    menu_info_list = get_menu_by_role_ids(user_id)
    return menu_info_list


@sys_config_site.route('/ldap', methods=['POST'])
@restful
def create_update_ldap_conf(*args, **kwargs):
    """
    {
        "id": "",
        "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
        "server_addr": "192.168.3.116",
        "server_port": 389,
        "is_ssl": 0,
        "user_name": "Administrator@leaptocloud.com",
        "user_pass": "1qaz@WSX",
        "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com",
        "is_update": 0
    }
    :return:
    """
    data = request.get_json()
    must_params = ["server_addr", "user_name", "user_pass", "base_dn", "is_update"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            log.error("params '{0}' maybe missing".format(item))
            raise ParamsException("params '{0}' maybe missing".format(item))

    if "server_port" not in data or data.get("server_port") == "":
        log.info("params [server_port] not in request data or is ''")
        data["server_port"] = LDAP_SERVER_PORT
    elif not isinstance(data.get("server_port"), int):
        log.error("params 'server_port' must be Type Integer")
        raise ParamsException("params 'server_port' must be Type Integer")

    if "is_ssl" not in data:
        log.info("params [is_ssl] not in request data")
        data["is_ssl"] = N_SSL
    elif data.get("is_ssl") not in [IS_SSL, N_SSL]:
        log.error("params 'is_ssl' must be {0} or {1}".format(N_SSL, IS_SSL))
        raise ParamsException("params 'is_ssl' must be {0} or {1}".format(N_SSL, IS_SSL))

    user = kwargs.get("user")
    project_id = user["project_id"]
    if "id" in data and data.get("id") != "":
        ldap_conf_id = data.get("id")
        ldap_obj = LdapConfigModel(id=ldap_conf_id).get_one()
        if not ldap_obj:
            log.info("can not found anyone by id [%s]" % ldap_conf_id)
            raise ParamsException("can not found anyone by id [%s]" % ldap_conf_id)
        ldap_obj.update_ldap_conf(**data)
    else:
        data["project_id"] = project_id
        ldap_obj = LdapConfigModel.add_ldap_conf(**data)
    server_addr = data.get("server_addr")
    user_name = data.get("user_name")
    user_pass = data.get("user_pass")
    base_dn = data.get("base_dn")
    conf_file = get_conf_file(base_dn, server_addr, user_name, user_pass)
    if not conf_file:
        raise ApiException("get_conf_file failed")
    if data.get("is_update"):
        reset_keystone_basedn(ldap_obj, base_dn, conf_file)

    return {
        "id": ldap_obj.id
    }


@sys_config_site.route('/ldap', methods=['GET'])
@restful
def get_ldap_conf(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
        "id": "",
        "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
        "server_addr": "192.168.3.116",
        "server_port": 389,
        "is_ssl": 0,
        "user_name": "Administrator@leaptocloud.com",
        "user_pass": "1qaz@WSX",
        "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
    }
    """
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"]
    }
    ldap_obj = LdapConfigModel().get_ldap_info_by_project_id(**filters)
    if not ldap_obj:
        return {
            "id": "",
            "project_id": user["project_id"],
            "server_addr": "",
            "server_port": LDAP_SERVER_PORT,
            "is_ssl": N_SSL,
            "user_name": "",
            "user_pass": "",
            "base_dn": ""
        }
    return {
        "id": ldap_obj.id,
        "project_id": ldap_obj.project_id,
        "server_addr": ldap_obj.server_addr,
        "server_port": ldap_obj.server_port,
        "is_ssl": ldap_obj.is_ssl,
        "user_name": ldap_obj.user_name,
        "user_pass": ldap_obj.user_pass,
        "base_dn": ldap_obj.base_dn
    }


@sys_config_site.route('/ldap/test', methods=['POST'])
@restful
def test_ldap_conf(*args, **kwargs):
    """
    {
        "id": "",
        "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
        "server_addr": "192.168.3.116",
        "server_port": 389,
        "is_ssl": 0,
        "user_name": "Administrator@leaptocloud.com",
        "user_pass": "1qaz@WSX",
        "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
    }
    :param args:
    :param kwargs:
    :return:
    """
    data = request.get_json()
    must_params = ["server_addr", "server_port", "user_name", "user_pass"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            log.error("params '{0}' maybe missing".format(item))
            raise ParamsException("params '{0}' maybe missing".format(item))
    if not isinstance(data.get("server_port"), int):
        log.error("params 'server_port' must be Type Integer")
        raise ParamsException("params 'server_port' must be Type Integer")

    conn = ldap_conn(server_addr=data.get("server_addr"),
                     server_port=int(data.get("server_port")),
                     user=data.get("user_name"),
                     password=data.get("user_pass"))
    if conn:
        log.info("connect ldap server succeful.")
        return {"code": SUCCESS}
    else:
        log.error("Error connect ldap server failed !!!")
        return {"code": FAILED}


@sys_config_site.route('/sync/user', methods=['POST'])
@restful
def sync_ad_users(*args, **kwargs):
    """
    {
        "base_dn":"OU=西安测试中心,DC=leaptocloud,DC=com"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "sync_status": 0
        }
    }
    """
    data = request.get_json()
    if "base_dn" not in data or data.get("base_dn") == "":
        raise ParamsException("'base_dn' maybe missing")
    base_dn = data.get("base_dn")
    user = kwargs.get("user")
    project_id = user["project_id"]
    domain_id = user["domain_id"]
    user_name = user["name"]

    # 判断同步组织机构的状态
    filters = {
        "project_id": project_id,
        "base_dn": base_dn,
        "sync_info": SYNC_ORG
    }
    ldap_org_status = SyncLdapStatusModel.get_latest_create_one(**filters)
    if not ldap_org_status:
        return {
            "sync_status": SYNC_NOT_ORG  # 组织机构没有进行过
        }
    elif ldap_org_status.sync_status == DOING:
        return {
            "sync_status": SYNC_ORG_DOING  # 组织机构正在同步中
        }
    elif ldap_org_status.sync_status == FAILED:
        return {
            "sync_status": SYNC_ORG_FAILED  # 组织机构同步失败
        }
    elif ldap_org_status.sync_status == SUCCESS:  # 组织机构同步成功
        # 同步用户信息
        data = {
            "project_id": project_id,
            "base_dn": base_dn,
            "sync_info": SYNC_USER
        }
        ldap_status = SyncLdapStatusModel.get_latest_create_one(**data)
        if not ldap_status or ldap_status.sync_status != DOING:
            data["sync_by"] = user_name
            ldap_status = SyncLdapStatusModel.add_sync_ldap_status(**data)
            log.info("sync user params : 'base_dn' {0} 'project_id' {1}  'domain_id' {2}"
                     .format(base_dn, project_id, domain_id))
            send_task('tasks.auth.celery_sync_users', args=[base_dn, project_id, domain_id, ldap_status],
                      queue="gd_auth")
            return {
                "sync_status": ldap_status.sync_status
            }
        else:
            return {
                "sync_status": ldap_status.sync_status
            }


@sys_config_site.route('/sync/org', methods=['POST'])
@restful
def sync_ad_orgs(*args, **kwargs):
    """
    {
        "base_dn":"OU=西安测试中心,DC=leaptocloud,DC=com"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "sync_status": 2
        }
    }
    """
    data = request.get_json()
    if "base_dn" not in data or data.get("base_dn") == "":
        raise ParamsException("'base_dn' maybe missing")
    base_dn = data.get("base_dn")

    user = kwargs.get("user")
    project_id = user["project_id"]
    domain_id = user["domain_id"]
    user_name = user["name"]
    token = user["token"]
    data = {
        "project_id": project_id,
        "base_dn": base_dn,
        "sync_info": SYNC_ORG
    }
    ldap_status = SyncLdapStatusModel.get_latest_create_one(**data)
    if not ldap_status or ldap_status.sync_status != DOING:
        data["sync_by"] = user_name
        ldap_status = SyncLdapStatusModel.add_sync_ldap_status(**data)
        log.info("sync org params > 'basedn':'{0}' 'project_id':'{1}' 'domain_id':'{2}'"
                 .format(base_dn, project_id, domain_id))
        send_task('tasks.ldap.celery_sync_orgs', args=[base_dn, project_id, domain_id, token, ldap_status],
                  queue="gd_ldap")
        return {
            "sync_status": ldap_status.sync_status
        }
    else:
        return {
            "sync_status": ldap_status.sync_status
        }
