# -*- coding: utf-8 -*-

import os
from setuptools import setup, find_packages, Command


class CleanCommand(Command):
    """Custom clean command to tidy up the project root."""
    user_options = []

    def initialize_options(self):
        pass

    def finalize_options(self):
        pass

    def run(self):
        os.system('rm -vrf ./build ./dist ./*.pyc ./*.tgz ./*.egg-info')


def do_setup():
    setup(
        name='guardian',
        description='',
        license='Apache License 2.0',
        version='0.1.2',
        packages=find_packages(exclude=['tests*']),
        include_package_data=True,
        zip_safe=False,
        scripts=['guardian/bin/guardian'],
        install_requires=[
            'aiohttp==3.5.2',
            'alembic==1.0.5',
            'amqp==2.3.2',
            'asn1crypto==0.24.0',
            'async-timeout==3.0.1',
            'attrs==18.2.0',
            'bcrypt==3.1.6',
            'billiard==3.5.0.5',
            'celery==4.2.1',
            'certifi==2018.11.29',
            'cffi==1.12.2',
            'chardet==3.0.4',
            'Click==7.0',
            'croniter==0.3.28',
            'cryptography==2.6.1',
            'docutils==0.14',
            'Flask==1.0.2',
            'Flask-Caching==1.4.0',
            'gunicorn==19.9.0',
            'idna==2.8',
            'idna-ssl==1.1.0',
            'itsdangerous==1.1.0',
            'Jinja2==2.10',
            'kombu==4.2.2.post1',
            'ldap3==2.5.2',
            'lockfile==0.12.2',
            'Mako==1.0.7',
            'MarkupSafe==1.1.0',
            'multidict==4.5.2',
            'paramiko==2.4.2',
            'pendulum==2.0.4',
            'psutil==5.4.8',
            'psycopg2-binary==2.7.6.1',
            'pyasn1==0.4.5',
            'pycparser==2.19',
            'PyNaCl==1.3.0',
            'python-daemon==2.1.1',
            'python-dateutil==2.7.5',
            'python-editor==1.0.3',
            'pytz==2018.7',
            'pytzdata==2018.7',
            'redis==3.0.1',
            'requests==2.21.0',
            'setproctitle==1.1.10',
            'setuptools==39.1.0',
            'six==1.12.0',
            'SQLAlchemy==1.2.14',
            'typing-extensions==3.6.6',
            'urllib3==1.24.1',
            'vine==1.1.4',
            'Werkzeug==0.14.1',
            'yarl==1.3.0',
            'mistune == 0.8.4',
            'pygments == 2.3.1',
            'PyYAML == 5.1',
            'markdown2 == 2.3.7',
            'Markdown == 3.0.1',
            'pyaml == 18.11.0',
            'jieba == 0.39'
        ],
        setup_requires=[
        ],
        extras_require={
        },
        classifiers=[
        ],
        author='Leaptocloud Software Foundation',
        author_email='',
        url='',
        download_url=(),
        cmdclass={
            'extra_clean': CleanCommand,
        },
    )


if __name__ == "__main__":
    do_setup()
