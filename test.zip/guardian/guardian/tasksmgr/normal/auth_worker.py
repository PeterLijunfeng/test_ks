
from celery.decorators import task
from celery.utils.log import get_task_logger
from guardian.common.ldap_domain.ldap_sync import sync_ldap_orgs
from guardian.common.ldap_domain.ldap_sync import sync_ldap_users

log = get_task_logger("celery_logger")


@task(name="tasks.auth.celery_sync_orgs", queue="gd_auth", routing_key="auth.org")
def celery_sync_ldap_orgs(base_dn, project_id, domain_id, token, ldap_status):
    log.info("start sync org param > 'basedn'：'{0}' 'project_id':'{1}' 'domain_id':'{2}'"
             .format(base_dn, project_id, domain_id))
    sync_status = sync_ldap_orgs(base_dn, project_id, domain_id, token, ldap_status)
    log.info("sync ldap org done !")
    return {
        "sync_status": sync_status.sync_status
    }


@task(name="tasks.auth.celery_sync_users", queue="gd_auth", routing_key="auth.user")
def celery_sync_ldap_users(base_dn, objectclass_list, project_id, domain_id, ldap_status):
    log.info("start sync users params > 'basedn':'{0}'  'objectclass_list':'{1}'\n'project_id':'{2}' 'domain_id':'{3}'"
             .format(base_dn, objectclass_list, project_id, domain_id))
    sync_status = sync_ldap_users(base_dn, project_id, domain_id, ldap_status)
    log.info("sync ldap users done !")
    return {
        "sync_status": sync_status.sync_status
    }
