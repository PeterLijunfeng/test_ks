
from guardian.common.errors import SyncException
from guardian.common.keystone.user_mgt import query_user_by_domain_id
from guardian.common.ldap_domain.myldap import search_ad_list
from guardian.common.ldap_domain.myldap import ldap_conn
from guardian.common.ldap_domain.myldap import parse_org_list
from guardian.common.ldap_domain.myldap import parse_user_list
from guardian.common.ldap_domain.myldap import get_ad_parent_dn
from guardian.settings import LDAP_ORG_FILTER
from guardian.settings import OBJECTCLASS_ORG_LIST
from guardian.settings import LDAP_USER_FILTER
from guardian.settings import OBJECTCLASS_USER_LIST
from guardian.settings import LDAP_SYNC_USER_COUNT
from guardian.log4 import app_logger as log
from guardian.apps import ON, FAILED, SUCCESS
from guardian.apps.users.models import UsersModel
from guardian.apps.users.models import UsersOrgsModel
from guardian.apps.sys_config.models import LdapConfigModel
from guardian.apps.users.services import delete_orgs_patch


def get_ldap_info(project_id):
    data = {
        "project_id": project_id
    }
    ldap = LdapConfigModel.get_ldap_info_by_project_id(**data)
    if not ldap:
        log.error("Can't found LdapConfig by project_id {0}".format(project_id))
        raise "Can't found LdapConfig by project_id {0}".format(project_id)
    return ldap


def fuzzy_get_orgs_list(base_dn, project_id):
    """

    :param base_dn: "OU=西安测试中心,DC=leaptocloud,DC=com"
    :param project_id:
    :return:
    """
    filters = {
        "project_id": project_id,
        "dn": base_dn
    }
    local_orgs_list = UsersOrgsModel.get_orgs_by_dn(**filters)
    if not local_orgs_list:
        log.info("local orgs is null for 'base_dn':{0}, 'project_id':{1}".format(base_dn, project_id))
        local_orgs_list = []
    return local_orgs_list


def insert_ldap_orgs_to_local(obj_parent_id_in_local_list, ldap_dict, project_id, domain_id):
    for exist_obj, org_dn in obj_parent_id_in_local_list:
        filters = {
            "dn": org_dn
        }
        local_org_obj = UsersOrgsModel.get_one_org_by_dn(**filters)
        if not local_org_obj:
            max_node_org_obj = UsersOrgsModel().get_max_node_id()
            if max_node_org_obj:
                new_node_id = max_node_org_obj.node_id + 1
            else:
                new_node_id = 1
            org_dict = {
                "org_name": ldap_dict.get(org_dn).get('name', ''),
                "object_uid": ldap_dict.get(org_dn).get('objectGUID', ''),
                "parent_id": exist_obj.id,
                "project_id": project_id,
                "domain_id": domain_id,
                "dn": org_dn,
                "node_id": new_node_id,
            }
            UsersOrgsModel.create_org(parent_parent_code=exist_obj.parent_code, parent_node_id=exist_obj.node_id,
                                      **org_dict)


def insert_ldap_root_org_to_local(org_dn, ldap_dict, project_id, domain_id):
    max_node_org_obj = UsersOrgsModel().get_max_node_id()
    if max_node_org_obj:
        new_node_id = max_node_org_obj.node_id + 1
    else:
        new_node_id = 1
    org_dict = {
        "org_name": ldap_dict.get(org_dn).get('name', ''),
        "object_uid": ldap_dict.get(org_dn).get('objectGUID', ''),
        "parent_id": "",
        "project_id": project_id,
        "domain_id": domain_id,
        "dn": org_dn,
        "node_id": new_node_id,
    }
    log.info("Insert root org_name: {0}".format(ldap_dict.get(org_dn).get('name', '')))
    UsersOrgsModel.create_org(parent_parent_code=None, parent_node_id=None, **org_dict)


def chk_parent_org_in_local(orgs_dn_list):
    in_local_list = []
    not_in_local_list = []
    for org_dn in orgs_dn_list:
        filters = {
            "dn": get_ad_parent_dn(org_dn)
        }
        local_org_obj = UsersOrgsModel.get_one_org_by_dn(**filters)
        if local_org_obj:
            in_local_list.append((local_org_obj, org_dn))
        else:
            not_in_local_list.append(org_dn)
    return in_local_list, not_in_local_list


def delete_local_orgs(local_org_dn_list, project_id, token):
    """
    删除本地组织结构,需要先校验是否有信息挂靠在该组织机构下
    :param local_org_dn_list:
    :param project_id:
    :return:
    """
    filters = {
        "project_id": project_id,
        "dn_list": local_org_dn_list
    }
    local_org_info_list = UsersOrgsModel.get_orgs_by_dn(**filters)
    orgs_info_list = []
    for org in local_org_info_list:
        org_info = {
            "id": org.id,
            "node_id": org.node_id,
            "parent_code": org.parent_code,
        }
        orgs_info_list.append(org_info)
    delete_orgs_patch(orgs_info_list, token, **filters)


def update_local_orgs(com_dn, ldap_dict, project_id):
    filters = {
        "project_id": project_id,
        "dn_list": com_dn
    }
    local_org_info_list = UsersOrgsModel.get_orgs_by_dn(**filters)
    orgs_info_list = []
    for org_obj in local_org_info_list:
        org_dict = {
            "id": org_obj.id,
            "object_uid": ldap_dict.get(org_obj.dn).get('objectGUID', ''),
            "org_name": ldap_dict.get(org_obj.dn).get('name', '')
        }
        orgs_info_list.append(org_dict)
    if orgs_info_list:
        UsersOrgsModel.update_org_batch(orgs_info_list)


def sync_ldap_orgs(base_dn, project_id, domain_id, token, ldap_status):
    """
    :param base_dn: "OU=西安测试中心,DC=leaptocloud,DC=com"
    :param project_id:
    :param domain_id:
    :param token:
    :return:
    """
    try:
        local_orgs_list = fuzzy_get_orgs_list(base_dn, project_id)
        log.info(">>>>> local_orgs_list count: {0}".format(len(local_orgs_list)))

        ldap = get_ldap_info(project_id)
        conn = ldap_conn(ldap.server_addr, ldap.server_port, ldap.user_name, ldap.user_pass)
        # TODO 预留将来通过前端传递 OBJECTCLASS_ORG_LIST, LDAP_ORG_FILTER
        org_list = search_ad_list(conn, base_dn, OBJECTCLASS_ORG_LIST, LDAP_ORG_FILTER)
        original_list = list(parse_org_list(org_list))
        ldap_orgs_list = sorted(original_list, key=lambda x: len(x['dn'].split(",")))
        ldap_dict = get_ldap_org_dict(ldap_orgs_list)

        ldap_org_dn = []
        for org in ldap_orgs_list:
            ldap_org_dn.append(org.get('dn', ''))

        # local org is null
        if not local_orgs_list:
            # add
            log.info("First time to Sync")
            insert_ldap_root_org_to_local(base_dn, ldap_dict, project_id, domain_id)
            not_in_local_list = ldap_org_dn
            not_in_local_list.remove(base_dn)
            while not_in_local_list:
                in_local_list, not_in_local_list = chk_parent_org_in_local(ldap_org_dn)
                insert_ldap_orgs_to_local(in_local_list, ldap_dict, project_id, domain_id)
            log.info("Sync ldap orgs to local done, count: {0}!".format(len(ldap_org_dn)))

        else:
            local_guid = []
            for org in local_orgs_list:
                local_guid.append(org.dn)

            # compare
            local_diff_ldap = list(set(local_guid).difference(set(ldap_org_dn)))
            ldap_diff_local = list(set(ldap_org_dn).difference(set(local_guid)))

            # delete
            log.info("Sync orgs: First step start DELETE local_diff_ldap")
            log.info("Sync orgs: local_diff_ldap DELETE count: {0}".format(len(local_diff_ldap)))
            if local_diff_ldap:
                delete_local_orgs(local_diff_ldap, project_id, token)

            # add
            log.info("Sync orgs: Second step start ADD ldap_diff_local")
            log.info("Sync orgs: ldap_diff_local ADD count: {0}".format(len(ldap_diff_local)))
            if ldap_diff_local:
                not_in_local_list = ldap_diff_local
                while not_in_local_list:
                    in_local_list, not_in_local_list = chk_parent_org_in_local(ldap_diff_local)
                    insert_ldap_orgs_to_local(in_local_list, ldap_dict, project_id, domain_id)

            # common & update
            log.info("Sync orgs: Last step start UPDATE local org")
            com_dn = list(set(local_guid).intersection(set(ldap_org_dn)))
            log.info("Sync orgs: update local org list count: {0}".format(len(com_dn)))
            if com_dn:
                update_local_orgs(com_dn, ldap_dict, project_id)
            ldap_status = ldap_status.update_sync_status(status=FAILED, description=str(e))
            log.info("Sync ldap orgs to local done!")
            return ldap_status
    except Exception as e:
        log.error("sync_ldap_orgs: {0}".format(e))
        ldap_status = ldap_status.update_sync_status(status=FAILED, description=str(e))
        return ldap_status


def get_ldap_org_dict(org_list):
    res = {}
    for data in org_list:
        res[data.get('dn')] = {'objectGUID': data.get('objectGUID'),
                               'name': data.get('name')}
    return res


def delete_local_users(dn_list, local_user_obj_dict):
    for i in range(0, len(dn_list) - 1, LDAP_SYNC_USER_COUNT):
        delete_user_ids = []
        for dn in dn_list[i:i + LDAP_SYNC_USER_COUNT]:
            delete_user_ids.append(local_user_obj_dict.get(dn).user_id)
        UsersModel.delete_user_batch(delete_user_ids)


def fuzzy_get_users_list(base_dn, project_id):
    """
    :param base_dn: "OU=西安测试中心,DC=leaptocloud,DC=com"
    :param project_id:
    :return:
    """
    filters = {
        "project_id": project_id,
        "dn": base_dn
    }
    local_users_list = UsersModel.fuzzy_get_users_by_dn(**filters)
    if not local_users_list:
        log.info("local users is null for 'base_dn':'{0}', 'project_id':'{1}'".format(base_dn, project_id))
    return local_users_list


def get_orgs_by_dn(root_dn):
    filters = {
        "dn": root_dn
    }
    orgs_obj = UsersOrgsModel.get_orgs_by_dn(**filters)
    if not orgs_obj:
        log.error("Can't get org_id, Check and Sync ORG first!")
        raise SyncException("Can't get org_id, Check and Sync ORG first!")
    org_id_dict = dict()
    for org in orgs_obj:
        org_id_dict[org.dn] = org.id

    return org_id_dict


def get_user_id_from_keystone(domain_id):
    """
    {
        "users": [
            {
                "password_expires_at": null,
                "links": {
                    "self": "http://192.168.3.124:35357/v3/users/9438973ed1854b968365823b52f054b78970a7"
                },
                "options": {},
                "id": "9438973ed1854b968365823b52f054b78970a7",
                "domain_id": "2cf2952e868a41a18a2fa9cdd0268990",
                "name": "postfix"
            },
            ...],
        "links": {
            "self": "http://192.168.3.124:35357/v3/users?domain_id=2cf2952e868a41a18a2fa9cdd0268990",
            "previous": null,
            "next": null
        }
    }
    同一个domain_id下， name不会重复
    :param domain_id:
    :return:
    """
    keystone_ad_user = query_user_by_domain_id(domain_id)
    ks_user_id_dict = dict()
    if not keystone_ad_user['users']:
        return {}
    ks_user_info_list = keystone_ad_user['users']
    for user_info in ks_user_info_list:
        ks_user_id_dict[user_info["name"]] = user_info["id"]
    return ks_user_id_dict


def get_org_array(org_id, parent_ad_node_dn, org_id_dict):
    org_array = [org_id]
    while org_id:
        parent_ad_node_dn = get_ad_parent_dn(parent_ad_node_dn)
        org_id = org_id_dict.get(parent_ad_node_dn)
        if org_id:
            org_array.append(org_id)
    return org_array[::-1]


def insert_ldap_users_to_local(user_info_list, user_id_dict, org_id_dict, project_id, domain_id):
    for i in range(0, len(user_info_list) - 1, LDAP_SYNC_USER_COUNT):
        users_batch_list = []
        for user_info in user_info_list[i:i + LDAP_SYNC_USER_COUNT]:
            user_name = user_info.get("username", "")
            org_dn = get_ad_parent_dn(user_info.get("dn", ""))
            org_id = org_id_dict.get(org_dn)

            users_batch_list.append({
                "user_id": user_id_dict.get(user_name) if user_id_dict.get(user_name) else UsersModel().gen_uuid(),
                "username": user_name,
                "realname": user_info.get("realname", ""),
                "email": user_info.get("email", ""),
                "org_id": org_id,
                "domain_id": domain_id,
                "enable": ON,
                "first_login": False,
                "org_array": get_org_array(org_id, org_dn, org_id_dict),
                "default_project_id": project_id,
                "object_suid": user_info.get("objectGUID", ""),
                "dn": user_info.get("dn", ""),
                "lower_name": user_name.lower(),
            })
        UsersModel.create_user_batch(users_batch_list)


def insert_ldap_users_to_local_by_dn(user_dn_list, dn_dict, user_id_dict, org_id_dict, project_id, domain_id):
    for i in range(0, len(user_dn_list) - 1, LDAP_SYNC_USER_COUNT):
        users_batch_list = []
        for dn in user_dn_list[i:i + LDAP_SYNC_USER_COUNT]:
            user_name = dn_dict.get(dn).get("username", "")
            org_dn = get_ad_parent_dn(dn)
            org_id = org_id_dict.get(org_dn)

            users_batch_list.append({
                "user_id": user_id_dict.get(user_name) if user_id_dict.get(user_name) else UsersModel().gen_uuid(),
                "username": user_name,
                "realname": dn_dict.get(dn).get("realname", ""),
                "email": dn_dict.get(dn).get("email", ""),
                "org_id": org_id,
                "domain_id": domain_id,
                "enable": ON,
                "first_login": False,
                "org_array": get_org_array(org_id, org_dn, org_id_dict),
                "default_project_id": project_id,
                "object_suid": dn_dict.get(dn).get("objectGUID", ""),
                "dn": dn,
                "lower_name": user_name.lower(),
            })
        UsersModel.create_user_batch(users_batch_list)


def get_ldap_data_dict(user_list):
    res = {}
    for data in user_list:
        res[data.get('dn')] = {'objectGUID': data.get('objectGUID'),
                               'username': data.get('username'),
                               'email': data.get('email'),
                               'realname': data.get('realname')}
    return res


def update_local_users(com_dn, dn_dict, local_user_obj_dict):
    for i in range(0, len(com_dn) - 1, LDAP_SYNC_USER_COUNT):
        update_user_info_list = []
        for dn in com_dn[i:i + LDAP_SYNC_USER_COUNT]:
            user_info = {
                "user_id": local_user_obj_dict.get(dn).user_id,
                "username": dn_dict.get(dn).get("username", ""),
                "realname": dn_dict.get(dn).get("realname", ""),
                "email": dn_dict.get(dn).get("email", ""),
                "object_suid": dn_dict.get(dn).get("objectGUID", ""),
                "lower_name": dn_dict.get(dn).get("username", "").lower(),
            }
            update_user_info_list.append(user_info)
        UsersModel.update_user_batch(update_user_info_list)


def sync_ldap_users(base_dn,  project_id, domain_id, ldap_status):
    """
    :param base_dn: "OU=西安测试中心,DC=leaptocloud,DC=com"
    :param project_id:
    :param domain_id:
    :return:
    """
    try:
        local_users_list = fuzzy_get_users_list(base_dn, project_id)
        log.info("local_users_list count: {0}".format(len(local_users_list)))

        ldap = get_ldap_info(project_id)
        log.info("start connect LDAP server")
        conn = ldap_conn(ldap.server_addr, ldap.server_port, ldap.user_name, ldap.user_pass)
        # TODO 预留将来通过前端传递 OBJECTCLASS_USER_LIST, LDAP_USER_FILTER
        ldap_users_list = search_ad_list(conn, base_dn, OBJECTCLASS_USER_LIST, LDAP_USER_FILTER)
        log.info("get LDAP user info done !")

        ldap_users_info_list = list(parse_user_list(ldap_users_list))
        log.info("ldap_users_info_list[0]:{0}".format(ldap_users_info_list[0]))
        user_id_dict = get_user_id_from_keystone(domain_id)
        org_id_dict = get_orgs_by_dn(base_dn)

        # local org is null
        if not local_users_list:
            # add
            log.info("First Sync: create users count: {0}".format(len(ldap_users_info_list)))
            insert_ldap_users_to_local(ldap_users_info_list, user_id_dict, org_id_dict, project_id, domain_id)
            log.info("Sync ldap users to local done create users count: {0}".format(len(ldap_users_info_list)))

        else:
            ldap_user_dn_list = []
            for user in ldap_users_info_list:
                ldap_user_dn_list.append(user.get('dn', ''))
            local_user_dn_list = []
            local_user_obj_dict = {}
            for user in local_users_list:
                local_user_dn_list.append(user.dn)
                local_user_obj_dict[user.dn] = user
            ldap_dict = get_ldap_data_dict(ldap_users_info_list)

            # compare
            local_diff_ldap = list(set(local_user_dn_list).difference(set(ldap_user_dn_list)))
            ldap_diff_local = list(set(ldap_user_dn_list).difference(set(local_user_dn_list)))
            com_dn = list(set(local_user_dn_list).intersection(set(ldap_user_dn_list)))

            # delete
            log.info("Sync users: First step start DELETE local_diff_ldap")
            log.info("Sync users: local_diff_ldap count: {0}".format(len(local_diff_ldap)))
            # TODO 判读用户拥有的资源信息,解除资源后再删除
            if local_diff_ldap:
                delete_local_users(local_diff_ldap, local_user_obj_dict)

            # add
            log.info("Sync users: Second step start ADD ldap_diff_local")
            log.info("Sync users: ldap_diff_local count: {0}".format(len(ldap_diff_local)))
            if ldap_diff_local:
                insert_ldap_users_to_local_by_dn(ldap_diff_local, ldap_dict, user_id_dict, org_id_dict, project_id,
                                                 domain_id)

            # common & update
            log.info("Sync users: Last step start UPDATE local users")
            log.info("Sync users: update local user count: {0}".format(len(com_dn)))
            if com_dn:
                update_local_users(com_dn, ldap_dict, local_user_obj_dict)
            ldap_status = ldap_status.update_sync_status(status=SUCCESS)
            log.info("Sync ldap users to local done!")
            return ldap_status
    except Exception as e:
        log.error("sync_ldap_users: {0}".format(e))
        ldap_status = ldap_status.update_sync_status(status=FAILED, description=str(e))
        return ldap_status
