from guardian import settings
from guardian.log4 import app_logger as LOG
import requests
from guardian.common.errors import KeystoneHandleException


def create_project(domain_id, project_name, description, is_domain=False, parent_project_id=None):
    req_data = {
        "project": {
            "description": "My new project",
            "domain_id": "default",
            "enabled": True,
            "is_domain": False,
            "name": "myNewProject"
        }
    }

    req_data['project']['domain_id'] = domain_id
    req_data['project']['name'] = project_name
    req_data['project']['is_domain'] = is_domain
    if description is None:
        req_data['project']['description'] = 'domain' if is_domain else 'project' + ' ' + project_name
    else:
        req_data['project']['description'] = description
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/projects', headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            LOG.info('create a new project, response: {0}'.format(resp_json))
            return resp_json
    else:
        LOG.error('error create a new project, response: {0}'.format(_resp))
        raise KeystoneHandleException('error create project {0} with response status {1}'
                                      .format(project_name, _resp.status_code),
                                      _resp.status_code)


def delete_project(project_id):
    LOG.debug('delete_project - project_id: {0}'.format(project_id))
    # myheaders = {'Content-Type': 'application/json'}
    myheaders = {'X-Auth-Token': settings.KEYSTONE_ADMIN_TOKEN }
    _resp = requests.delete(settings.KEYSTONE_BASE + '/v3/projects/' + project_id, headers=myheaders,  verify=False)

    if _resp.status_code == 204:
        LOG.debug('delete project -- response {0}'.format(_resp))
    else:
        LOG.error('error delete project, response: {0}'.format(_resp))
        raise KeystoneHandleException('error delete project {0} with response status {1}'
                                      .format(project_id, _resp.status_code), _resp.status_code)


def update_project(project_id, project_name, description, enabled=True):
    req_data = {
        "project": {
            "description": "Update Project",
            "name": "UpdateProject",
            "enabled": True,
        }
    }

    req_data['project']['name'] = project_name
    req_data['project']['description'] = description
    req_data['project']['enabled'] = enabled

    myheaders = {'Content-Type': 'application/json'}
    LOG.debug('update_project - project_id: {0}'.format(project_id))

    # myheaders = {'Content-Type': 'application/json'}
    myheaders = {'X-Auth-Token': settings.KEYSTONE_ADMIN_TOKEN }
    _resp = requests.patch(settings.KEYSTONE_BASE + '/v3/projects/' + project_id, headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            return resp_json
    else:
        LOG.error('error update project, response: {0}'.format(_resp))
        raise KeystoneHandleException('error update project {0} with response status {1}'
                                      .format(project_name, _resp.status_code),
                                      _resp.status_code)


def list_project(domainid):
    req_data = {"domain_id": "domain_id"}
    req_data['domain_id'] = domainid
    LOG.debug('list_project - domain_id: {0}'.format(domainid))
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/projects', headers=myheaders, params=req_data, verify=False)

    if _resp.ok:
        LOG.debug('list_project -- response {0}'.format(_resp))
        resp_json = _resp.json()

        return resp_json

    else:
        LOG.error('error list projects, response: {0}'.format(_resp))
        raise KeystoneHandleException('error list projects for domain {0} with response status {1}'
                                      .format(domainid, _resp.status_code), _resp.status_code)


def query_user_project(userid):
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/users/' + userid+ '/projects', headers=myheaders, verify=False)

    if _resp.ok:
        LOG.debug('query user projects -- response {0}'.format(_resp))
        resp_json = _resp.json()

        return resp_json

    else:
        LOG.error('error query user projects, response: {0}'.format(_resp))
        raise KeystoneHandleException('error query user projects with response status {0}'
                                      .format(_resp.status_code), _resp.status_code)


def change_user_project(project_id, token):
    req_data = {
                "auth": {
                    "identity": {
                        "methods": [
                            "token"
                        ],
                        "token": {
                            "id": token
                        }
                    },
                    "scope": {
                        "project": {
                            "id": project_id
                        }
                    }
                }
            }
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/auth/tokens', headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        resp_head = _resp.headers
        if resp_json is not None:
            return resp_head
    else:
        LOG.error('error change user project, response: {0}'.format(_resp))
        raise KeystoneHandleException('error change user project {0} with response status {1}'
                                      .format(project_id, _resp.status_code),
                                      _resp.status_code)


def get_project_by_id(project_id):
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/projects/' + project_id,
                         headers={'X-Auth-Token': settings.KEYSTONE_ADMIN_TOKEN}, verify=False)
    if _resp.ok:
        LOG.debug('query project by id -- response {0}'.format(_resp))
        resp_json = _resp.json()
        return resp_json
    else:
        LOG.error('query project by id, response: {0}'.format(_resp))
        raise KeystoneHandleException('query project by id with response status {0}'
                                      .format(_resp.status_code), _resp.status_code)