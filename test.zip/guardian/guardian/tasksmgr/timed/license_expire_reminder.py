import time
from celery.decorators import task
from guardian.apps.sys_config.services import check_license_expire_task


@task(name="tasks.default.check_license_expire", queue="default", routing_key="default")
def check_license_expire(date):
    now_date = time.strftime('%Y-%m-%d',time.localtime(time.time()))
    # 如果不是同一天的消息则不发送
    if date == now_date:
        check_license_expire_task()