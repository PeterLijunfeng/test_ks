import requests
from guardian import settings
from guardian.common.errors import KeystoneHandleException
from guardian.log4 import app_logger as log

keystone_auth_url = '/v3/auth/tokens'


def validate(token):
    myheaders = dict()
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    myheaders['X-Subject-Token'] = token

    resp = requests.get(settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, timeout=300)
    '''
    {
    "token": {
        "methods": [
            "token"
        ],
        "roles":[
         {
                "id": "5090055d6bd547dc83e0e8f070803708",
                "name": "admin"
            }
        ],
        "expires_at": "2015-11-05T22:00:11.000000Z",
        "project": {
            "domain": {
                "id": "default",
                "name": "Default"
            },
            "id": "5b50efd009b540559104ee3c03bbb2b7",
            "name": "admin"
        },
        "is_domain": false,
        "catalog": [
            {
                "endpoints": [
                    {
                        "region_id": "RegionOne",
                        "url": "http://23.253.248.171:9292",
                        "region": "RegionOne",
                        "interface": "admin",
                        "id": "b2605da9b25943beb49b2bd86aca2202"
                    }
                ],
                "type": "image",
                "id": "495df2483dc145dbb6b34bfbdd787aae",
                "name": "glance"
            }
        ],
        "user": {
            "domain": {
                "id": "default",
                "name": "Default"
            },
            "id": "10a2e6e717a245d9acad3e5f97aeca3d",
            "name": "admin",
            "password_expires_at": null
        },
        "audit_ids": [
            "mAjXQhiYRyKwkB4qygdLVg"
        ],
        "issued_at": "2015-11-05T21:00:33.819948Z"
        }
    }
    '''
    if resp.status_code < 400:
        resp_body = resp.json()
        # log.debug('validate token, keystone response: {0}'.format(resp_body))
        if resp_body is None:
            log.error('keystone response is None!!!')
            raise KeystoneHandleException('keystone response nothing !!!')
        return token, resp_body
    elif resp.status_code > 500:
        log.error('keystone res.status_code is [%d],  maybe service unavailable!' % resp.status_code)
        raise KeystoneHandleException('keystone res.status_code is [%d]' % resp.status_code)
    else:
        log.error('keystone res.status_code is [%d],  maybe service unavailable!' % resp.status_code)
        raise KeystoneHandleException('keystone res.status_code is [%d]' % resp.status_code)


def get_user_from_domain(domain, user):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    u_data = dict()
    u_data['domain_id'] = domain
    u_data['name'] = user
    _res = requests.get(settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
                        params=u_data, verify=False)
    res_json = _res.json()
    if not res_json['users']:
        return {}
    return res_json['users'][0]


def login_user_token(user, passwd, domain, user_id, project_id=None):
    """
    user login from keystone domain
    :param domain:
    :param user:
    :param passwd:
    :return: token  token:0- 帐号or密码错误  token:None-帐号被禁用
    """
    req_data = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": "admin",
                        "domain": {
                            "id": "default"
                        },
                        "password": "123456"
                    }
                }
            },
            "scope": {
                "project": {
                    "id": "d68c02cb02864bafa7ed202d8d26fa42"
                }
            }
        }
    }

    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    req_data['auth']['identity']['password']['user']['domain']['id'] = domain
    req_data['auth']['identity']['password']['user']['name'] = user
    req_data['auth']['identity']['password']['user']['password'] = passwd
    if project_id:
        req_data['auth']['scope']['project']['id'] = project_id
    else:
        resp_project = requests.get(
            settings.KEYSTONE_BASE + "/v3/users/" + user_id + "/projects", headers=myheaders,
            verify=True)
        project_json = resp_project.json()
        project_id = project_json['projects'][0].get('id')
        req_data['auth']['scope']['project']['id'] = project_id
    _resp = requests.post(
        settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, json=req_data, verify=False)
    if _resp.ok:
        token = _resp.headers['X-Subject-Token']
        resp_json = _resp.json()
        return token, resp_json
    elif _resp.status_code == 401 or _resp.status_code == 403:
        log.error('User must authenticate before making a request, response: {0}'.format(_resp))
        return 0, None
    else:
        log.error('keystone res.status_code is [%d],  maybe service unavailable!' % _resp.status_code)
        raise KeystoneHandleException('login keystone error, response: {0}'.format(_resp))


def user_token(domain, user, passwd):
    req_data = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "name": "admin",
                        "domain": {
                            "id": "default"
                        },
                        "password": "123456"
                    }
                }
            },
            "scope": {
                "project": {
                    "id": "d68c02cb02864bafa7ed202d8d26fa42"
                }
            }
        }
    }

    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    u_data = dict()
    u_data['domain_id'] = domain
    u_data['name'] = user
    _res = requests.get(
        settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
        params=u_data, verify=False)
    res_json = _res.json()
    # fixed ucmp-1331 start
    if res_json['users']:
        default_project_id = res_json['users'][0].get('default_project_id')
    else:
        return 0
    # fixed ucmp-1331 end
    # if domain == "default":
    if default_project_id:
        # return 0: 帐号 or 密码错误  None:帐号被禁用
        if len(res_json['users']):
            if res_json['users'][0]['enabled']:  # 验证帐号状态
                # req_data['auth']['identity']['password']['user']['domain']['id'] = domain
                req_data['auth']['identity']['password']['user']['name'] = user
                req_data['auth']['identity']['password']['user']['password'] = passwd
                req_data['auth']['scope']['project']['id'] = default_project_id
                # user_id = res_json['users'][0].get('id')
                _resp = requests.post(settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, json=req_data,
                                      verify=False)
                if _resp.ok:
                    return _resp.headers['X-Subject-Token']
                else:
                    log.error('error got a new token, response: {0}'.format(_resp))
                    return 0
            else:
                return None
        else:
            return 0
    else:
        req_data = {
            "auth": {
                "identity": {
                    "methods": [
                        "password"
                    ],
                    "password": {
                        "user": {
                            "name": "admin",
                            "domain": {
                                "id": "default"
                            },
                            "password": "123456"
                        }
                    }
                },
                "scope": {
                    "project": {
                        "id": "d68c02cb02864bafa7ed202d8d26fa42"
                    }
                }
            }
        }
        req_data['auth']['identity']['password']['user']['domain']['id'] = domain
        req_data['auth']['identity']['password']['user']['name'] = user
        req_data['auth']['identity']['password']['user']['password'] = passwd

        user_id = res_json['users'][0].get('id')
        resp_project = requests.get(
            settings.KEYSTONE_BASE + "/v3/users/" + user_id + "/projects", headers=myheaders,
            verify=True)
        project_json = resp_project.json()
        project_id = project_json['projects'][0].get('id')
        req_data['auth']['scope']['project']['id'] = project_id

        _resp = requests.post(
            settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, json=req_data,
            verify=False)
        if _resp.ok:
            return _resp.headers['X-Subject-Token']
        else:
            log.error('error got a new token, response: {0}'.format(_resp))
            return 0


def list_user_role(domain_id, user_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(
        settings.KEYSTONE_BASE + '/v3/domains/' + domain_id + '/users/' + user_id + '/roles',
        headers=myheaders, verify=False)
    if _resp.ok:
        roles = []

        resp_json = _resp.json()
        if resp_json is not None:
            rs = resp_json['roles']
            for r in rs:
                roles.append(r['name'])
            log.debug('succeed listing user {0} with roles {1}'.format(user_id, roles))
            return roles
        else:
            return None
    else:
        log.error('error listing the roles for user {0}, response {1}'.format(user_id, _resp))
        return None


def list_user_role_detail(project_id, user_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(
        settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + user_id + '/roles',
        headers=myheaders, verify=False)
    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            rs = resp_json['roles']
            log.debug('succeed listing user {0} with roles {1}'.format(user_id, rs))
            return rs
        else:
            return None

    else:
        log.error('error listing the roles for user {0}, response {1}'.format(user_id, _resp))
        return None


def list_user_role_on_project(project_id, user_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(
        settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + user_id + '/roles',
        headers=myheaders, verify=False)
    if _resp.ok:
        roles = []

        resp_json = _resp.json()
        if resp_json is not None:
            rs = resp_json['roles']
            for r in rs:
                roles.append(r['name'])
            log.debug('succeed listing user {0} with roles {1}'.format(user_id, roles))
            return roles
        else:
            return None
    else:
        log.error('error listing the roles for user {0}, response {1}'.format(user_id, _resp))
        return None


def list_user_role_detail_on_project(project_id, user_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(
        settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + user_id + '/roles',
        headers=myheaders, verify=False)
    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            rs = resp_json['roles']
            log.debug('succeed listing user {0} with roles {1}'.format(user_id, rs))
            return rs
        else:
            return None

    else:
        log.error('error listing the roles for user {0}, response {1}'.format(user_id, _resp))
        return None


def user_login_scope_project(user_id, password, project_id):
    data = {
        "auth": {
            "identity": {
                "methods": [
                    "password"
                ],
                "password": {
                    "user": {
                        "id": user_id,
                        "password": password
                    }
                }
            },
            "scope": {
                "project": {
                    "id": project_id
                }
            }
        }
    }
    myheaders = {'Content-Type': 'application/json',
                 'X-Auth-Token': settings.KEYSTONE_ADMIN_TOKEN}
    _resp = requests.post(
        settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, json=data, verify=False)
    if _resp.ok:
        token = _resp.headers['X-Subject-Token']
        resp_json = _resp.json()
        return token, resp_json
    else:
        log.error('error got a new token, response: {0}'.format(_resp))
        return 0, None


def logout(token):
    myheaders = dict()
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    myheaders['X-Subject-Token'] = token
    resp = requests.delete(settings.KEYSTONE_BASE + keystone_auth_url, headers=myheaders, timeout=10)
    if resp.status_code < 400:
        log.info('successfully logout token {0}'.format(token))
    else:
        log.error('keystone logout error {0}'.format(resp))

