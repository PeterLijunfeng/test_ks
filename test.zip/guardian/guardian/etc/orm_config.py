import os

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.pool import NullPool

from guardian.log4 import app_logger as log
from guardian.utils.sqlalchemy import setup_event_handlers
from guardian.settings import SQL_ALCHEMY_POOL_ENABLED, SQL_ALCHEMY_CONN, \
    SQL_ALCHEMY_POOL_SIZE, SQL_ALCHEMY_POOL_RECYCLE, SQL_ALCHEMY_RECONNECT_TIMEOUT

engine = None
Session = None


def configure_orm(disable_connection_pool=False):
    # log.debug("Setting up DB connection pool (PID %s)" % os.getpid())
    global engine
    global Session
    engine_args = {}

    pool_connections = SQL_ALCHEMY_POOL_ENABLED
    if disable_connection_pool or not pool_connections:
        engine_args['poolclass'] = NullPool
        log.debug("settings.configure_orm(): Using NullPool")
    elif 'sqlite' not in SQL_ALCHEMY_CONN:
        log.debug("orm_configure(): Using pool settings. pool_size={}, "
                  "pool_recycle={}".format(SQL_ALCHEMY_POOL_SIZE, SQL_ALCHEMY_POOL_RECYCLE))
        engine_args['pool_size'] = SQL_ALCHEMY_POOL_SIZE
        engine_args['pool_recycle'] = SQL_ALCHEMY_POOL_RECYCLE

    engine_args['encoding'] = 'utf-8'
    engine = create_engine(SQL_ALCHEMY_CONN, **engine_args)
    reconnect_timeout = SQL_ALCHEMY_RECONNECT_TIMEOUT
    setup_event_handlers(engine, reconnect_timeout)

    Session = scoped_session(
        sessionmaker(autocommit=False,
                     autoflush=False,
                     bind=engine,
                     expire_on_commit=False))
configure_orm()