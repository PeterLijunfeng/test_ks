# -*- coding: utf-8 -*-
"""
@author: ray
@description: 由于windows、linux在实现ldap协议后，用户定义的属性不一致，导致处理结果差异化
现在将获取属性 设置为用户自定义， 通过getattr 来读取相关属性， 使用reload 再不重启guardian情况下 用户自由定义
windows ad
    LDAP_ATTRIBUTES = {
            "dn": "distinguishedName",
            "objectGUID": "objectGUID",
            "realname": "name",
            'email': "userPrincipalName",
            'username': "sAMAccountName"
}

linux ldap_domain

    LDAP_ATTRIBUTES = {
            "dn": "entry_dn",
            "objectGUID": "uid",
            "realname": "name",
            'email': "",
            'username': "cn"
}

"""
import ldap3
from ldap3 import Connection, Server, ALL
from guardian.common.errors import ParamsException
from guardian.common.errors import SyncException
from guardian.settings import LDAP_ORG_ATTRIBUTES
from guardian.settings import LDAP_ATTRIBUTES
from guardian.settings import LDAP_ATTRIBUTES_FILTERS
from guardian.settings import LDAP_TIMEOUT
from guardian.settings import LDAP_PAGED_SIZE
from guardian.log4 import app_logger as log


def ldap_conn(server_addr, server_port, user, password):
    ldap_addr = server_addr+":"+str(server_port)
    try:
        server = Server(ldap_addr, get_info=ALL, connect_timeout=LDAP_TIMEOUT)
        conn = Connection(server, user, password, auto_bind=True)
        return conn
    except Exception as e:
        log.error("Ldap Connect error: {0}".format(e))
        return None


def search_ad_list(conn, search_base, objectclass_list, filter_string=None):
    """
    查询ad 数据，返回list
    :param conn:
    :param search_base:
    :param objectclass_list:
    :param filter_string:
    :return:
    """
    if filter_string:
        objectclass_string = filter_string
    else:
        if not objectclass_list:
            log.error("OBJECTCLASS_LIST in guardian settings.py is []")
            raise ParamsException("OBJECTCLASS_LIST in guardian settings.py is []")
        elif len(objectclass_list) == 1:
            objectclass_string = '(objectclass=%s)' % objectclass_list[0]
        else:
            objectclass_string_list = []
            for objectclass in objectclass_list:
                objectclass_string_list.append('(objectclass=%s)' % objectclass)
            objectclass_string = '(&%s)' % (''.join(objectclass_string_list))

    # objectclass_string = '(&(objectclass=organizationalUnit)(objectclass=top))'
    if conn.search(search_base, objectclass_string, search_scope=ldap3.SUBTREE,
                   attributes=LDAP_ATTRIBUTES_FILTERS if LDAP_ATTRIBUTES_FILTERS else ldap3.ALL_ATTRIBUTES,
                   paged_size=LDAP_PAGED_SIZE):
        ad_users_list = []
        ad_users_list.extend(conn.entries)
        log.info(">>>>> ad_users_list[0]: {0}".format(ad_users_list[0]))
        log.info(">>>>> paged_cookie: {0}".format(conn.result['controls']))
        cookie = conn.result['controls']['1.2.840.113556.1.4.319']['value']['cookie']
        while cookie:
            if conn.search(search_base, objectclass_string, search_scope=ldap3.SUBTREE,
                           attributes=LDAP_ATTRIBUTES_FILTERS if LDAP_ATTRIBUTES_FILTERS else ldap3.ALL_ATTRIBUTES,
                           paged_size=LDAP_PAGED_SIZE, paged_cookie=cookie):
                ad_users_list.extend(conn.entries)
                cookie = conn.result['controls']['1.2.840.113556.1.4.319']['value']['cookie']
            else:
                log.error("LDAP connect error")
                raise SyncException("LDAP connect error")
        return ad_users_list
    else:
        log.error("LDAP connect error")
        raise SyncException("LDAP connect error")


def parse_org_list(org_entry_list):
    """
    LDAP_ORG_ATTRIBUTES = {
        "dn": "distinguishedName",
        "objectGUID": "objectGUID",
        "name": "name"
    }
    :param org_entry_list:

    :return:

    """
    return map(lambda x: {
        "dn": str(getattr(x, LDAP_ORG_ATTRIBUTES['dn'], "")),
        "objectGUID": str(getattr(x, LDAP_ORG_ATTRIBUTES['objectGUID'], "")).replace("{", "").replace("}", ""),
        "name": str(getattr(x, LDAP_ORG_ATTRIBUTES['name'], "")),
    }, org_entry_list)


def parse_user_list(user_entry_list):
    """

    :param user_entry_list: 根据settings配置 获取相关属性值
    :return:
    """
    for user_entry in user_entry_list:
            dn = str(user_entry.__dict__.get(LDAP_ATTRIBUTES['dn'], ''))
            email = str(user_entry.__dict__.get(LDAP_ATTRIBUTES['email'], ''))
            username = str(user_entry.__dict__.get(LDAP_ATTRIBUTES['username'], ''))
            objectGUID = str(user_entry.__dict__.get(LDAP_ATTRIBUTES['objectGUID'], ''))\
                .replace("{", "").replace("}", "")
            realname = str(user_entry.__dict__.get(LDAP_ATTRIBUTES['realname'], ''))

            yield {
                "dn": dn,
                "objectGUID": objectGUID,
                "realname": realname,
                'email': email,
                'username': username
            }


def get_ad_parent_dn(dn):
    """
    'OU=测试1组,OU=西安测试中心,DC=leaptocloud,DC=com'
    :param dn:
    :return:
    """
    dn_list = dn.split(",")
    return ",".join(dn_list[1:])
