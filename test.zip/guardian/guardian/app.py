
from flask import Flask
from guardian import settings
from guardian.etc import orm_config
from guardian.apps.business.controller import business_site
from guardian.apps.device_agents.controller import device_site,agent_site
from guardian.apps.messages.controller import messages_site
from guardian.apps.sys_config.controller import sys_config_site
from guardian.apps.users.controller import users_site


def create_app():
    app = Flask(__name__)
    app.secret_key = settings.SECRET_KEY
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16M
    settings.cache.init_app(app)
    with app.app_context():
        app.register_blueprint(business_site)
        app.register_blueprint(device_site)
        app.register_blueprint(messages_site)
        app.register_blueprint(sys_config_site)
        app.register_blueprint(users_site)
        app.register_blueprint(agent_site)

        @app.teardown_appcontext
        def shutdown_session(exception=None):
            orm_config.Session.remove()

        return app


app = None


def cached_app():
    global app
    if not app:
        app = create_app()
    return app


if __name__ == "__main__":
    app = cached_app()
    app.run(debug=True, port=8080, host="0.0.0.0", ssl_context=None)
