import re
import json
from celery.execute import send_task
from guardian.etc.strategy_conf import EMAIL, SMS, INNER_NOTICE, MessageTypeDict
from guardian.settings import PLATFORM_UCMP, INIT_ROLE_ID, DEPT_ADMIN, PROJECT_ADMIN, ROLE_START
from guardian.common.errors import ParamsException
from guardian.apps import DOING, MESSAGE_TYPE_DICT
from guardian.apps.users.models import UsersModel
from guardian.apps.users.models import UserRoleRelationShip
from guardian.apps.users.models import get_user_by_org_id_and_role_id
from guardian.apps.messages.models import MessagesModel
from guardian.log4 import app_logger as log


def get_user_info_for_send_message(role_name_list, to_user, select_user_id_list, source_info, platform, force):
    """
    目前发消息支持选择的角色类型有，租户管理员，部门管理员
    :param role_name_list:  role uuid
    :param to_user:
    :param select_user_id_list:
    :param source_info:
    :return:
    """
    ucmp_admin_user_list = []
    ucmp_dept_user_list = []
    if force != 1:
        if platform == PLATFORM_UCMP:
            ucmp_dept_role_id = INIT_ROLE_ID[PLATFORM_UCMP][DEPT_ADMIN]
            dept = ROLE_START + ucmp_dept_role_id
            if dept in role_name_list:
                org_id = source_info.get("org_id")
                if not org_id:
                    raise ParamsException("org_id in source info is None: {0}")
                users_info = get_user_by_org_id_and_role_id(org_id, ucmp_dept_role_id)
                for user in users_info:
                    ucmp_dept_user_list.append(user.id)

            ucmp_admin_role_id = INIT_ROLE_ID[PLATFORM_UCMP][PROJECT_ADMIN]
            admin = ROLE_START + ucmp_admin_role_id
            if admin in role_name_list:
                filters = {
                    "role_id": ucmp_admin_role_id
                }
                rela_objs = UserRoleRelationShip.get_relation_by_user_role_ids(**filters)
                for rela in rela_objs:
                    ucmp_admin_user_list.append(rela.user_id)
        else:
            log.info("no support [%s] platform to send message" % platform)
        user_id_li = list(set(to_user + select_user_id_list + ucmp_admin_user_list + ucmp_dept_user_list))
        filters = {
            "user_id_list": user_id_li
        }
    else:
        filters = {
            "user_id_list": to_user
        }
    cnt, user_objs = UsersModel.get_list(**filters)
    if not cnt:
        log.error("can not found anyuser by ids: {0}".format(to_user))
        raise ParamsException("can not found anyuser by ids: {0}".format(to_user))
    user_id_list = []
    all_user = []
    email_list = []
    no_email_users = []
    phone_list = []
    no_phone_users = []
    for user_obj in user_objs:
        all_user.append(user_obj.username)
        user_id_list.append(user_obj.user_id)
        if user_obj.email:
            email_list.append(user_obj.email)
        else:
            no_email_users.append(user_obj.username)
        if user_obj.phone:
            phone_list.append(user_obj.phone)
        else:
            no_phone_users.append(user_obj.username)

    return email_list, no_email_users, phone_list, no_phone_users, all_user, user_id_list


def send_message(send_info):
    """
    send strategy message
    :param send_info:
    :param template_name:
    :return:
    """
    project_id = send_info.get("project_id")
    to_user = send_info.get("to_user")
    role_name_list = send_info.get("role_name_list")
    select_user_id_list = send_info.get("user_id_list")
    templates = send_info.get("templates")
    notice_type_id = send_info.get("notice_type_id")
    level = send_info.get("level")
    variable = send_info.get("variable")
    source_info = send_info.get("source_info")
    platform = send_info.get("platform")
    force = send_info.get("force")
    message_type = send_info.get("message_type")

    email_list, no_email_users, phone_list, no_phone_users, all_user, user_id_list = \
        get_user_info_for_send_message(role_name_list, to_user, select_user_id_list, source_info, platform, force)
    data_list = []
    for template in templates:
        content = render_template(template.content, variable)
        msgs_id = MessagesModel().gen_uuid()
        data_list.append({
            "id": msgs_id,
            "template_id": template.id,
            "to_user": all_user,
            "content": content,
            "message_type_id": message_type if message_type else notice_type_id,
            "message_type_name": MessageTypeDict.get(message_type) if message_type else MESSAGE_TYPE_DICT.get(notice_type_id),
            "level": level,
            "project_id": project_id,
            "status": DOING
        })
        send_msgs = {
            "project_id": project_id,
            "level": level,
            "notice_type_id": notice_type_id,
            "user_id_list": user_id_list,
            "all_user": all_user,
            "msgs_id": msgs_id,
            "messgs": {
                "title": template.title,
                "content": content
            }
        }

        # 'message_type' for Java
        if message_type in [EMAIL, SMS, INNER_NOTICE] and message_type == EMAIL and email_list:
            send_msgs["email_list"] = email_list
            send_msgs["no_email_users"] = no_email_users
            send_msgs["messgs"]["to_addrs"] = email_list
            send_task('tasks.message.celery_send_template_mail', [json.dumps(send_msgs)], queue="gd_message")

        elif message_type in [EMAIL, SMS, INNER_NOTICE] and message_type == SMS and phone_list:
            send_msgs["phone_list"] = phone_list
            send_msgs["no_phone_users"] = no_phone_users
            send_msgs["messgs"]["to_phones"] = phone_list
            send_task('tasks.message.celery_send_sms', [json.dumps(send_msgs)], queue="gd_message")

        elif message_type in [EMAIL, SMS, INNER_NOTICE] and message_type == INNER_NOTICE:
            send_msgs["user_id_list"] = user_id_list
            send_msgs["messgs"]["to_user"] = user_id_list
            send_task('tasks.message.celery_send_inner_notice', [json.dumps(send_msgs)], queue="gd_message")

        else:
            if template.type_id == EMAIL and email_list:
                send_msgs["email_list"] = email_list
                send_msgs["no_email_users"] = no_email_users
                send_msgs["messgs"]["to_addrs"] = email_list
                send_task('tasks.message.celery_send_template_mail', [json.dumps(send_msgs)], queue="gd_message")

            if template.type_id == SMS and phone_list:
                send_msgs["phone_list"] = phone_list
                send_msgs["no_phone_users"] = no_phone_users
                send_msgs["messgs"]["to_phones"] = phone_list
                send_task('tasks.message.celery_send_sms', [json.dumps(send_msgs)], queue="gd_message")

            if template.type_id == INNER_NOTICE:
                send_msgs["user_id_list"] = user_id_list
                send_msgs["messgs"]["to_user"] = user_id_list
                send_task('tasks.message.celery_send_inner_notice', [json.dumps(send_msgs)], queue="gd_message")
    MessagesModel.add_message_batch(data_list)


def render_template(content, variables):
    """
    :param content:
    :param variables:
    :return:
    """
    for variable in variables:
        key = variable.get('key')
        value = variable.get('value', '')
        match_rxp = '{% *' + key + ' *%}'
        result = re.search(match_rxp, content)
        if result:
            under_replace = result.group(0)
            content = content.replace(under_replace, value)
    return content


def get_user_email_phone(user_ids):
    email_list = []
    no_email_users = []
    phone_list = []
    no_phone_users = []
    filters = {
        "user_id_list": user_ids
    }
    cnt, user_objs = UsersModel.get_list(**filters)
    if not cnt:
        log.error("can not found anyuser by ids: {0}".format(user_ids))
        raise ParamsException("can not found anyuser by ids: {0}".format(user_ids))
    for user_obj in user_objs:
        if user_obj.email:
            email_list.append(user_obj.email)
        else:
            no_email_users.append(user_obj.username)
        if user_obj.phone:
            phone_list.append(user_obj.phone)
        else:
            no_phone_users.append(user_obj.username)

    return email_list, no_email_users, phone_list, no_phone_users


def send_no_template_message(data):
    project_id = data.get("project_id")
    to_user = data.get("to_user")
    title = data.get("title")
    content = data.get("content")
    level = data.get("level")
    message_type = data.get("message_type")
    msgs_id = MessagesModel().gen_uuid()
    data_list = {
        "id": msgs_id,
        "template_id": title,
        "to_user": to_user,
        "content": content,
        "message_type_id": message_type,
        "message_type_name": MessageTypeDict.get(message_type),
        "level": level,
        "project_id": project_id,
        "status": DOING
    }
    send_msgs = {
        "project_id": project_id,
        "level": level,
        "all_user": to_user,
        "user_id_list": to_user,
        "msgs_id": msgs_id,
        "notice_type_id": data.get("notice_type_id"),
        "messgs": {
            "title": title,
            "content": content
        }
    }
    if message_type == EMAIL:
        email_list, no_email_users, ph_li, no_ph = get_user_email_phone(to_user)
        send_msgs["email_list"] = email_list
        send_msgs["no_email_users"] = no_email_users
        send_msgs["messgs"]["to_addrs"] = email_list
        send_task('tasks.message.celery_send_template_mail', [json.dumps(send_msgs)], queue="gd_message")

    elif message_type == SMS:
        em_li, no_em, phone_list, no_phone_users = get_user_email_phone(to_user)
        send_msgs["phone_list"] = phone_list
        send_msgs["no_phone_users"] = no_phone_users
        send_msgs["messgs"]["to_phones"] = phone_list
        send_task('tasks.message.celery_send_sms', [json.dumps(send_msgs)], queue="gd_message")

    elif message_type == INNER_NOTICE:
        send_msgs["user_id_list"] = to_user
        send_msgs["messgs"]["to_user"] = to_user
        send_task('tasks.message.celery_send_inner_notice', [json.dumps(send_msgs)], queue="gd_message")

    MessagesModel.add_message(**data_list)
