import json
import math
import uuid
from flask import Blueprint
from flask import request
from guardian.settings import APIBASEURL, INIT_ROOT_NAME
from guardian.settings import RESET_LOGIN_PASSWD
from guardian.settings import LOGIN_DEFAULT_DOMAIN_NAME
from guardian.settings import cache
from guardian.settings import UCMP_ROLE_KIND_ROOT
from guardian.settings import UCMP_ROLE_KIND_ADMIN
from guardian.settings import UCMP_ROLE_KIND_CHOICES
from guardian.settings import UCMP_ROLE_KIND_DEPT
from guardian.settings import KEYSTONE_DEFAULT_ROLE_NAME
from guardian.settings import CMDB_ROLE_KIND_ROOT
from guardian.settings import ATOMFLOW_ROLE_KIND_ROOT
from guardian.settings import GUARDIAN_ROLE_KIND_ROOT
from guardian.settings import PLATFORM_CMDB
from guardian.settings import PLATFORM_ATOMFLOW
from guardian.settings import PLATFORM_GUARDIAN
from guardian.settings import PLATFORM_UCMP
from guardian.settings import CMDB_ROLE_KIND_ADMIN
from guardian.settings import CMDB_ROLE_KIND_CHOICES
from guardian.settings import ATOMFLOW_ROLE_KIND_ADMIN
from guardian.settings import ATOMFLOW_ROLE_KIND_CHOICES
from guardian.settings import GUARDIAN_ROLE_KIND_CHOICES
from guardian.settings import GUARDIAN_ROLE_KIND_ADMIN
from guardian.settings import INIT_ROLE_ID
from guardian.settings import DEPT_ADMIN
from guardian.common.rest import restful
from guardian.common.common import check_param_is_null
from guardian.common.ucmp.ucmp_api import update_user_role
from guardian.common.keystone.domain_mgt import DEFAULT_DOMAIN_ID
from guardian.common.keystone.domain_mgt import list_domain
from guardian.common.keystone.authentication import logout
from guardian.common.keystone.user_mgt import create_user as keystone_create_user
from guardian.common.keystone.user_mgt import update_user as keystone_update_user
from guardian.common.keystone.user_mgt import delete_user as keystone_delete_user
from guardian.common.keystone.user_mgt import change_user_password as keystone_change_user_password
from guardian.common.keystone.project_mgt import create_project as keystone_create_project
from guardian.common.keystone.project_mgt import update_project as keystone_update_project
from guardian.common.keystone.project_mgt import list_project as keystone_list_project
from guardian.common.keystone.project_mgt import get_project_by_id as keystone_get_project_by_id
from guardian.common.keystone.project_mgt import change_user_project as keystone_change_user_project
from guardian.common.keystone.role_mgt import query_role_by_role_name as keystone_query_role
from guardian.common.keystone.role_mgt import assign_role_project as keystone_binding_role
from guardian.common.errors import KeystoneHandleException, AuthException, ParamsException
from guardian.apps.users.services import token_validate, query_dept_role_users_by_local_org_id
from guardian.apps.users.services import user_login
from guardian.apps.users.services import delete_orgs
from guardian.apps.users.services import get_org_tree
from guardian.apps.users.services import get_trees_org_business
from guardian.apps.users.services import get_all_node_org_info
from guardian.apps.users.services import get_roles_by_user_id
from guardian.apps.users.services import clear_user_token_relationcache
from guardian.apps.users.services import login_scope_project
from guardian.apps.users.services import assign_role_project_to_superuser
from guardian.apps.users.services import judge_allow_role_list
from guardian.apps.users.models import UsersModel
from guardian.apps.users.models import UsersOrgsModel
from guardian.apps.users.models import UserRolePermissionModel
from guardian.apps.users.models import UserRolesModel
from guardian.apps.sys_config.models import SysInfoConfModel
from guardian.apps.users.models import UserRoleRelationShip
from guardian.apps.users.services import query_init_dept_role_users_by_org_id
from guardian.apps.users.services import query_dept_role_users_by_org_id
from guardian.apps.users.models import get_users_by_role_data
from guardian.apps import OFF, ON
from guardian.log4 import app_logger as log

users_site = Blueprint('user', __name__, url_prefix="%s/user" % APIBASEURL)


@users_site.route('/token', methods=['GET'])
@restful
def validate_token(*args, **kwargs):
    """
    validate token
    :return:
    {
    'rst': 'ok',
    'data': {
        'id': '87cb4da3919a47688d6a0669ea366fed',
        'name': 'admin',
        'roles': {
            'ucmp': {
                'id': '1278945210e1458290cdde9417e0d7d1',
                'name': 'atowflow管理员',
                'role_ctl': {"F5": {"ip": ["192.168.1.1"]},
                                "ECS": {"vm": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                "Nas": {"app": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                'role_data': 'ucmp_root',
                'comments': ''
            },
            'cmdb': {
                'id': '76b8508b61a34855a736d8f785f112e8',
                'name': '租户管理员',
                'role_ctl': {"F5": {"ip": ["192.168.1.1"]},
                                "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}}',
                'role_data': 'cmdb_root',
                'comments': ''
            }
        },
        'token': 'gAAAAABcU_XFLUO85FY82xc3qB_-Q6ySf-VSltsXecq1MFom4DCDGXE4n4ctFiopMjOXNV0ehFxoKG7KUB_ZzkLu9Rh7LWaXRT
                            vRVVYtQF014RQd0gRVG7nqXWqx4ejuIFYdqBB6tzy3kCIW-csYXFSTSuYyJbrVx0SY3jcJzinMFDktS0rv3ok',
        'project_id': '0eb082df17d44c8abf46414d8a1397f8',
        'project_name': 'admin',
        'domain_id': 'default',
        'domain_name': 'Default',
        'token_expires_at': '2019-02-02T07:31:17.000000Z'
        }
    }
    """
    try:
        token = request.headers.get('X-Subject-Token')
        check_param_is_null(dict(token=token))
        log.info("get token: %s" % token)
        user_info = token_validate(token)
        return user_info
    except KeystoneHandleException as e:
        log.error("validate_token-KeystoneHandleException: %s" % str(e))
        raise AuthException(e.msg)
    except Exception as e:
        log.error("validate_token-Exception: %s" % str(e))
        raise AuthException("validate_token-Exception: Auth Failed")


@users_site.route('/domain/list', methods=['GET'])
@restful
def list_domains(*args, **kwargs):
    """
    get domain list
    :return:
    {
    'rst': 'ok',
    'data': {
        'domains': [{
                    'name': 'leaptocloud',
                    'id': '39c4ab7a91474111bddfd3e160e5a361'
                },
                {
                    'name': 'guardian',
                    'id': '2cf2952e868a41a18a2fa9cdd0268990'
                },
                {
                    'name': 'Default',
                    'id': 'default'
                }]
            }
    }
    """
    domain = list_domain()
    tmp_domain_list = domain['domains']
    domains_list = []
    for domain_dict in tmp_domain_list:
        domain_item = {
            'name': domain_dict["name"],
            'id': domain_dict["id"]
        }
        if domain_dict['name'] == LOGIN_DEFAULT_DOMAIN_NAME:
            domains_list.insert(0, domain_item)
            continue
        domains_list.append(domain_item)

    return {"domains": domains_list}


@users_site.route('/login', methods=['POST'])
@restful
def login_user(*args, **kwargs):
    """
    request body
    {
       "domain_id": "1789d1",
       "username": "James Doe",
       "password": "secretsecret"
    }
    :param args:
    :param kwargs:
    :return: code:-1 用户或密码为空 0 用户不存在或用户名大小写不符 1 帐号被禁用 2 登录成功 3用户认证失败
            {
            'rst': 'ok',
            'data': {'code': 2,
                    'first_login': False,
                    'user_id': '87cb4da3919a47688d6a0669ea366fed',
                    'username': 'admin',
                    'login_project_id': '0eb082df17d44c8abf46414d8a1397f8',
                    'checkout_project': False
                    }
            }
    """
    data_json = request.get_json()
    domain_id = data_json.get('domain_id', DEFAULT_DOMAIN_ID)
    user_name = data_json.get('username', '')
    user_passwd = data_json.get('password', '')
    lower_username = user_name.lower()

    if not user_name and not user_passwd:
        return {"code": -1}
    # do username case sensitive judge
    sys_conf = SysInfoConfModel().get_one()
    if sys_conf:
        if sys_conf.case_sensitive:
            user_info = UsersModel.get_user_by_username_domain(user_name, domain_id)
        else:
            user_info = UsersModel.get_user_by_lower_username_domain(lower_username, domain_id)
    else:
        raise Exception("Please init system config info with sys_info_conf.")
    if not user_info:
        return {"code": 0}
    if not user_info.enable:
        return {"code": 1}
    token = user_login(user_info.username, user_passwd, domain_id, user_info.user_id, user_info.default_project_id)
    if not token:
        return {"code": 3}
    roles_info = get_roles_by_user_id(user_id=user_info.user_id)
    # Check user has the right to switch project
    checkout_project = False
    for (platform, role) in roles_info.items():
        log.info('role_data is %s', roles_info[platform].get('role_data'))
        if UCMP_ROLE_KIND_ROOT in roles_info[platform].get('role_data', '') or CMDB_ROLE_KIND_ROOT in roles_info[
            platform].get('role_data', '') or ATOMFLOW_ROLE_KIND_ROOT in roles_info[platform].get('role_data', '') \
                or GUARDIAN_ROLE_KIND_ROOT in roles_info[platform].get('role_data', ''):
            checkout_project = True
            break
        else:
            checkout_project = False
    rst_data = {
        "code": 2,
        "first_login": user_info.first_login,
        "user_id": user_info.user_id,
        "username": user_name,
        "login_project_id": user_info.default_project_id,
        "__token": token,
        "checkout_project": checkout_project
    }
    return rst_data


@users_site.route('/login/scope_project', methods=['POST'])
@restful
def login_user_scope_project(*args, **kwargs):
    """
        API  for java
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {'user_id': '87cb4da3919a47688d6a0669ea366fed',
                'login_project_id': 'c5143669f6ac4db6b47c3f703ca2e82a'}
    }
    """
    data_json = request.get_json()
    project_id = data_json.get('project_id', '')
    user_id = data_json.get('user_id', '')
    user_passwd = data_json.get('password', '')
    token = login_scope_project(user_id=user_id, project_id=project_id, password=user_passwd)
    rst_data = {
        "user_id": user_id,
        "login_project_id": project_id,
        "__token": token
    }
    return rst_data


@users_site.route('/logout', methods=['GET'])
@restful
def logout_user(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return: {
                "rst": "ok",
                "data": {}
            }
    """
    token = kwargs.get("user").get('token')
    check_param_is_null(dict(token=token))
    log.info('logout token is %s', token)
    logout(token)
    token_cache = cache.delete("Token_%s" % token)
    log.info('token_cache is %s', token_cache)
    if not token_cache == 1:
        log.error("Clear token %s cache error", token)
    return {}


@users_site.route('/create', methods=['POST'])
@restful
def create_user(*args, **kwargs):
    """
    request body
    {
        "name": "taikanglife",
        "realname": "chenxu.bai",
        "password": "123456",
        "default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "tel": "029-88880000",
        "phone": "15691880739",
        "email": "383656225@qq.com",
        "enabled": 0,
        "comments": "",
        "domain_id": "default",
        "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
        "org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]
     }
    :param args:
    :param kwargs:
    :return: {
                "rst": "ok",
                "data": {}
            }
    """
    data_json = request.get_json()
    domain_id = data_json.get('domain_id', DEFAULT_DOMAIN_ID)
    name = data_json.get('name')
    realname = data_json.get('realname')
    password = data_json.get('password')
    project_id = data_json.get('default_project_id')
    tel = data_json.get('tel', '')
    phone = data_json.get('phone', '')
    email = data_json.get('email', '')
    enabled = data_json.get('enabled')
    comments = data_json.get('comments', '')
    org_id = data_json.get('org_id')
    org_array = data_json.get('org_array')
    # check params null value
    check_param_is_null(dict(name=name, realname=realname, project_id=project_id, org_id=org_id, enabled=enabled))

    if enabled not in [ON, OFF]:
        log.error("params [is_on] must be 0/1; but get %s" % str(enabled))
        raise ParamsException("params [is_on] must be 0/1; but get %s" % str(enabled))

    user_resp = keystone_create_user(domain_id=domain_id, user_name=name, passwd=password, project_id=project_id,
                                     enabled=True if enabled == ON else False)

    if not user_resp.get('user'):
        log.error("Create user error with keystone")
        raise KeystoneHandleException("Create user error with keystone")
    user_id = user_resp['user'].get('id')
    # binding keystone default role in order to authentication token
    role_id = keystone_query_role(KEYSTONE_DEFAULT_ROLE_NAME)
    keystone_binding_role(project_id=project_id, userid=user_id, roleid=role_id[0].get('id'))

    org_obj = UsersOrgsModel(id=org_id).get_one()
    if not org_obj:
        log.error("params [org_info] not found; org_id is %s" % str(org_id))
        raise ParamsException("params [org_info] not found; org_id is %s" % str(org_id))
    UsersModel.create_user(user_id=user_id, username=name, realname=realname, email=email, tel=tel, phone=phone,
                           org_id=org_id, domain_id=domain_id, enable=enabled, first_login=True,
                           comments=comments, org_array=org_array, default_project_id=project_id,
                           object_suid=None, dn=None, user_code=None, lower_name=name.lower(),
                           org_name=org_obj.org_name)
    return {}


@users_site.route('/update', methods=['POST'])
@restful
def update_user(*args, **kwargs):
    """
        request body
        {
            "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
            "name": "taikanglife",
            "realname": "chenxu.bai",
            "password": "123456",
            "default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "tel": "029-88880000",
            "phone": "15691880739",
            "email": "383656225@qq.com",
            "enabled": 0,
            "comments": "",
            "domain_id": "default",
            "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
            "org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]
         }
        :param args:
        :param kwargs:
        :return: {
                    "rst": "ok",
                    "data": {"id": "51b0c1ee68ed4a7e86fffe71357f95b8"}
                }
        """
    data_json = request.get_json()
    user_info = {
        "domain_id": data_json.get('domain_id', DEFAULT_DOMAIN_ID),
        "username": data_json.get('name'),
        "realname": data_json.get('realname'),
        "email": data_json.get('email', ''),
        "tel": data_json.get('tel', ''),
        "phone": data_json.get('phone', ''),
        "org_id": data_json.get('org_id'),
        "comments": data_json.get('comments', ''),
        "org_array": json.dumps(data_json.get('org_array')),
        "enable": data_json.get('enabled'),
        "default_project_id": data_json.get('default_project_id'),
        "user_id": data_json.get('id'),
        "password": data_json.get('password')
    }
    # check params null value
    check_param_is_null(dict(user_id=user_info.get('user_id'), project_id=user_info.get('default_project_id')))

    if user_info.get('enable') not in [ON, OFF]:
        log.error("params [is_on] must be 0/1; but get %s" % str(user_info.get('enable')))
        raise ParamsException("params [is_on] must be 0/1; but get %s" % str(user_info.get('enable')))

    user_obj = UsersModel.get_one(user_id=user_info.get('user_id'))
    if not user_obj:
        log.error("can not found user by id [%s]" % str(user_info.get('user_id')))
        raise ParamsException("can not found user by id [%s]" % str(user_info.get('user_id')))

    user_resp = keystone_update_user(domain_id=user_info.get('domain_id'), user_id=user_info.get('user_id'),
                                     passwd=user_info.get('password'), project_id=user_info.get('default_project_id'),
                                     enable=True if user_info.get('enable') == ON else False)
    if not user_resp.get('user'):
        log.error("Update user error with keystone")
        raise Exception("Update user error with keystone")

    org_obj = UsersOrgsModel(id=data_json.get('org_id')).get_one()
    if not org_obj:
        log.error("params [org_info] not found; org_id is %s" % str(data_json.get('org_id')))
        raise ParamsException("params [org_info] not found; org_id is %s" % str(data_json.get('org_id')))
    user_info['org_name'] = org_obj.org_name
    UsersModel.update_user(user_obj, kwargs=user_info)

    return {"id": user_resp.get('user')['id']}


@users_site.route('/passwd/reset', methods=['POST'])
@restful
def reset_user_passwd(*args, **kwargs):
    """
    request body
{
    "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
    "domain_id": "default"
}
    :param args:
    :param kwargs:
    :return: {
                "rst": "ok",
                "data": {"reset_passwd": "123456"}
            }
    """
    data_json = request.get_json()
    user_info = {
        "domain_id": kwargs.get("user").get("domain_id"),
        "user_id": data_json.get('id')
    }
    # check params null value
    check_param_is_null(dict(user_id=user_info.get('user_id')))

    user_obj = UsersModel.get_one(user_id=user_info.get('user_id'))
    if not user_obj:
        log.error("can not found user by id [%s]" % str(user_info.get('user_id')))
        raise ParamsException("can not found user by id [%s]" % str(user_info.get('user_id')))

    user_resp = keystone_update_user(domain_id=user_info.get('domain_id'), user_id=user_info.get('user_id'),
                                     user_name=user_obj.username, passwd=RESET_LOGIN_PASSWD,
                                     project_id=user_obj.default_project_id)
    if not user_resp.get('user'):
        log.error("Update user error with keystone")
        raise Exception("Update user error with keystone")

    user_obj.update_user_first_login(first_login=True)
    return {"reset_passwd": RESET_LOGIN_PASSWD}


@users_site.route('/passwd/modify', methods=['POST'])
@restful
def modify_user_passwd(*args, **kwargs):
    """
    request body
    {
        "new_passwd":"12345678",
        "original_passwd":"123456"
    }
    :param args:
    :param kwargs:
    :return: code: 0 旧密码错误 1 密码修改成功
    {
        "rst": "ok",
        "data": {"code": 1}
    }
    """
    data_json = request.get_json()
    user_info = {
        "password": data_json.get('new_passwd'),
        "original_password": data_json.get('original_passwd'),
    }
    # check params null value
    check_param_is_null(dict(password=user_info.get('password'), original_password=user_info.get('original_password')))
    user = kwargs.get("user")
    user_id = user["id"]
    user_obj = UsersModel.get_one(user_id=user_id)
    if not user_obj:
        log.error("can not found user by id [%s]" % str(user_info.get('user_id')))
        raise ParamsException("can not found user by id [%s]" % str(user_info.get('user_id')))

    code = keystone_change_user_password(user_id, user_info.get('password'), user_info.get('original_password'))
    if code == 204:
        user_obj.update_user_first_login(first_login=False)
        return {"code": 1}
    else:
        return {"code": 0}


@users_site.route('/delete', methods=['DELETE'])
@restful
def delete_user(*args, **kwargs):
    """
    delete user
    :param args:user_id
    :param kwargs:
    :return:{'rst': 'ok', 'data': {'id': '26ca9a3101b04c449f1c60602e30ebee'}}
    """
    user_id = request.args.get("user_id")
    # check params null value
    check_param_is_null(dict(user_id=user_id))
    delete_user_roles_info = get_roles_by_user_id(user_id=user_id)
    for (platform, role) in delete_user_roles_info.items():
        if UCMP_ROLE_KIND_ROOT in delete_user_roles_info[platform].get('role_data', '') or CMDB_ROLE_KIND_ROOT in \
                delete_user_roles_info[platform].get('role_data', '') or ATOMFLOW_ROLE_KIND_ROOT in \
                delete_user_roles_info[platform].get('role_data', '') or GUARDIAN_ROLE_KIND_ROOT in \
                delete_user_roles_info[platform].get('role_data', ''):
            log.error("Delete user role is administrator [%s]" % str(user_id))
            raise ParamsException("Delete user role is administrator [%s]" % str(user_id))

    user_obj = UsersModel.get_one(user_id=user_id)
    if not user_obj:
        log.error("Can not found user by id [%s]" % str(user_id))
        raise ParamsException("can not found user by id [%s]" % str(user_id))
    if user_obj.username == INIT_ROOT_NAME:
        log.error("Can not delete this user")
        raise ParamsException("Can not delete this user")
    res_code = keystone_delete_user(user_obj.user_id)
    if res_code == 204:
        UsersModel.delete_user(user_id=user_obj.user_id)
        clear_user_token_relationcache(user_ids_list=[user_obj.user_id])
        return {"id": user_obj.user_id}
    else:
        log.error("Delete user with keystone failed")
        raise Exception("Delete user with keystone failed")


@users_site.route('/check', methods=['GET'])
@restful
def get_users_by_username(*args, **kwargs):
    """
    :param args: username
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'id': '6bf790530de0427bb176ca06e2f197ee',
            'name': 'taikang7',
            'realname': 'chenxu.ba',
            'default_project_id': '0eb082df17d44c8abf46414d8a1397f8',
            'tel': '15691880739',
            'phone': '15691880739',
            'email': '383656225@qq.com',
            'enabled': 1,
            'comments': '',
            'domain_id': 'default',
            'org_id': 'ec6f498747c04f6c8e0fdbb1ef220595',
            'org_name': 'test13',
            'org_array': ['c2d3ec86-84b6-4b02-9e5e-df5c573976d3',
                'e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a'],
            'user_code': None
        }
    }
    """
    domain_id = kwargs.get("user").get("domain_id")
    # filter user by username
    username = request.args.get("username", "")
    if not username:
        log.error("params 'username' maybe missing")
        raise ParamsException("params 'username' maybe missing")
    if username == INIT_ROOT_NAME:
        log.error("'username' CAN NOT BE THIS ")
        raise ParamsException("'username' CAN NOT BE THIS ")
    user_obj = UsersModel.get_user_by_username_domain(username, domain_id)
    if not user_obj:
        log.info("Can not found user by username [%s]" % username)
        return {}
    return {
        "id": user_obj.user_id,
        "name": user_obj.username,
        "realname": user_obj.realname,
        "default_project_id": user_obj.default_project_id,
        "tel": user_obj.tel,
        "phone": user_obj.phone,
        "email": user_obj.email,
        "enabled": user_obj.enable,
        "comments": user_obj.comments,
        "domain_id": user_obj.domain_id,
        "org_id": user_obj.org_id,
        "org_array": json.loads(user_obj.org_array),
        "user_code": user_obj.user_code,
        "org_name": user_obj.org_name
    }


@users_site.route('/inside/lists', methods=['POST'])
@restful
def inside_list_users(*args, **kwargs):
    """
    API for Go
    request body
    {
        "user_ids":["200876f2479f4566b1364badc5ed4c1d","c38a4fd167144400b8a3cfd0f5e6ea73"]
    }
    :param args:
    :param kwargs:
    :return: {
               'rst': 'ok',
               'data': {
                       'user_infos': [{
                                      'id': '89f71e87c85a45fdb9cb3c0f4a818073',
                                      'name': 't_3',
                                      'realname': 'dwlal1',
                                      'org_id': 'c2d3ec86-84b6-4b02-9e5e-df5c573976d3'
                                       },
                                      {
                                      'id': '87cb4da3919a47688d6a0669ea366fed',
                                      'name': 'admin',
                                      'realname': '管理员',
                                      'org_id': '7249332a-f7fc-4a84-9a00-77008713f92e'
                                     }]
                        }
             }
    """
    data_json = request.get_json()
    user_ids = data_json.get('user_ids', [])
    if not user_ids:
        log.error("params 'user_ids' maybe missing")
        raise ParamsException("params 'user_ids' maybe missing")
    filters = {'user_id_list': user_ids}
    count, user_lists = UsersModel.get_list(**filters)
    res = []
    for user in user_lists:
        res.append({
            "id": user.user_id,
            "name": user.username,
            "realname": user.realname,
            "org_id": user.org_id
        })
    return {'user_infos': res}


@users_site.route('/lists', methods=['GET'])
@restful
def list_users(*args, **kwargs):
    """
    user_ids, user_id_list
    :param args: limit, page, username, realname, email, tel, phone, org_name, domain_id, enable, object_suid, user_code
    :param kwargs:
    :return:  {
               'rst': 'ok',
               'data': {
                        'users': [{
                            'id': '6bf790530de0427bb176ca06e2f197ee',
                            'name': 'taikang7',
                            'realname': 'chenxu.ba',
                            'default_project_id': '0eb082df17d44c8abf46414d8a1397f8',
                            'tel': '15691880739',
                            'phone': '15691880739',
                            'email': '383656225@qq.com',
                            'enabled': 1,
                            'comments': '',
                            'domain_id': 'default',
                            'org_id': 'ec6f498747c04f6c8e0fdbb1ef220595',
                            'org_array': ['c2d3ec86-84b6-4b02-9e5e-df5c573976d3',
                                          'e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a'],
                            'user_code': None,
                            'org_name': 'test12'
                       },
                      {
                            'id': '87cb4da3919a47688d6a0669ea366fed',
                            'name': 'admin',
                            'realname': '管理员',
                            'default_project_id': '0eb082df17d44c8abf46414d8a1397f8',
                            'tel': None,
                            'phone': None,
                            'email': 'sd@leaptocloud.com',
                            'enabled': 1,
                            'comments': None,
                            'domain_id': 'default',
                            'org_id': 'ec6f498747c04f6c8e0fdbb1ef220595',
                            'org_array': ['c2d3ec86-84b6-4b02-9e5e-df5c573976d3',
                                          'e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a'],
                            'user_code': '123456',
                            'org_name': 'test13'
                       }],
                     'page': 1,
                     'page_count': 1,
                     'total': 2
               }
        }
    """
    user = kwargs.get("user")
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page_idx', default=1, type=int)
    filters = {
        "default_project_id": user["project_id"],
        "username": request.args.get("name", ""),
        "user_id": request.args.get("user_id", ""),
        "user_ids": request.args.get("user_ids", ""),
        "user_id_list": request.args.get("user_id_list", []),
        "realname": request.args.get("name", ""),
        "email": request.args.get("email", ""),
        "tel": request.args.get("tel", ""),
        "phone": request.args.get("phone", ""),
        "org_id": request.args.get("org_id", ""),
        "org_name": request.args.get("org_name", ""),
        "org_ids": request.args.get("org_array", ""),
        "domain_id": request.args.get("domain_id", ""),
        "object_suid": request.args.get("object_suid", ""),
        "enable": request.args.get("enable", ""),
        "user_code": request.args.get("user_code", "")
    }
    count, user_lists = UsersModel.get_list(page_idx=page_idx, limit=limit, **filters)
    res = []

    for user in user_lists:
        if user.username != INIT_ROOT_NAME:
            res.append({
                "id": user.user_id,
                "name": user.username,
                "realname": user.realname,
                "default_project_id": user.default_project_id,
                "tel": user.tel,
                "phone": user.phone,
                "email": user.email,
                "enabled": user.enable,
                "comments": user.comments,
                "domain_id": user.domain_id,
                "org_id": user.org_id,
                "org_name": user.org_name,
                "org_array": json.loads(user.org_array) if user.org_array else [],
                "user_code": user.user_code
            })
    log.info('user data is %s', res)
    return {
        "users": res,
        "page": page_idx,
        "page_count": math.ceil(count / limit),
        "total": count
    }


@users_site.route('/detail', methods=['GET'])
@restful
def user_detail(*args, **kwargs):
    """
    :param args: user_id
    :param kwargs:
    :return: {
                    "rst": "ok",
                    "data": {
                        "id": "51b0c1ee68ed4a7e86fffe71357f95b8",
                        "name": "taikanglife",
                        "realname": "chenxu.bai",
                        "default_project_id": "0eb082df17d44c8abf46414d8a1397f8",
                        "tel": "029-88880000",
                        "phone": "15691880739",
                        "email": "383656225@qq.com",
                        "enabled": 0,
                        "comments": "",
                        "domain_id": "default",
                        "org_id": "e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a",
                        "org_name": "test1",
                        "org_array": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3","e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]
                        "org_name_array": ["test1","test2"]
                    }
                }
    """
    user_id = request.args.get("user_id")
    # check params null value
    check_param_is_null(dict(user_id=user_id))

    user_obj = UsersModel.get_one(user_id=user_id)
    if user_obj:
        org_ids = ",".join(json.loads(user_obj.org_array))
        filters = {'ids': org_ids}
        total_count, org_list = UsersOrgsModel.get_list(**filters)
        org_code = ""
        org_name_array = []
        for org in org_list:
            org_name_array.append(org.org_name)
            if org.id == user_obj.org_id:
                org_code = "%s-%s" % (org.parent_code, org.node_id) if org.parent_code else "%s" % org.node_id
        res = {
            "id": user_obj.user_id,
            "name": user_obj.username,
            "realname": user_obj.realname,
            "default_project_id": user_obj.default_project_id,
            "tel": user_obj.tel,
            "phone": user_obj.phone,
            "email": user_obj.email,
            "enabled": user_obj.enable,
            "comments": user_obj.comments,
            "domain_id": user_obj.domain_id,
            "org_id": user_obj.org_id,
            "org_name": user_obj.org_name,
            "org_array": json.loads(user_obj.org_array),
            "org_name_array": org_name_array[::-1],
            "org_code": org_code
        }
    else:
        log.debug("Can not found user by id [%s]" % str(user_id))
        res = {}
    return res


@users_site.route('/domain/check', methods=['GET'])
@restful
def check_user_email(*args, **kwargs):
    """
    :param args: email
    :param kwargs:
    :return: {'rst': 'ok', 'data': {}}  //该域下email不重复
            {'rst': 'ok', 'data': {'user_id': '200876f2479f4566b1364badc5ed4c1d'}}  //该域下email重复
    """
    email = request.args.get("email")
    domain_id = kwargs.get("user").get('domain_id')
    log.info('domain_id is %s', domain_id)
    # check params null value
    check_param_is_null(dict(email=email))
    user_obj = UsersModel.get_user_by_email_domain(email=email, domain_id=domain_id)
    if user_obj:
        return {'user_id': user_obj.user_id}
    return {}


@users_site.route('/list/dept/admin', methods=['GET'])
@restful
def get_dept_role_users(*args, **kwargs):
    """
    :param args:org_id
                local_user：0 查询子、父组织机构管理员
                            1 查询当前子组织机构管理员
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'users_info': [{
                'project_id': '7fca4022faba4ba69d8cd42de409dab2',
                'user_id': '11fb50ce59ef48d3a7653c2360eb8799',
                'org_name': '',
                'org_id': '',
                'phone': '',
                'email': 'superadmin@company.com',
                'username': 'superadmin',
                'realname': 'superadmin',
                'comments': 'superadmin',
                'domain_id': '8deb6204a1e54d24b81af996490b8e92'
            }]
        }
    }
    """
    org_id = request.args.get("org_id")
    local_user = request.args.get("local_user")
    # check params null value
    check_param_is_null(dict(org_id=org_id))
    if local_user:
        users_info = query_dept_role_users_by_local_org_id(org_id=org_id)

    else:
        users_info = query_dept_role_users_by_org_id(org_id=org_id)
    res = []
    for user in users_info:
        res.append({"project_id": user.default_project_id,
                    "user_id": user.user_id,
                    "org_name": user.org_name,
                    "org_id": user.org_id,
                    "phone": user.phone,
                    "email": user.email,
                    "username": user.username,
                    "realname": user.realname,
                    "comments": user.comments,
                    "domain_id": user.domain_id
                    })
    return {"users_info": res}


@users_site.route('/list/roles/admin', methods=['GET'])
@restful
def get_users_by_role_type(*args, **kwargs):
    """
    :param args: role_type
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'users_info': [{
                'project_id': '7fca4022faba4ba69d8cd42de409dab2',
                'user_id': '11fb50ce59ef48d3a7653c2360eb8799',
                'org_name': '',
                'org_id': '',
                'phone': '',
                'email': 'superadmin@company.com',
                'username': 'superadmin',
                'realname': 'superadmin',
                'comments': 'superadmin',
                'domain_id': '8deb6204a1e54d24b81af996490b8e92'
            }]
        }
    }
    """
    role_data = request.args.get("role_data")
    project_id = kwargs.get("user").get("project_id")
    # check params null value
    check_param_is_null(dict(role_data=role_data))
    if role_data == UCMP_ROLE_KIND_ADMIN:
        users_info = get_users_by_role_data(role_data=UCMP_ROLE_KIND_ADMIN, project_id=project_id)
    elif role_data == UCMP_ROLE_KIND_ROOT:
        users_info = get_users_by_role_data(role_data=UCMP_ROLE_KIND_ROOT)
    else:
        raise ParamsException("'role_data' not in [ucmp_root, ucmp_admin],please check params")
    res = []
    for user in users_info:
        res.append({"project_id": user.default_project_id,
                    "user_id": user.user_id,
                    "org_name": user.org_name,
                    "org_id": user.org_id,
                    "phone": user.phone,
                    "email": user.email,
                    "username": user.username,
                    "realname": user.realname,
                    "comments": user.comments,
                    "domain_id": user.domain_id
                    })
    return {"users_info": res}


@users_site.route('/list/administrator', methods=['POST'])
@restful
def get_administrator_users_by_role_id(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    request body:
    {
            "role_id": "ad822b337d884cbb9b84f61a39aff904",
            "org_id": "5aa0028069314b469d69bd5b586dd0a9"
        }
    :return:{
    'rst': 'ok',
    'data': {
    'users_info': [{
            'project_id': '0eb082df17d44c8abf46414d8a1397f8',
            'user_id': '881347b05ed4411fba95b8caac275a03',
            'org_name': 'test11',
            'org_id': '5aa0028069314b469d69bd5b586dd0a9',
            'phone': '15691880736',
            'email': '123456789@qq.com',
            'username': 'zhangxiaofeng',
            'realname': 'zhangxiaofeng7891',
            'comments': '',
            'domain_id': 'default'
      }]
    }
}
    """
    data = request.get_json()
    role_id = data.get('role_id', '')
    if not role_id:
        raise ParamsException("'role_id' maybe missing")
    org_id = data.get('org_id', '')
    # TODO need add app administrator and business administrator
    # judge what type of role belongs to
    role_type = None
    for key, value in INIT_ROLE_ID.get(PLATFORM_UCMP).items():
        if role_id == value:
            role_type = key
            break
    if not role_type or role_type != DEPT_ADMIN:
        raise ParamsException("'role_id' maybe missing or Non-conformity")
    # query users by role_id
    users_info = query_init_dept_role_users_by_org_id(org_id=org_id, role_id=role_id)
    res = []
    for user in users_info:
        res.append({"project_id": user.default_project_id,
                    "user_id": user.user_id,
                    "org_name": user.org_name,
                    "org_id": user.org_id,
                    "phone": user.phone,
                    "email": user.email,
                    "username": user.username,
                    "realname": user.realname,
                    "comments": user.comments,
                    "domain_id": user.domain_id
                    })
    return {"users_info": res}


@users_site.route('/roles/create', methods=['POST'])
@restful
def create_role(*args, **kwargs):
    """
    request body
    {
        "name": "平台管理员",
        "role_model_menu":[{
                        "module_id":"3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                        "sub_menu":["a7a053ba-2473-49be-8e94-9826a24b484b"]
                    }],
        'role_data': 'ucmp_root',
        "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                      "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                      "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
        "comments": "",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "platform_name": "ucmp"
     }
    :param args:
    :param kwargs:
    :return: {'rst': 'ok', 'data': {}}
    """
    project_id = kwargs.get("user").get('project_id')
    role_info = request.get_json()
    role_info['project_id'] = project_id
    # check params null value
    check_param_is_null(dict(name=role_info.get('name'), project_id=role_info.get('project_id')))
    role_obj = UserRolesModel.get_role_by_name(role_name=role_info.get('name'))
    if role_obj:
        log.error("Create role is exist [%s], Please check your params" % str(role_info.get('name')))
        raise ParamsException("Create role is exist [%s], Please check your params" % str(role_info.get('name')))
    role_id = UserRolesModel().create_role(role_data=role_info)
    model_menu_info = role_info.get('role_model_menu', [])
    relation_data = []
    for model in model_menu_info:
        for menu in model.get('sub_menu'):
            relation_data.append({'id': uuid.uuid4().hex,
                                  'role_id': role_id,
                                  'module_id': model.get('module_id'),
                                  'menu_id': menu})
    log.info('relation_data is %s', relation_data)
    UserRolePermissionModel().create_menu_premission(relation_data=relation_data)
    return {}


@users_site.route('/roles/check', methods=['GET'])
@restful
def check_role_by_name(*args, **kwargs):
    """
    :param args: role_name
    :param kwargs:
    :return:
    {'rst': 'ok', 'data': {}}  校验的角色不存在
    {'rst': 'ok', 'data': {"id": "485abaa031dd42f291d167cf723a904e"}}  校验的角色存在
    """
    role_name = request.args.get("role_name")
    if role_name == INIT_ROOT_NAME:
        return {}
    check_param_is_null(dict(role_name=role_name))
    role_obj = UserRolesModel.get_role_by_name(role_name=role_name)
    if not role_obj:
        return {}
    return {'role_id': role_obj.id}


@users_site.route('/roles/update', methods=['POST'])
@restful
def update_role(*args, **kwargs):
    """
    request body
    {
        "id": "485abaa031dd42f291d167cf723a904e",
        "name": "平台管理员",
        "role_model_menu": [{
                        "module_id":"3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                        "sub_menu":["a7a053ba-2473-49be-8e94-9826a24b484b"]
                    }],
        'role_data': 'ucmp_root',
        "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                      "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                      "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
        "comments": ""
     }
    :param args:
    :param kwargs:
    :return: {'rst': 'ok', 'data': {"id": "485abaa031dd42f291d167cf723a904e"}}
    """
    role_info = request.get_json()
    # check params null value
    check_param_is_null(dict(name=role_info.get('name'),
                             role_id=role_info.get('id')))
    roles_info = kwargs.get("user").get('roles', {})
    allow_role_list = judge_allow_role_list(roles_info)

    role_obj = UserRolesModel(id=role_info.get('id')).get_one()
    if not role_obj:
        log.error("Can not found role by id [%s]" % str(role_info.get('id')))
        raise ParamsException("Can not found role by id [%s]" % str(role_info.get('id')))

    if role_obj.role_data not in allow_role_list:
        log.error("Permission denied update role by id [%s]" % str(role_info.get('id')))
        raise ParamsException("Permission denied update role by id [%s]" % str(role_info.get('id')))

    role_info['role_ctl'] = json.dumps(role_info.get("role_ctl", ''))

    UserRolesModel.update_role(role_obj, kwargs=role_info)
    model_menu_info = role_info.get("role_model_menu", [])
    relation_data = []
    for model in model_menu_info:
        for menu in model.get('sub_menu'):
            relation_data.append({'role_id': role_info.get('id'),
                                  'module_id': model.get('module_id'),
                                  'menu_id': menu,
                                  'id': uuid.uuid4().hex}),
    UserRolePermissionModel().update_menu_premission(role_id=role_info.get('id'), relation_data=relation_data)
    # clear dependent token
    user_role_obj = UserRoleRelationShip.get_one_by_role_id(role_id=role_info.get('id'))
    user_list = [role.user_id for role in user_role_obj]
    clear_user_token_relationcache(user_ids_list=user_list)
    return {"id": role_info.get('id')}


@users_site.route('/roles/delete', methods=['DELETE'])
@restful
def delete_role(*args, **kwargs):
    """

    :param args: role_id
    :param kwargs:
    :return: {'rst': 'ok', 'data': {"id": "485abaa031dd42f291d167cf723a904e"}}
    """
    role_id = request.args.get("role_id")
    # check params null value
    check_param_is_null(dict(role_id=role_id))
    roles_info = kwargs.get("user").get('roles', {})
    allow_role_list = judge_allow_role_list(roles_info)
    for platform, role in INIT_ROLE_ID.items():
        if role_id in role.values():
            log.error("Can not delete init role by id [%s]" % str(role_id))
            raise ParamsException("Can not delete init role by id [%s]" % str(role_id))
    role_obj = UserRolesModel(id=role_id).get_one()
    if role_obj.name == INIT_ROOT_NAME:
        log.error("Permission denied delete role")
        raise ParamsException("Permission denied delete role")
    if not role_obj:
        log.error("Can not found role by id [%s]" % str(role_id))
        raise ParamsException("Can not found role by id [%s]" % str(role_id))
    if role_obj.role_data not in allow_role_list:
        log.error("Permission denied delete role by id [%s]" % str(role_id))
        raise ParamsException("Permission denied delete role by id  [%s]" % str(role_id))
    UserRolesModel.delete_role(role_obj)
    UserRoleRelationShip.delete_relation_by_role_id(role_id=role_id)
    UserRolePermissionModel.delete_menu_preemission_by_role(role_id=role_id)

    # clear dependent token
    user_role_obj = UserRoleRelationShip.get_one_by_role_id(role_id=role_id)
    user_list = [role.user_id for role in user_role_obj]
    clear_user_token_relationcache(user_ids_list=user_list)
    return {'id': role_id}


@users_site.route('/roles/assign', methods=['POST'])
@restful
def assign_user_role(*args, **kwargs):
    """
    request body
    {
        user_id : "51b0c1ee68ed4a7e86fffe71357f95b8",
        role_id : ["485abaa031dd42f291d167cf723a904e","1278945210e1458290cdde9417e0d7d1"]
    }
    :param args:
    :param kwargs:
    :return: {'rst': 'ok', 'data': {}}
    """
    data_json = request.get_json()
    token = kwargs.get("user").get("token")
    project_id = kwargs.get("user").get('project_id')
    user_obj = UsersModel.get_one(user_id=data_json.get('user_id'))
    # check params null value
    check_param_is_null(dict(user_id=data_json.get('user_id')))
    user_role_obj = UserRoleRelationShip.get_role_by_user(user_id=data_json.get('user_id'))
    user_role_list = [role.role_id for role in user_role_obj]
    # filter role by project
    role_obj = UserRolesModel.filter_role_by_project(project_id=project_id, role_ids=user_role_list)
    role_list = [role.id for role in role_obj]
    add_role_list = data_json.get('role_id')
    role_name_list = []
    role_obj_list = UserRolesModel.get_all(role_ids=add_role_list)
    for role in role_obj_list:
        role_name_list.append(role.role_data)
    delete_roles = list(set(role_list).difference(set(add_role_list)))
    add_roles = list(set(add_role_list).difference(set(role_list)))
    if delete_roles:
        UserRoleRelationShip.delete_relation(user_id=data_json.get('user_id'), role_ids=delete_roles)
    if add_roles:
        UserRoleRelationShip.add_relation(user_id=data_json.get('user_id'), role_ids=add_roles)

    # clear dependent token
    clear_user_token_relationcache(user_ids_list=[data_json.get('user_id')])
    update_user_role(token=token, user_id=user_obj.user_id, org_id=user_obj.org_id, project_id=project_id,
                     role_list=role_name_list)
    return {}


@users_site.route('/roles/assigned', methods=['GET'])
@restful
def get_user_role(*args, **kwargs):
    """
    :param args: user_id
    :param kwargs:
    :return:
    {
    'rst': 'ok',
    'data': {
            'ucmp': {
                'id': '1278945210e1458290cdde9417e0d7d1',
                'name': 'atowflow管理员',
                'role_ctl': {"F5": {"ip": ["192.168.1.1"]},
                                "ECS": {"vm": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                "Nas": {"app": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                'role_data': 'ucmp_root',
                'comments': ''
            },
            'cmdb': {
                'id': '76b8508b61a34855a736d8f785f112e8',
                'name': '租户管理员',
                'role_ctl': {"F5": {"ip": ["192.168.1.1"]},
                                "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}}',
                'role_data': 'cmdb_root',
                'comments': ''
            }
        }
    }
    """
    user_id = request.args.get("user_id")
    # check params null value
    check_param_is_null(dict(user_id=user_id))
    role_infos = get_roles_by_user_id(user_id=user_id)
    return role_infos


@users_site.route('/roles/detail', methods=['GET'])
@restful
def get_role_detail(*args, **kwargs):
    """
    :param args: role_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data":{
                    "id": "485abaa031dd42f291d167cf723a904e",
                    "name": "平台管理员",
                    'role_data': 'ucmp_root',
                    "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                                  "ECS": {"vsphere": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                  "Nas": {"NetApp": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                    "platform_name": "ucmp",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "comments": ""
                }
     }
    """
    role_id = request.args.get("role_id")
    # check params null value
    check_param_is_null(dict(role_id=role_id))
    role_obj = UserRolesModel(id=role_id).get_one()
    if not role_obj:
        log.error("Can not found role by id [%s]" % str(role_id))
        raise ParamsException("can not found role by id [%s]" % str(role_id))
    return {'id': role_obj.id,
            'name': role_obj.name,
            'role_data': role_obj.role_data,
            'role_ctl': json.loads(role_obj.role_ctl),
            'platform_name': role_obj.platform_name,
            'project_id': role_obj.project_id,
            'comments': role_obj.comments}


@users_site.route('/roles/lists', methods=['GET'])
@restful
def get_role_lists(*args, **kwargs):
    """
    :param args: limit,page,name
    :param kwargs:
    :return:
        {
         "rst": "ok",
         "data": { "roles":
                        [{"id": "1278945210e1458290cdde9417e0d7d1",
                        "name": "atowflow\\u7ba1\\u7406\\u5458",
                        'role_data': 'ucmp_root',
                        "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                                    "ECS": {"vm": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                                    "Nas": {"app": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
                        "platform_name": "ucmp",
                        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                        "comments": ""}],
                  "page": 2,
                  "page_count": 4,
                  "total": 4
                }
        }

    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    project_id = request.args.get('project_id', default=None)
    roles_info = kwargs.get("user").get('roles', {})
    platforms = list(roles_info.keys())
    filters = {
        "project_id": project_id,
        "name": request.args.get("name", ""),
        'platforms': platforms
    }
    count, role_lists = UserRolesModel.get_list(page_idx=page_idx, limit=limit, **filters)
    res = []
    all_role_kind_choices = dict()
    all_role_kind_choices.update(UCMP_ROLE_KIND_CHOICES)
    all_role_kind_choices.update(CMDB_ROLE_KIND_CHOICES)
    all_role_kind_choices.update(ATOMFLOW_ROLE_KIND_CHOICES)
    all_role_kind_choices.update(GUARDIAN_ROLE_KIND_CHOICES)
    for role in role_lists:
        if role.name != INIT_ROOT_NAME:
            res.append({'id': role.id,
                        'name': role.name,
                        'role_data': role.role_data,
                        'role_data_name': all_role_kind_choices.get(role.role_data, ''),
                        'role_ctl': json.loads(role.role_ctl),
                        'platform_name': role.platform_name,
                        'project_id': role.project_id,
                        'comments': role.comments})
    return {
        "roles": res,
        "page": page_idx,
        "page_count": math.ceil(count / limit),
        "total": count
    }


@users_site.route('/roles/allow/lists', methods=['GET'])
@restful
def get_user_allow_role_list(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
    'rst': 'ok',
    'data': {
    'roles': [{
        'id': '0ee3059a68a44aaea809b1aac5e57c5b',
        'name': '云主机管理员',
        'role_data': 'ucmp_admin',
        'role_ctl': {},
        'platform_name': 'ucmp',
        'project_id': '0eb082df17d44c8abf46414d8a1397f8',
        'comments': ''
    }]
    }
}
    """
    project_id = request.args.get('project_id', default=None)
    roles_info = kwargs.get("user").get('roles', {})
    allow_list = judge_allow_role_list(roles_info)
    platforms = list(roles_info.keys())
    log.info('allow role list is %s', allow_list)
    filters = {
        "project_id": project_id,
        'platforms': platforms,
        "role_data_allow_list": allow_list
    }
    count, role_lists = UserRolesModel.get_list(page_idx=1, limit=999999, **filters)
    res = []
    for role in role_lists:
        res.append({'id': role.id,
                    'name': role.name,
                    'role_data': role.role_data,
                    'role_ctl': json.loads(role.role_ctl),
                    'platform_name': role.platform_name,
                    'project_id': role.project_id,
                    'comments': role.comments})
    return {"roles": res}


@users_site.route('/roles/kinds', methods=['GET'])
@restful
def get_role_kinds(*args, **kwargs):
    """
    :param args: platform: 'ucmp','cmdb','atomflow','system'
    :param kwargs:
    :return: {"code": 0} 权限不足
    {
        "rst": "ok",
        "data": {
            "ucmp_root": "超级管理员",
            "ucmp_admin": "租户管理员",
            "ucmp_dept": "部门管理员",
            "ucmp_user": "管理员",
            "ucmp_app": "应用管理员",
            "ucmp_business": "业务管理员"
        }
    }
    """
    platform = request.args.get('platform', default=None)
    role_data = kwargs.get("user").get("roles").get(platform).get("role_data")
    if platform == PLATFORM_UCMP:
        if UCMP_ROLE_KIND_ROOT in role_data:
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_ROOT)
            return UCMP_ROLE_KIND_CHOICES
        elif UCMP_ROLE_KIND_ADMIN in role_data:
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_ROOT)
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_ADMIN)
            return UCMP_ROLE_KIND_CHOICES
        elif UCMP_ROLE_KIND_DEPT in role_data:
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_ROOT)
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_ADMIN)
            UCMP_ROLE_KIND_CHOICES.pop(UCMP_ROLE_KIND_DEPT)
            return UCMP_ROLE_KIND_CHOICES
        else:
            # 权限不足
            return {"code": 0}
    elif platform == PLATFORM_CMDB:
        if CMDB_ROLE_KIND_ROOT in role_data:
            CMDB_ROLE_KIND_CHOICES.pop(CMDB_ROLE_KIND_ROOT)
            return CMDB_ROLE_KIND_CHOICES
        elif CMDB_ROLE_KIND_ADMIN in role_data:
            CMDB_ROLE_KIND_CHOICES.pop(CMDB_ROLE_KIND_ROOT)
            CMDB_ROLE_KIND_CHOICES.pop(CMDB_ROLE_KIND_ADMIN)
            return CMDB_ROLE_KIND_CHOICES
        else:
            # 权限不足
            return {"code": 0}
    elif platform == PLATFORM_ATOMFLOW:
        if ATOMFLOW_ROLE_KIND_ROOT in role_data:
            ATOMFLOW_ROLE_KIND_CHOICES.pop(ATOMFLOW_ROLE_KIND_ROOT)
            return ATOMFLOW_ROLE_KIND_CHOICES
        elif ATOMFLOW_ROLE_KIND_ADMIN in role_data:
            ATOMFLOW_ROLE_KIND_CHOICES.pop(ATOMFLOW_ROLE_KIND_ROOT)
            ATOMFLOW_ROLE_KIND_CHOICES.pop(ATOMFLOW_ROLE_KIND_ADMIN)
            return ATOMFLOW_ROLE_KIND_CHOICES
        else:
            # 权限不足
            return {"code": 0}
    elif platform == PLATFORM_GUARDIAN:
        if GUARDIAN_ROLE_KIND_ROOT in role_data:
            GUARDIAN_ROLE_KIND_CHOICES.pop(GUARDIAN_ROLE_KIND_ROOT)
            return GUARDIAN_ROLE_KIND_CHOICES
        elif GUARDIAN_ROLE_KIND_ADMIN in role_data:
            GUARDIAN_ROLE_KIND_CHOICES.pop(GUARDIAN_ROLE_KIND_ROOT)
            GUARDIAN_ROLE_KIND_CHOICES.pop(GUARDIAN_ROLE_KIND_ADMIN)
            return GUARDIAN_ROLE_KIND_CHOICES
        else:
            # 权限不足
            return {"code": 0}
    else:
        log.error("Can not found platform [%s]" % str(platform))
        raise ParamsException("Can not found platform [%s]" % str(platform))


@users_site.route('/project/create', methods=['POST'])
@restful
def create_project(*args, **kwargs):
    """
    request body
    {
        "name" : "my project",
        "description" : "This is test project"
    }
    :param args:
    :param kwargs: domain_id
    :return:
    {
        "rst": "ok",
        "data": {}
    }
    """
    domain_id = kwargs.get("user").get('domain_id')
    data_json = request.get_json()
    project_name = data_json.get('name')
    project_description = data_json.get('description')
    check_param_is_null(dict(project_name=project_name))
    res = keystone_create_project(domain_id, project_name, project_description)
    project_id = res.get('project').get('id')
    if not project_id:
        log.error("Create project error with keystone")
        raise KeystoneHandleException("Create project error with keystone")
    assign_role_project_to_superuser(project_id)
    return {}


@users_site.route('/project/update', methods=['POST'])
@restful
def update_project(*args, **kwargs):
    """
    request body
    {
        "project_id": "c5143669f6ac4db6b47c3f703ca2e82a",
        "name" : "my project",
        "description" : "This is test project",
        "enabled": true
    }
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {'project_id': 'c5143669f6ac4db6b47c3f703ca2e82a'}
    }
    """
    token_project_id = kwargs.get("user").get('project_id')
    data_json = request.get_json()
    project_id = data_json.get('project_id')
    project_name = data_json.get('name')
    project_description = data_json.get('description')
    project_enabled = data_json.get('enabled')
    check_param_is_null(dict(project_name=project_name, project_id=project_id, project_enabled=project_enabled))
    if str(project_id) == str(token_project_id):
        log.error('Unable to update current project')
        raise ParamsException('Unable to update current project')
    project_info = keystone_get_project_by_id(project_id)
    if not project_info.get('project'):
        log.error("Can not found project by id [%s]" % str(project_id))
        raise ParamsException("can not found project by id [%s]" % str(project_id))
    keystone_update_project(project_id, project_name, project_description, project_enabled)
    return {'project_id': project_id}


@users_site.route('/project/lists', methods=['GET'])
@restful
def list_project(*args, **kwargs):
    """
    :param args:
    :param kwargs: domain_id
    :return:
    {
    'rst': 'ok',
    'data': [{
                 'id': '0eb082df17d44c8abf46414d8a1397f8',
                 'domain_id': 'default',
                 'name': 'admin',
                 'description': '前提',
                 'enabled': true
             },
           {
                'id': '5366a34dd14f487e82480c08289f32d9',
                'domain_id': 'default',
                'name': 'demo',
                'description': 'test',
                'enabled': true
        }]
    }
    """
    domain_id = kwargs.get("user").get('domain_id')
    res = keystone_list_project(domain_id)
    project_list = []
    for project in res.get('projects'):
        log.info('project is %s', project)
        project_list.append({'id': project.get('id', ''),
                             'domain_id': project.get('domain_id', ''),
                             'name': project.get('name', ''),
                             'description': project.get('description', ''),
                             'enabled': project.get('enabled', '')})
    return project_list


@users_site.route('/project/change', methods=['GET'])
@restful
def change_user_project(*args, **kwargs):
    """
    :param args: project_id
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {'user_id': '200876f2479f4566b1364badc5ed4c1d'}
    }
    """
    project_id = request.args.get('project_id')
    old_token = kwargs.get("user").get('token')
    domain_id = kwargs.get("user").get('domain_id')
    user_id = kwargs.get("user").get('id')
    check_param_is_null(dict(project_id=project_id))
    user_obj = UsersModel.get_one(user_id=user_id)
    if not user_obj:
        log.error("can not found user by id [%s]" % str(user_id))
        raise ParamsException("can not found user by id [%s]" % str(user_id))
    user_info = {'default_project_id': project_id}
    # modify user default project
    keystone_update_user(domain_id=domain_id, user_id=user_id, project_id=project_id)
    UsersModel.update_user(user_obj, kwargs=user_info)
    # binding keystone default role in order to authentication token
    role_id = keystone_query_role(KEYSTONE_DEFAULT_ROLE_NAME)
    keystone_binding_role(project_id=project_id, userid=user_id, roleid=role_id[0].get('id'))
    token = keystone_change_user_project(project_id=project_id, token=old_token)
    new_token = token.get('X-Subject-Token')
    # clear dependent token
    clear_user_token_relationcache(user_ids_list=[user_id])
    return {
        "__token": new_token,
        "user_id": user_id
    }


@users_site.route('/org/create', methods=['POST'])
@restful
def create_org(*args, **kwargs):
    """
    {
        "org_name":"新加712",
        "parent_id":"e2f8cb45dc1b43cfaa7c3234971e3e1a"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id": "66749960e6fb4585bf8b2dcf705ea199"
        }
    }
    """
    data = request.get_json()
    if "org_name" not in data or data.get("org_name") == "":
        raise ParamsException("'org_name' maybe missing")
    if "parent_id" not in data:
        raise ParamsException("'parent_id' maybe missing")

    parent_parent_code = None
    parent_node_id = None
    if data.get("parent_id") != "":
        parent_org_obj = UsersOrgsModel(id=data.get("parent_id")).get_one()
        if not parent_org_obj:
            log.error("Can not found org by id [%s]" % data.get("parent_id"))
            raise ParamsException("Can not found org by id [%s]" % data.get("parent_id"))
        parent_parent_code = parent_org_obj.parent_code
        parent_node_id = parent_org_obj.node_id

    max_node_org_obj = UsersOrgsModel().get_max_node_id()
    if max_node_org_obj:
        new_node_id = max_node_org_obj.node_id + 1
    else:
        new_node_id = 1

    user = kwargs.get("user")
    data["project_id"] = user["project_id"]
    data["parent_id"] = data.get("parent_id", "")
    data["mgr_user_id"] = json.dumps(data.get("mgr_user_id", []))
    data["project_id"] = user["project_id"]
    data["domain_id"] = user["domain_id"]
    data["node_id"] = new_node_id

    org_obj = UsersOrgsModel.create_org(parent_parent_code=parent_parent_code, parent_node_id=parent_node_id, **data)
    return {
        "id": org_obj.id
    }


@users_site.route('/org/update', methods=['POST'])
@restful
def update_org_name(*args, **kwargs):
    """
    {
        "id":"cf17c2ab83444379b987a2aba1162857",
        "org_name":"新加712"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "id": "cf17c2ab83444379b987a2aba1162857"
        }
    }
    """
    data = request.get_json()
    must_params = ["id", "org_name"]
    for item in must_params:
        if item not in data or data.get(item) == "":
            raise ParamsException("{0} maybe missing".format(item))
    org_obj = UsersOrgsModel(id=data.get("id")).get_one()
    if not org_obj:
        log.error("can not found org by id [%s]" % data.get("id"))
        raise ParamsException("can not found org by id [%s]" % data.get("id"))
    org_obj = org_obj.update_org(**data)
    UsersModel.update_user_org_name_by_org_id(org_id=org_obj.id, org_name=data.get('org_name'))
    return {
        "id": org_obj.id
    }


@users_site.route('/org/del', methods=['DELETE'])
@restful
def delete_org(*args, **kwargs):
    """
    {
        "id":"cf17c2ab83444379b987a2aba1162857"
    }
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "ids": ["cf17c2ab83444379b987a2aba1162857"]
        }
    }
    """
    data = request.get_json()
    if "id" not in data or data.get("id") == "":
        raise ParamsException("id maybe missing")
    org_obj = UsersOrgsModel(id=data.get("id")).get_one()
    if not org_obj:
        log.error("can not found org by id [%s]" % data.get("id"))
        raise ParamsException("can not found org by id [%s]" % data.get("id"))
    user = kwargs.get("user")
    token = user["token"]
    filters = {
        "project_id": user["project_id"],
    }
    id_list = delete_orgs(org_obj.id, org_obj.node_id, org_obj.parent_code, token, **filters)

    return {
        "ids": id_list
    }


@users_site.route('/sub_orgs', methods=['GET'])
@restful
def list_sub_org_id(*args, **kwargs):
    """
    API for Java
    /user/sub_org?id=66749960e6fb4585bf8b2dcf705ea199
    :param args:
    :param kwargs:
    :return:

    """
    org_id = request.args.get("id")
    if not org_id:
        raise ParamsException("id maybe missing")
    org_obj = UsersOrgsModel(id=org_id).get_one()
    if not org_obj:
        log.error("can not found org by id [%s]" % org_id)
        raise ParamsException("can not found org by id [%s]" % org_id)
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"],
    }
    sub_orgs_list = UsersOrgsModel.get_sub_orgs(org_obj.node_id, org_obj.parent_code, **filters)
    rst = [org_id]
    for org in sub_orgs_list:
        rst.append(org.id)
    return {
        "sub_ids": rst
    }


@users_site.route('/parent_orgs', methods=['GET'])
@restful
def list_parent_org_id(*args, **kwargs):
    """
    API for Java
    返回的org_id 包含自己，同时从叶子到根节点排序
    /user/parent_orgs?id=66749960e6fb4585bf8b2dcf705ea199
    :param args:  id   # org_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "parent_ids": [
                "c534dbc6d2744420938c8b4e1753716c",
                "164349b76ce449229d52d953282f4f30",
                "571ab95c37174d20a00ff5d2840993b0",
                "16f0d23ba70b47788e43299c0b8cfae4",
                "ec6f498747c04f6c8e0fdbb1ef220595"
            ]
        }
    }
    """
    org_id = request.args.get("id")
    if not org_id:
        raise ParamsException("id maybe missing")
    org_obj = UsersOrgsModel(id=org_id).get_one()
    if not org_obj:
        log.error("can not found org by id [%s]" % org_id)
        raise ParamsException("can not found org by id [%s]" % org_id)
    node_ids = []
    rst = [org_id]
    if org_obj.parent_code:
        node_ids = org_obj.parent_code.split("-")
        user = kwargs.get("user")
        filters = {
            "project_id": user["project_id"],
            "node_ids": node_ids
        }
        sub_orgs_list = UsersOrgsModel.get_org_by_id_fuzzy_name_or_node_ids(**filters)
        for org in sub_orgs_list:
            rst.append(org.id)
    return {
        "parent_ids": rst
    }


@users_site.route('/org_code', methods=['GET'])
@restful
def get_org_code(*args, **kwargs):
    """
    API for Java
    /user/org_code?user_id=87cb4da3919a47688d6a0669ea366fed
    :param args: user_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": "1-5-12"
    }
    """
    user_id = request.args.get("user_id")
    if not user_id:
        raise ParamsException("'user_id' maybe missing")
    rst_obj = UsersModel.get_one_user_join_org(user_id)
    if not rst_obj:
        log.info("can not found org by user_id [%s]" % user_id)
        return ""
    user_obj, org_obj = rst_obj
    if org_obj.parent_code:
        return "%s-%s" % (org_obj.parent_code, org_obj.node_id)
    else:
        return "%s" % org_obj.node_id


@users_site.route('/orgs', methods=['GET'])
@restful
def get_sub_orgs(*args, **kwargs):
    """
    通过组织id 获取下一级组织机构信息   id不传或为空，返回根组织信息
    /user/orgs?id=e2f8cb45dc1b43cfaa7c3234971e3e1a&project_id=0eb082df17d44c8abf46414d8a1397f8
    :param args:id, project_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "orgs": [
                {
                    "id": "72941e4520b54c96938c14781df90ec5",
                    "parent_id": "e2f8cb45dc1b43cfaa7c3234971e3e1a",
                    "org_name": "新加711",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "domain_id": "",
                    "object_uid": "",
                    "dn": "",
                    "mgr_user_id": [],
                    "node_id": 8,
                    "parent_code": "2-5-6"
                }
            ],
            "total": 1
        }
    }
    """
    project_id = request.args.get("project_id")
    if not project_id:
        raise ParamsException("'project_id' maybe missing")
    filters = {
        "project_id": project_id,
        "parent_id": request.args.get("id", "")
    }
    total_count, org_list = UsersOrgsModel.get_list(is_sort=False, **filters)
    rst = []
    for org in org_list:
        rst.append({
            "id": org.id,
            "parent_id": org.parent_id if org.parent_id else "",
            "org_name": org.org_name,
            "project_id": org.project_id,
            "domain_id": org.domain_id if org.domain_id else "",
            "object_uid": org.object_uid if org.object_uid else "",
            "dn": org.dn if org.dn else "",
            "mgr_user_id": json.loads(org.mgr_user_id) if org.mgr_user_id else "",
            "node_id": org.node_id,
            "parent_code": org.parent_code
        })
    return {
        "orgs": rst,
        "total": total_count
    }


@users_site.route('/orgtree', methods=['GET'])
@restful
def get_org_trees(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:

    """
    project_id = kwargs.get("user").get("project_id")
    rst = get_org_tree(project_id)
    return rst


@users_site.route('/org/business', methods=['GET'])
@restful
def org_business_trees(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": [{
            "id": "000000000000CCE7AED4",
            "parent_id": "",
            "org_name": "西部机场集团",
            "sub_orgs": [{
                "id": "wE44RYLfS2uoQNJdwAK7X8znrtQ=",
                "parent_id": "000000000000CCE7AED4",
                "org_name": "控参股公司",
                "sub_orgs": [],
                "business":[]},
            ... ...
                        ],
            "business": [{
                "business_id": "0d7ca344ecfc4763bf3f1d18486db5f4",
                "business_name": "twa"}]
        }]
    }
    """
    project_id = kwargs.get("user").get("project_id")
    rst = get_trees_org_business(project_id)
    return rst


@users_site.route('/orgs/info', methods=['GET'])
@restful
def get_orgs_info(*args, **kwargs):
    """
    API for Go & Java
    :param args: ids list
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "orgs": [
                {
                    "id": "1df47706b7644344bb3b5eb33518a79b",
                    "parent_id": "7a2c3521e9064be0a6b1e4c30b48c3e2",
                    "org_name": "dd",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "domain_id": "default",
                    "object_uid": "",
                    "dn": "",
                    "mgr_user_id": [],
                    "node_id": 2145,
                    "parent_code": "1-2144"
                }
            ],
            "total": 2129
        }
    }
    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"],
        "ids": request.args.get("ids", "")
    }
    total_count, org_list = UsersOrgsModel.get_list(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for org in org_list:
        rst.append({
            "id": org.id,
            "parent_id": org.parent_id if org.parent_id else "",
            "org_name": org.org_name,
            "project_id": org.project_id,
            "domain_id": org.domain_id if org.domain_id else "",
            "object_uid": org.object_uid if org.object_uid else "",
            "dn": org.dn if org.dn else "",
            "mgr_user_id": json.loads(org.mgr_user_id) if org.mgr_user_id else "",
            "node_id": org.node_id,
            "parent_code": org.parent_code
        })
    return {
        "orgs": rst,
        "total": total_count
    }


@users_site.route('/orgname/check', methods=['GET'])
@restful
def get_org_count_by_name(*args, **kwargs):
    """
    通过组织机构名称获取组织机构信息
    "org_name":"新加712",
    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
    "parent_org_id": ""
    :param args:
    :param kwargs:
    :return:
    "code": 1  存在
    "code": 0  不存在
    {
        "rst": "ok",
        "data": { "code": 1}
    }
    """
    org_name = request.args.get("org_name")
    if not org_name:
        raise ParamsException("'org_name' maybe missing")
    project_id = request.args.get("project_id")
    if not project_id:
        raise ParamsException("'project_id' maybe missing")
    filters = {
        "project_id": project_id,
        "org_name": org_name,
        "parent_id": request.args.get("parent_org_id", "")
    }
    cnt = UsersOrgsModel.get_count(**filters)
    if cnt:
        return {"code": 1}
    else:
        return {"code": 0}


@users_site.route('/org/query', methods=['GET'])
@restful
def get_org_by_name_or_id(*args, **kwargs):
    """
    通过组织机构名称模糊查询组织机构信息，返回合并的组织结构树
    :param args: org_name, project_id
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": {
            "org_info": [
                {
                    "id": "ec6f498747c04f6c8e0fdbb1ef220595",
                    "parent_id": "",
                    "org_name": "test1",
                    "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                    "domain_id": "default",
                    "object_uid": "",
                    "dn": "",
                    "mgr_user_id": [],
                    "node_id": 1,
                    "parent_code": "",
                    "sub_orgs": [
                        {
                            "id": "d481bf344fee4142aee933dd7e32b9d5",
                            "parent_id": "ec6f498747c04f6c8e0fdbb1ef220595",
                            "org_name": "test12",
                            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                            "domain_id": "default",
                            "object_uid": "",
                            "dn": "",
                            "mgr_user_id": [],
                            "node_id": 5,
                            "parent_code": "1",
                            "sub_orgs": []
                        }
                    ]
                }
            ]
        }
    }
    """
    org_name = request.args.get("org_name", "")
    org_id = request.args.get("org_id", "")
    if not org_name and not org_id:
        raise ParamsException("'org_name' or 'org_id' maybe missing")
    project_id = request.args.get("project_id")
    if not project_id:
        raise ParamsException("'project_id' maybe missing")
    org_list = get_all_node_org_info(org_name, org_id, project_id)
    return {
        "org_info": org_list
    }


@users_site.route('/roles/listuser', methods=['GET'])
@restful
def get_users_by_roles(*args, **kwargs):
    """

    :param args:   role_id  # 角色id
    :param kwargs:
    :return:
    {
    'rst': 'ok',
    'data': [{
        'id': '1fdb4b36fce247feaccd701b08b401f6',
        'name': 'xiaokai',
        'realname': 'xiaokai123',
        'default_project_id': '0eb082df17d44c8abf46414d8a1397f8',
        'tel': '15691880739',
        'phone': '15691880739',
        'email': '383656225@qq.com',
        'enabled': 1,
        'comments': '',
        'domain_id': 'default',
        'org_id': 'e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a',
        'org_array': [],
        'user_code': '',
        'org_name': 'test2'
        }]
    }
    """

    role_id = request.args.get("role_id", '')
    if not role_id:
        raise ParamsException("role_id is empty")
    users_obj = UserRoleRelationShip.get_users_by_role_id(role_id=role_id)
    users = []
    for rela, user in users_obj:
        user_info = {
            "id": user.user_id,
            "name": user.username,
            "realname": user.realname,
            "default_project_id": user.default_project_id,
            "tel": user.tel,
            "phone": user.phone,
            "email": user.email,
            "enabled": user.enable,
            "comments": user.comments,
            "domain_id": user.domain_id,
            "org_id": user.org_id,
            "org_array": json.loads(user.org_array) if user.org_array else [],
            "user_code": user.user_code,
            "org_name": user.org_name
        }
        users.append(user_info)
    return users
