import json
from sqlalchemy import Column, Integer, String, Text, desc
from sqlalchemy.sql.expression import or_, and_
from guardian.utils.db import provide_session
from guardian.utils.db import UUID_LEN
from guardian.apps import CommonModel, BaseModel, DEL, N_DEL, ON, N_READ, READ, IS_TLS


class EmailConfigModel(BaseModel, CommonModel):
    __tablename__ = "msg_email_config"

    id = Column(String(40), primary_key=True, index=True, nullable=False, doc="id")
    project_id = Column(String(64), unique=True, doc="租户ID")
    server_addr = Column(String(50), nullable=False, doc="服务器地址")
    server_port = Column(Integer, nullable=False, doc="服务器端口")
    is_tls = Column(Integer, default=IS_TLS, doc="是否为TLS")
    user_name = Column(String(50), nullable=False, doc="用户名")
    from_user_addr = Column(String(50), nullable=False, doc="发件人地址")
    user_pass = Column(String(50), nullable=False, doc="密码或授权码")
    test_to_user_addr = Column(String(50), nullable=False, doc="测试收件人")

    def __init__(self, *args, **kwargs):
        super(EmailConfigModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(EmailConfigModel)
        if self.id:
            qry = qry.filter(EmailConfigModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_one_by_project_id(cls, session=None, **kwargs):
        qry = session.query(EmailConfigModel)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        return qry.first()

    @classmethod
    @provide_session
    def add_email(cls, session=None, **kwargs):
        entry = cls()
        entry.id = cls().gen_uuid()
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v != "":
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_email(self, session=None, **kwargs):
        can_edit = ["server_addr", "server_port", "is_tls", "user_name",
                    "user_pass", "from_user_addr", "test_to_user_addr"]
        for k, v in kwargs.items():
            if k in can_edit and v != "":
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def add_email_conf_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "server_addr": data_info.get("server_addr"),
                "server_port": data_info.get("server_port"),
                "is_tls": data_info.get("is_tls"),
                "user_name": data_info.get("user_name"),
                "user_pass": data_info.get("user_pass"),
                "from_user_addr": data_info.get("from_user_addr"),
                "test_to_user_addr": data_info.get("test_to_user_addr"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class MessagesModel(BaseModel, CommonModel):
    __tablename__ = "msg_messages"

    id = Column(String(40), primary_key=True, nullable=False, index=True)
    template_id = Column(String(40), doc="模板ID")
    to_user = Column(Text, doc="收件人")
    from_user = Column(String(50), doc="发件人")
    content = Column(Text, doc="消息内容")
    status = Column(Integer, doc="消息发送状态")
    status_info = Column(Text, doc="消息发送状态信息")
    message_type_id = Column(Integer, doc="信息类型")
    message_type_name = Column(String(50), doc="信息类型名称")
    level = Column(Integer, doc="信息级别")
    project_id = Column(String(64), doc="租户ID")

    def __init__(self, *args, **kwargs):
        super(MessagesModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(MessagesModel)
        if self.id:
            qry = qry.filter(MessagesModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('template_id'):
            qry = qry.filter(cls.template_id == kwargs.get('template_id'))
        if kwargs.get('from_user'):
            qry = qry.filter(cls.from_user == kwargs.get('from_user'))
        if kwargs.get('status'):
            qry = qry.filter(cls.status == kwargs.get('status'))
        if kwargs.get('level'):
            qry = qry.filter(cls.level == kwargs.get('level'))
        res = qry.order_by(desc(MessagesModel.create_at))
        qry = res.limit(limit).offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def add_message(cls, session=None, **kwargs):
        entry = cls()
        entry.id = kwargs.get("id") if kwargs.get("id") else cls().gen_uuid()
        kwargs["to_user"] = json.dumps(kwargs.get("to_user"))
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v != "":
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @classmethod
    @provide_session
    def add_message_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "template_id": data_info.get("template_id"),
                "to_user": json.dumps(data_info.get("to_user")),
                "content": data_info.get("content"),
                "message_type_id": data_info.get("message_type_id"),
                "message_type_name": data_info.get("message_type_name"),
                "level": data_info.get("level"),
                "project_id": data_info.get("project_id"),
                "status": data_info.get("status"),
                "status_info": data_info.get("status_info"),
                "create_at": data_info.get("create_at"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @provide_session
    def update_message(self, session=None, **kwargs):
        can_edit = ["template_id", "to_user", "content", "status", "level",
                    "status_info", "message_type_id", "message_type_name"]
        for k, v in kwargs.items():
            if k in can_edit and v != "":
                setattr(self, k, v)
        session.merge(self)
        session.commit()


class SmsConfigModel(BaseModel, CommonModel):
    __tablename__ = "msg_sms_config"

    id = Column(String(40), index=True, primary_key=True)
    project_id = Column(String(64), nullable=False, unique=True, doc="租户ID")
    account_id = Column(String(100), doc="第三方短信平台账号")  # 参数来源于第三方短信平台
    account_token = Column(String(255), doc="密钥")  # 参数来源于第三方短信平台
    test_phone = Column(String(20), doc="测试手机号码")
    server_addr = Column(String(50), nullable=False, doc="服务器地址")  # 参数来源于第三方短信平台
    server_port = Column(Integer, nullable=False, doc="服务器端口")  # 参数来源于第三方短信平台
    extra_params = Column(Text, doc="额外参数")

    def __init__(self, *args, **kwargs):
        super(SmsConfigModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(SmsConfigModel)
        if self.id:
            qry = qry.filter(SmsConfigModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_one_by_project_id(cls, session=None, **kwargs):
        qry = session.query(SmsConfigModel)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        return qry.first()

    @classmethod
    @provide_session
    def add_sms_conf(cls, session=None, **kwargs):
        entry = SmsConfigModel()
        entry.id = cls().gen_uuid()
        kwargs["extra_params"] = json.dumps(kwargs.get("extra_params"))
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v != "":
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_sms_conf(self, session=None, **kwargs):
        can_edit = ["server_addr", "server_port", "account_id", "account_token",
                    "test_phone", "extra_params"]
        kwargs["extra_params"] = json.dumps(kwargs.get("extra_params"))
        for k, v in kwargs.items():
            if k in can_edit and v != "":
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def add_sms_conf_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "server_addr": data_info.get("server_addr"),
                "server_port": data_info.get("server_port"),
                "test_phone": data_info.get("test_phone"),
                "extra_params": data_info.get("extra_params"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class MsgStrategyModel(BaseModel, CommonModel):
    __tablename__ = "msg_strategy"

    id = Column(String(40), primary_key=True, index=True, nullable=False)
    strategy_app_id = Column(String(40), doc="策略模块ID")  # for Go & Java
    strategy_app_name = Column(String(40), doc="策略模块名称")
    project_id = Column(String(64), doc="租户ID")
    title = Column(String(250), doc="策略标题")
    strategy_period_type = Column(Integer, doc="策略发送周期ID")
    strategy_period_type_name = Column(String(40), doc="策略发送周期名称")
    send_ahead_date = Column(Integer, doc="提前发送时间(天)")
    support_message_types = Column(Text, doc="消息类型列表")
    select_template_ids = Column(Text, doc="已选模板ID列表")
    accept_role_list = Column(Text, doc="接收方角色列表")
    accept_user_list = Column(Text, doc="接收方用户列表")
    select_strategy_app_id = Column(String(64), doc="已选策略模块ID")  # for Web
    is_on = Column(Integer, default=ON, doc="是否已开启")
    is_del = Column(Integer, default=N_DEL, doc="是否已删")

    def __init__(self, *args, **kwargs):
        super(MsgStrategyModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_one(cls, strategy_id, session=None):
        qry = session.query(MsgStrategyModel)
        if cls.id:
            qry = qry.filter(cls.id == strategy_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, include_del=False, session=None, page_idx=1, limit=10000, **kwargs):
        qry = session.query(cls)
        if kwargs.get('id'):
            qry = qry.filter(cls.id == kwargs.get('id'))
        if kwargs.get('strategy_app_id'):
            qry = qry.filter(cls.strategy_app_id == kwargs.get('strategy_app_id'))
        if kwargs.get('strategy_app_name'):
            qry = qry.filter(cls.strategy_app_name == kwargs.get('strategy_app_name'))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('id_list'):
            qry = qry.filter(cls.id.in_(kwargs.get('id_list')))
        if 'is_on' in kwargs:
            qry = qry.filter(cls.is_on == kwargs.get('is_on'))
        if not include_del:
            qry = qry.filter(cls.is_del == N_DEL)
        res = qry.order_by(desc(MsgStrategyModel.create_at))
        return res.count(), res.limit(limit).offset((page_idx - 1) * limit).all()

    @classmethod
    @provide_session
    def add_strategy(cls, msgs_obj, session=None):
        session.add(msgs_obj)
        session.commit()

    @classmethod
    @provide_session
    def add_strategy_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": cls().gen_uuid(),
                "strategy_app_id": data_info.get("strategy_app_id"),
                "strategy_app_name": data_info.get("strategy_app_name"),
                "project_id": data_info.get("project_id"),
                "title": data_info.get("title"),
                "strategy_period_type": data_info.get("strategy_period_type"),
                "strategy_period_type_name": data_info.get("strategy_period_type_name"),
                "send_ahead_date": data_info.get("send_ahead_date", 0),
                "support_message_types": json.dumps(data_info.get("support_message_types", [])),
                "select_template_ids": json.dumps(data_info.get("select_template_ids", [])),
                "accept_role_list": json.dumps(data_info.get("accept_role_list", [])),
                "accept_user_list": json.dumps(data_info.get("accept_user_list", [])),
                "select_strategy_app_id": data_info.get("select_strategy_app_id", [])
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def add_update_strategy_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "strategy_app_id": data_info.get("strategy_app_id"),
                "strategy_app_name": data_info.get("strategy_app_name"),
                "project_id": data_info.get("project_id"),
                "title": data_info.get("title"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
                "strategy_period_type": data_info.get("strategy_period_type"),
                "strategy_period_type_name": data_info.get("strategy_period_type_name"),
                "send_ahead_date": data_info.get("send_ahead_date", 0),
                "support_message_types": data_info.get("support_message_types", []),
                "select_template_ids": data_info.get("select_template_ids", []),
                "accept_role_list": data_info.get("accept_role_list", []),
                "accept_user_list": data_info.get("accept_user_list", []),
                "select_strategy_app_id": data_info.get("select_strategy_app_id", [])
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @provide_session
    def update_strategy(self, session=None, **kwargs):
        can_edit = ["strategy_app_id", "strategy_app_name", "title", "strategy_period_type", "select_strategy_app_id",
                    "strategy_period_type_name", "send_ahead_date", "support_message_types",
                    "select_template_ids", "accept_role_list", "accept_user_list", "is_on", "is_del"]
        kwargs["support_message_types"] = json.dumps(kwargs.get("support_message_types", []))
        kwargs["select_template_ids"] = json.dumps(kwargs.get("select_template_ids", []))
        kwargs["accept_role_list"] = json.dumps(kwargs.get("accept_role_list", []))
        kwargs["accept_user_list"] = json.dumps(kwargs.get("accept_user_list", []))
        for k, v in kwargs.items():
            if k in can_edit and v is not None:
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def update_strategy_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_list.append({
                "id": data_info.get("id"),
                "strategy_app_id": data_info.get("strategy_app_id"),
                "strategy_app_name": data_info.get("strategy_app_name"),
                "title": data_info.get("title"),
                "strategy_period_type": data_info.get("strategy_period_type"),
                "strategy_period_type_name": data_info.get("strategy_period_type_name"),
                "send_ahead_date": data_info.get("send_ahead_date", 0),
                "support_message_types": json.dumps(data_info.get("support_message_types", [])),
                "select_template_ids": json.dumps(data_info.get("select_template_ids", [])),
                "accept_role_list": json.dumps(data_info.get("accept_role_list", [])),
                "accept_user_list": json.dumps(data_info.get("accept_user_list", [])),
                "select_strategy_app_id": data_info.get("select_strategy_app_id", []),
                "is_on": data_info.get("is_on", ON),
                "is_del": data_info.get("is_del", N_DEL)
            })
        session.bulk_update_mappings(cls, data_list)

    @provide_session
    def enable_disable_strategy(self, is_on=ON, session=None):
        self.is_on = is_on
        session.merge(self)
        session.commit()

    @provide_session
    def del_strategy(self, session=None):
        self.is_del = DEL
        session.merge(self)
        session.commit()


class MsgTemplateModel(BaseModel, CommonModel):
    __tablename__ = "msg_template"

    id = Column(String(40), primary_key=True, nullable=False, index=True)
    strategy_app_id = Column(String(40), doc="策略模块ID")
    strategy_app_name = Column(String(40), doc="策略模块名称")
    project_id = Column(String(64), doc="租户ID")
    title = Column(String(250), doc="模板标题")
    content = Column(Text, doc="模板内容")
    type_id = Column(Integer, doc="模板类型")
    type_name = Column(String(40), doc="模板类型名称")
    variable = Column(String(250), doc="模板参数集合")

    def __init__(self, *args, **kwargs):
        super(MsgTemplateModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('template_ids'):
            qry = qry.filter(cls.id.in_(kwargs.get('template_ids')))
        res = qry.order_by(desc(cls.create_at))
        qry = res.limit(limit).offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def update_template_batch(cls, data, session=None):
        data_list = []
        can_edit = ["title", "content"]
        for data_info in data:
            msg_template_dict = dict()
            msg_template_dict["id"] = data_info.get("id")
            for k, v in data_info.items():
                if k in can_edit and v is not None:
                    msg_template_dict[k] = v
            data_list.append(msg_template_dict)
        session.bulk_update_mappings(cls, data_list)

    @classmethod
    @provide_session
    def add_template_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "strategy_app_id": data_info.get("strategy_app_id"),
                "title": data_info.get("title"),
                "content": data_info.get("content"),
                "update_at": data_info.get("update_at"),
                "type_id": data_info.get("type_id"),
                "variable": data_info.get("variable"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class InnerNoticeModel(BaseModel, CommonModel):
    __tablename__ = "msg_inner_notice"

    id = Column(String(40), primary_key=True, nullable=False, index=True)
    user_id = Column(String(UUID_LEN), doc="用户ID")
    project_id = Column(String(64), nullable=False, doc="租户ID")
    title = Column(String(100), nullable=False, doc="通知标题")
    content = Column(String(500), doc="通知内容")
    notice_type = Column(Integer, nullable=False, doc="通知类型")
    notice_type_name = Column(String(20), nullable=False, doc="通知类型名称")
    level = Column(Integer, doc="信息级别")

    def __init__(self, *args, **kwargs):
        super(InnerNoticeModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(InnerNoticeModel)
        if self.id:
            qry = qry.filter(InnerNoticeModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=100, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('title'):
            qry = qry.filter(cls.title == kwargs.get('title'))
        if kwargs.get('notice_type'):
            qry = qry.filter(cls.notice_type == kwargs.get('notice_type'))
        res = qry.order_by(desc(InnerNoticeModel.create_at))
        qry = res.offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def add_notice(cls, session=None, **kwargs):
        entry = InnerNoticeModel()
        entry.id = cls().gen_uuid()
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v is not None:
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @classmethod
    @provide_session
    def add_notice_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": cls().gen_uuid(),
                "user_id": data_info.get("user_id"),
                "project_id": data_info.get("project_id"),
                "title": data_info.get("title"),
                "content": data_info.get("content"),
                "notice_type": data_info.get("notice_type"),
                "notice_type_name": data_info.get("notice_type_name"),
                "level": data_info.get("level")
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def add_update_notice_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "user_id": data_info.get("user_id"),
                "project_id": data_info.get("project_id"),
                "title": data_info.get("title"),
                "content": data_info.get("content"),
                "notice_type": data_info.get("notice_type"),
                "notice_type_name": data_info.get("notice_type_name"),
                "level": data_info.get("level", 1),
                "create_at": data_info.get("create_at")
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def query_notice(cls, page_idx=1, limit=10000, include_del=False, session=None, **kwargs):
        """
        query_notice_left_join_status
        :return: return all notices for login user
        """
        qry = session.query(cls, InnerNoticeStatusModel) \
            .join(InnerNoticeStatusModel, and_(cls.id == InnerNoticeStatusModel.notice_id,
                                               kwargs.get('project_id') == InnerNoticeStatusModel.user_id),
                  isouter=True)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('user_id'):
            qry = qry.filter(
                or_(cls.user_id == kwargs.get('user_id'), cls.user_id.is_(None)))
        if kwargs.get('notice_type'):
            qry = qry.filter(cls.notice_type == kwargs.get('notice_type'))
        if not include_del:
            qry = qry.filter(
                or_(InnerNoticeStatusModel.is_del == N_DEL, InnerNoticeStatusModel.is_del.is_(None)))
        return qry.count(), qry.order_by(desc(cls.create_at)) \
            .limit(limit).offset((page_idx - 1) * limit).all()

    @classmethod
    @provide_session
    def query_notice_not_read(cls, page_idx=1, limit=10000, include_del=False, session=None, **kwargs):
        """
        query_notice_left_join_status_null
        :return: return notice already read
        """
        qry = session.query(cls, InnerNoticeStatusModel) \
            .join(InnerNoticeStatusModel, cls.id == InnerNoticeStatusModel.notice_id, isouter=True)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('user_id'):
            qry = qry.filter(InnerNoticeStatusModel.user_id.is_(None))
        if kwargs.get('notice_type'):
            qry = qry.filter(cls.notice_type == kwargs.get('notice_type'))
        if not include_del:
            qry = qry.filter(and_(cls.user_id == kwargs.get('user_id'), InnerNoticeStatusModel.is_del.is_(None)))
        return qry.count(), qry.order_by(desc(cls.create_at)) \
            .limit(limit).offset((page_idx - 1) * limit).all()


class InnerNoticeStatusModel(BaseModel, CommonModel):
    __tablename__ = "msg_inner_notice_status"

    id = Column(String(40), primary_key=True, nullable=False, index=True)
    notice_id = Column(String(40), nullable=False, doc="通知ID")
    user_id = Column(String(64), nullable=False, doc="用户ID")
    is_read = Column(Integer, default=N_READ, doc="是否已读")
    is_del = Column(Integer, default=N_DEL, doc="是否已删")

    def __init__(self, *args, **kwargs):
        super(InnerNoticeStatusModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_notice_id_by_status_info(cls, session=None, **kwargs):
        qry = session.query(cls.notice_id).join(InnerNoticeModel, cls.notice_id == InnerNoticeModel.id)
        if kwargs.get('project_id'):
            qry = qry.filter(InnerNoticeModel.project_id == kwargs.get('project_id'))
        if kwargs.get('user_id'):
            qry = qry.filter(cls.user_id == kwargs.get('user_id'))
        if kwargs.get('notice_ids'):
            qry = qry.filter(cls.notice_id.in_(kwargs.get('notice_ids')))
        return qry.order_by(desc(cls.create_at)).all()

    @classmethod
    @provide_session
    def get_list_by_status_info(cls, session=None, **kwargs):
        qry = session.query(cls.id, cls.notice_id).join(InnerNoticeModel, cls.notice_id == InnerNoticeModel.id)
        if kwargs.get('project_id'):
            qry = qry.filter(InnerNoticeModel.project_id == kwargs.get('project_id'))
        if kwargs.get('user_id'):
            qry = qry.filter(cls.user_id == kwargs.get('user_id'))
        if kwargs.get('notice_ids'):
            qry = qry.filter(cls.notice_id.in_(kwargs.get('notice_ids')))
        return qry.order_by(desc(cls.create_at)).all()

    @classmethod
    @provide_session
    def add_notice_status_batch(cls, user_id, notice_id_list, session=None):
        data_list = []
        for notice_id in notice_id_list:
            data_item = {
                "id": cls().gen_uuid(),
                "notice_id": notice_id,
                "user_id": user_id,
                "is_read": READ,
                "is_del": N_DEL
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def add_update_notice_status_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": cls().gen_uuid(),
                "notice_id": data_info.get("notice_id"),
                "user_id": data_info.get("user_id"),
                "is_read": data_info.get("is_read"),
                "is_del": data_info.get("is_del"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def del_notice_status_batch(cls, user_id, notice_id_list, session=None):
        """add notice to msg_inner_notice_status and mark is_del = DEL"""
        data_list = []
        for notice_id in notice_id_list:
            data_item = {
                "id": cls().gen_uuid(),
                "notice_id": notice_id,
                "user_id": user_id,
                "is_del": DEL
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def del_notice_info_batch(cls, id_list, session=None):
        """mark notice status  is_del = DEL"""
        data_list = []
        for status_id in id_list:
            notice_info_dict = dict()
            notice_info_dict["id"] = status_id
            notice_info_dict["is_del"] = DEL
            data_list.append(notice_info_dict)
        session.bulk_update_mappings(cls, data_list)
