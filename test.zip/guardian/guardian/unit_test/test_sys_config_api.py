import unittest
import requests
from datetime import datetime
from time import time
from io import StringIO


class UsersTestCase(unittest.TestCase):
    def setUp(self):
        self.base_url = "http://127.0.0.1:7000/gd/v2"
        self.start_time = datetime.now()
        self.token = 'gAAAAABcncG9uLZm-AIQxC7mCHDJRfEnfiWEmkwb2jC3M3RXWpRByQm1LYO4sWTZHWA6dGibDGtEvJSNqNdAwmoF1zKjtieiOoQ5WlBbjlP6pgdqhxQh8JJOW_ANb1xXl6T7decTi52Dso2uGevWHCVnbsKJWg-cxGebjSkrTlhPuI4qksGoiYI'
        self.headers = {'X-Subject-Token': self.token}
        print("start unittest -----{0}".format(datetime.now()))

    def _test_upload_logo(self):
        api_start_time = time()
        url = self.base_url + "/sys/file"
        print("url is %s" % url)
        temp = StringIO()
        # temp.write('Hello Temp!')
        temp.write('iVBORw0KGgoAAAANSUhEUgAAAEYAAAA8CAYAAADbl8wjAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTM4IDc5LjE1OTgyNCwgMjAxNi8wOS8xNC0wMTowOTowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkUxQUQzOUEyNDc2NjExRTdCOEEyRTg0N0FFODUwQTlEIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkUxQUQzOUEzNDc2NjExRTdCOEEyRTg0N0FFODUwQTlEIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RTFBRDM5QTA0NzY2MTFFN0I4QTJFODQ3QUU4NTBBOUQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RTFBRDM5QTE0NzY2MTFFN0I4QTJFODQ3QUU4NTBBOUQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7CLGRtAAAGnklEQVR42tycf0xWZRTHX14NlNxk+AslKMnUbFkMUkMNS52KOmZzq+wXi7K1ci3MsjJzlSudbi3GHH+oUTqx9ROnWzpRzF9JEJKCoaSCSEmh5JoY6u37jPNudzfe957z3PveFzrb54987/Och+/9dZ5zzi3KMAyfxzYaTAH3gSRwOxhEv10CZ0AjOA52gh99EbAoD4XJITKF4+rA52A9ifa/EeZ5sBjc4XAetdB14CNwsicLkwg2a1whHIFeBvk9UZiHwFegfxjXvhU8RkL1CGHmkShe2FEwAbR3d2HGgR88foGUk99uK0w8OAf6CsedBb+CPmAUzSO1L8F8d59kEMYlSg2+lYEcMNwyRyy4GywGhw2ZPeni3+KaMLnMxdeB2YJ5pwkFT+xOwvQF1xmL/g7cpOljGVOYTd1JmLcZC/7GBT8LmOIkdwdhBjEWetrFe38pw1+BG76cvpVUzLIEHAAVoAG0geugNxgAakCLi++LSpAa4vfLYLDT2MapMOqPv+Zx3JJK4thF3nuc/mFOLCBKEnErGA6iwVVwmmKUOkopuGE/USoiPcQxYyIljJ8CqmyQQYJE2VzeKkItBl+Aiw7WPBKctzlmPCjwMsCLpQfgWUPfLoI1YCSIZvqdB9aDU0wfV0A+yPTirfQKOG+4axNC+BsIVoN6hz4qwIvhECaegjO37Y0QV8wS0Oayvxowxy1h0kBTGER5Log/dXvtN8Jr6hbzOxFmRpgWNj+IvynMrYUbVgvu0hFmfJgWlBXEX5bhvd0AGZLIV0WNTS7EOGa7AaaCvV38toByw5GyGVSmsY18VQB1r3ByFcSVUqzSQOF4LCXEVcD3Nf1mtWeoLBJpS6ZaVtAA702hKNtAEWXQpJYH1mruldSVdwo0g7/BzSABjKCA837hnGWUPezoKsDrJ7g//wKPOti9vqXxTNgGUpnzT6bjJbYh2MO3kDnBSZBiGucXivKucMEXHJyEHGE8NNoqTAJzYANtCwLj1DOql2ChBUJRqsEA0/hq65lloBJXjUx/h63CvMYceKeD22edUJQ9psh4CIkSsEUaCbUWpt9xZmGOMAYsdSDKt0JRNprGpgb5o14VrmEM03dhQJihzPtcV5QSoShrTGMzbY59VriWdxj+1UnwBx5QdvaBpihlQlEWmsY+rTGGQytjzgzu22iU0HkMKBeK8rBp/BPCsZK3FqeqsUJl4obZBD/14BdBsDSEotx05vGtVJg3NwJUCGvgWygxz7EiVtcX1PnZRr0iwdlIECaz6myqh4eEV85c5jqP2czzPeeK4eZnUyhJPZR5/F7K+DeFOGYyKBFcOSXUwcXpkAhlSX5Gd0IHw1EW9aokMjuiVoEHaZ9jV4VYpdG05HN4suP9jMIUp63jBdBPsPjdzOPmgl2CeVVl4BHmybEtg9iVIpIZjlQpZTu3yEf5j8dtjltEt0Ysc97l4CXmsXZztqoH0Q6bB1GbYKMozdcGS3O+J5xnuTCc2Gkz3z4f1WvsbBrTYS8qV0jMmrnPF46XblX6gHabOYv9VJD3MS5rjqlifhplATl23JI52y24HZQtBB8KH87qRRFjc8wJpeAtzMTxMGHFssZmzu2UtggU16SRcq7mNuUAY+6JgYMPMg4u19gW1DJ6WFRyqFkoymxNUdIYc/8BegcG5IXpIRdPjUNmW2lJQV71SBRFJWP+T8z5mDhwjbmwPOFi4ihHbK1A5goFUbfzJAeirGb6mW7N+a4ULHKFcFFjQbbpv18XitJOt4GuKNw7or6rZLiKVS4JFqtigXThAtM1Ele/G529v7qirBX4mhmsRJutUdbYAmapB1aIuEH1t2zVmLuZMow6gkxnZA6s7SIhS7QfC+IWs6ni1xmqSrZQqTeFGKwxn2pTe4Da8P+bL+nME5k3uDH07yqOeson/xxItafV2jUnltLuN1JWQxXFti5a4/ZTK9lv4Bi4Qt8h3KN5AgKl4o3cVrN9RmSskm4/63qiDPn3BRwr0mkcKvZYlF1BNqyqfHw0DP42Gw5azZZ5JEqJEfxbheow+PvUcKE5UUWoVWES5HKIEshAqpW7bbbFOp1e/j9dXGAhJdC78jWJol03rYobe+nEB/1Jcd0mQrXrfp9Rq1K1onMuCXLC6GzH9ewjC/WKnEU1pLHUIR5t+v0fikOq6NWq0p9HhD6mUjvaHI3X8Q7qRv8skt9EBvr34iiXbFA2/oJLc6uk/EQw09f5vz1QJ+E2im06qMWtkb6xPAgO+Rx82f+vAAMAlSuIFm2Q7mcAAAAASUVORK5CYII=')
        temp.seek(0)
        temp.name = "hello-temp.png"
        file = {'file': temp}
        self.data = requests.post(url, files=file)
        print(self.data.status_code)
        print(self.data.json())
        print("test_upload_logo cost time: {0}".format(time() - api_start_time))

    def test_get_logo(self):
        api_start_time = time()
        url = self.base_url + "/sys/logo/3e2ad26e80034770b965289e8ebd2c3d.png"

        print("url is %s" % url)
        self.data = requests.get(url)
        print(self.data.status_code)
        print(self.data)
        print("test_get_logo cost time: {0}".format(time() - api_start_time))

    def _test_conf_save(self):
        api_start_time = time()
        url = self.base_url + "/sys/conf/save"
        print("url is %s" % url)
        r_data = {
            'id': 'dbdf7fbd-att1-4d34-9ba5-2d3779c11b21',
            'sys_logo': '/gd_static/49a74bb173e64f97a0860c35d4c2caa2.png',
            'sys_name': 'IT运营管理中枢',
            'version': 'V3.0',
            'copyright': 'Copyright © 2018',
            'surport_mail': 'support@domain.com',
            'surport_tel': '400-000-0000',
            'log_delete_time': '7',
            'session_expire': 3600,
            'case_sensitive': 1,
            'license_expire': 8,
            'project_id': '0eb082df17d44c8abf46414d8a1397f8'
        }
        data = requests.post(url, json=r_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_conf_save cost time: {0}".format(time() - api_start_time))

    def _test_list_sys_conf(self):
        api_start_time = time()
        url = self.base_url + "/sys/conf"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_sys_conf cost time: {0}".format(time() - api_start_time))

    def _test_get_license(self):
        api_start_time = time()
        url = self.base_url + '/sys/license'
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers, params={'module_id': '3f6943f6-60a1-4b66-be9e-7deef375bbeb'})
        print(data.status_code)
        print(data.json())
        print("test_list_sys_conf cost time: {0}".format(time() - api_start_time))

    def _test_upload_license(self):
        api_start_time = time()
        url = self.base_url + '/sys/license'
        print("url is %s" % url)
        files = {
            'file': ('1550565606.lic',
                     open('/home/zxp/leaptocloud.com/src/leaptocloud.com/tools/license/1550565606.lic', 'rb'))
        }
        data = {'module_id': '3f6943f6-60a1-4b66-be9e-7deef375bbeb'}
        data = requests.post(url, headers=self.headers, files=files, data=data)
        print(data.status_code)
        print(data.json())
        print("test_list_sys_conf cost time: {0}".format(time() - api_start_time))

    def _test_get_modules(self):
        api_start_time = time()
        url = self.base_url + "/sys/modules"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_modules cost time: {0}".format(time() - api_start_time))

    def _test_get_menus(self):
        api_start_time = time()
        url = self.base_url + "/sys/menus"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_modules cost time: {0}".format(time() - api_start_time))

    def _test_get_role_asigned_menus(self):
        api_start_time = time()
        url = self.base_url + "/sys/role/menus"
        print("url is %s" % url)
        params = {
            "role_id": "1278945210e1458290cdde9417e0d7d1"
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_get_role_asigned_menus cost time: {0}".format(time() - api_start_time))

    def _test_get_user_menus(self):
        api_start_time = time()
        url = self.base_url + "/sys/user/menus"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_user_menus cost time: {0}".format(time() - api_start_time))

    def _test_create_update_ldap_conf(self):
        api_start_time = time()
        url = self.base_url + "/sys/ldap"
        print("url is %s" % url)
        request_data = {
            "id": "",
            "project_id": "7fca4022faba4ba69d8cd42de409dab2",
            "server_addr": "192.168.3.116",
            "server_port": 389,
            "is_ssl": 0,
            "user_name": "Administrator@leaptocloud.com",
            "user_pass": "1qaz@WSX",
            "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com",
            "is_update": 1
        }
        data = requests.post(url, headers=self.headers, json=request_data)
        print(data.status_code)
        print(data.json())
        print("test_create_update_ldap_conf cost time: {0}".format(time() - api_start_time))

    def _test_get_ldap_conf(self):
        api_start_time = time()
        url = self.base_url + "/sys/ldap"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, headers=self.headers, json=request_data)
        print(data.status_code)
        print(data.json())
        print("test_get_ldap_conf cost time: {0}".format(time() - api_start_time))

    def _test_test_ldap_conf(self):
        api_start_time = time()
        url = self.base_url + "/sys/ldap/test"
        print("url is %s" % url)
        request_data = {
            "id": "",
            "project_id": "b91ff5afc1044e4c80bf9e68532a71fb",
            "server_addr": "192.168.3.116",
            "server_port": 389,
            "is_ssl": 0,
            "user_name": "Administrator@leaptocloud.com",
            "user_pass": "1qaz@WSX",
            "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
        }
        data = requests.post(url, headers=self.headers, json=request_data)
        print(data.status_code)
        print(data.text)
        print("test_test_ldap_conf cost time: {0}".format(time() - api_start_time))


def tearDown(self):
    print("end unittest -----{0}".format(datetime.now()))
