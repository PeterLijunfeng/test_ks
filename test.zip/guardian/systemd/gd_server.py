#!/usr/bin/python

import os
import platform

py_version = platform.python_version()[0:1]
activate_this = '/opt/leaptocloud/cloudenv/bin/activate_this.py'

if py_version == "3":
    exec(open(activate_this).read(), dict(__file__=activate_this))
else:
    execfile(activate_this, dict(__file__=activate_this))

os.system("rm -f /opt/leaptocloud/gd_work/log/webserver-guardian-monitor.pid")
os.system("rm -f /opt/leaptocloud/gd_work/log/workers-guardian-workers.pid")
os.system("rm -f /opt/leaptocloud/gd_work/log/webserver-guardian.pid")
os.system("rm -f /opt/leaptocloud/gd_work/log/workers-guardian.pid")
os.system("rm -f /opt/leaptocloud/gd_work/log/scheduler-guardian.pid")
os.system("guardian webserver -D")
os.system("guardian scheduler")
os.system("guardian workers")

