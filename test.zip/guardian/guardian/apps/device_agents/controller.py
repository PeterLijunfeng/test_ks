import math
import threading
import uuid
from flask import request
from guardian.settings import APIBASEURL
from flask import Blueprint
from guardian.common.rest import restful
from guardian.apps.device_agents.models import DeviceAgentModel
from guardian.apps.device_agents.services import connect
from guardian.apps.device_agents.services import exec_commands, execute_script_by_agents
from guardian.log4 import app_logger as log
from guardian.settings import ANSIBLE_HOST_IP
from guardian.settings import ANSIBLE_ROOT_USER
from guardian.settings import ANSIBLE_ROOT_PASS

device_site = Blueprint('device', __name__, url_prefix="%s/device" % APIBASEURL)
agent_site = Blueprint('agent', __name__, url_prefix="%s/agent" % APIBASEURL)


@device_site.route('/agent/list', methods=['GET'])
@restful
def get_agent_list(*args, **kwargs):
    """
    :param args: limit, page_idx
    :param kwargs:
    :return:
    {
    'rst': 'ok',
    'data': {
            'agents': [{
                'id': '46e4049b-fe16-4e8b-98d2-9c5e80a1d916',
                'host_ip': '192.168.3.141',
                'host_name': '192.168.3.141',
                'ansible_conn_status': False,
                'agent_name': None,
                'agent_version': None,
                'agent_url': None,
                agent_status': None
            }],
        'page': 1,
        'page_count': 1,
        'total': 1
        }
    }
    """
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page_idx', default=1, type=int)
    filters = {
        "host_ip": request.args.get('host_ip', ''),
        "host_name": request.args.get('host_name', ''),
        "agent_name": request.args.get('agent_name', ''),
        "agent_status": request.args.get('agent_status', ''),

    }
    count, agent_list = DeviceAgentModel.get_list(page_idx=page_idx, limit=limit, **filters)
    res = []
    for agent in agent_list:
        res.append({
            'id': agent.id,
            'host_ip': agent.host_ip,
            'host_name': agent.host_name,
            'ansible_conn_status': agent.ansible_conn_status,
            'agent_name': agent.agent_name,
            'agent_version': agent.agent_version,
            'agent_url': agent.agent_url,
            'agent_status': agent.agent_status
        })
    return {
        "agents": res,
        "page": page_idx,
        "page_count": math.ceil(count / limit),
        "total": count
    }


@device_site.route('/agent/sync', methods=['GET'])
@restful
def sync_device_agent(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {'rst': 'ok', 'data': {}}
    """
    conn = connect(host=ANSIBLE_HOST_IP, username=ANSIBLE_ROOT_USER, password=ANSIBLE_ROOT_PASS)
    command = "ansible all -m shell -a 'hostname'"
    res = exec_commands(conn=conn, cmd=command)
    res = str(res, encoding="utf-8")
    host_list = []
    for host in res.split("}\n"):
        if not host:
            continue
        log.info('host is %s', host)
        host_status = (host.split('|')[1]).split('=>')[0]
        host_list.append({'id': str(uuid.uuid4()),
                          'host_ip': host.split('|')[0],
                          'host_name': host.split('|')[0],
                          'ansible_conn_status': True if host_status == 'SUCCESS' else False,
                          'agent_name': None,
                          'agent_version': None,
                          'agent_url': None,
                          'agent_status': None
                          })
    log.info('host_list is %s', host_list)
    host_update_list = []
    host_add_list = []
    for host in host_list:
        agent_obj = DeviceAgentModel(id=host.get('host_ip')).get_one()
        if agent_obj:
            host_update_list.append(host)
        else:
            host_add_list.append(host)
    if host_update_list:
        DeviceAgentModel.update_agent_list(datas=host_update_list)
    if host_add_list:
        DeviceAgentModel.add_agent_list(datas=host_add_list)
    return {}


@agent_site.route('/script/exec', methods=['POST'])
@restful
def agent_script_exec(*args, **kwargs):
    """
    request body
    [
            {
                "host_ip": "127.0.0.1",
                "host_name": "host126",
                "agent_version": "1.0",
                "agent_url": "127.0.0.1"
            }
        ]
    :param args:
    :param kwargs:
    :return:
    {'rst': 'ok', 'data': {}}
    """
    agents = request.get_json()

    status = threading.Thread(target=execute_script_by_agents, args=(agents,))
    status.start()

    return {}
