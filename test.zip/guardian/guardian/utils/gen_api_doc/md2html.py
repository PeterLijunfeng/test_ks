import os
from time import strftime

import yaml
from jinja2 import Template
from markdown2 import markdown

SIGNATURE = strftime("""
---
Generate API DOC on %Y.%m.%d %H:%M:%S %z""")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def prasemd2html(input_file, output_file, flavour="skeleton", title="API DOC", signature=False, allow_html=True):
    # Load flavours
    with open(SCRIPT_DIR + "/flavours.yaml", "r") as f:
        FLAVOURS = yaml.load(f)

    with open(input_file, "r") as f:
        markdown_source = f.read()
    if signature:
        markdown_source = markdown_source.join(("\n", SIGNATURE))

    extras = [
        "metadata",
        "fenced-code-blocks",
        "header-ids",
        "footnotes",
        "tables",
    ]

    if allow_html:
        extras.append("markdown-in-html")

    converted_markdown = markdown(markdown_source, extras=extras)

    with open(SCRIPT_DIR + "/template.html", "r") as f:
        HTML_PAGE_TEMPLATE = Template(f.read())
    SELECTED_FLAVOUR = FLAVOURS.get(flavour, None)

    # If container template doesn't exist for current
    # flavour, simply replace it with placeholder
    main_container_template = SELECTED_FLAVOUR.get("container", "{{ content }}")
    MAIN_CONTAINER = Template(main_container_template)

    # Generate a list of CSS stylesheet URLs for jinja2 template
    u = SELECTED_FLAVOUR.get("url", None)
    if isinstance(u, str):
        stylesheet_urls = [u]
    else:
        stylesheet_urls = u

    if title:
        title = title
    elif converted_markdown.metadata:
        title = converted_markdown.metadata.get("title", None)
    else:
        title = None

    final_html_output = HTML_PAGE_TEMPLATE.render(
        body=MAIN_CONTAINER.render(
            content=converted_markdown
        ),
        embedded_stylesheets=[],
        stylesheet_urls=stylesheet_urls,
        custom_css=SELECTED_FLAVOUR.get("css-hack", None),
        title=title
    )

    with open(output_file, "w") as f:
        f.write(final_html_output)

