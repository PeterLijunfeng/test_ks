import psycopg2
import pymysql

from guardian.apps.sys_config.models import SysMenuModel
from guardian.apps.users.models import UserRolePermissionModel
from guardian.common.update import PROJECT_ID
from guardian.settings import ROOT_ADMIN, PROJECT_ADMIN, DEPT_ADMIN, USER
from guardian.settings import INIT_ROLE_ID, PLATFORM_UCMP


# 旧版本中默认初始化的角色
UCMP_ROOT = "ucmp_root"
UCMP_ADMIN = "ucmp_admin"
UCMP_DEPT = "ucmp_dept"
UCMP_USER = "ucmp_user"
ROLE_TYPE_DICT = {
    UCMP_ROOT: ROOT_ADMIN,
    UCMP_ADMIN: PROJECT_ADMIN,
    UCMP_DEPT: DEPT_ADMIN,
    UCMP_USER: USER
}
OLD_ROLE_TYPE_LIST = [k for k in ROLE_TYPE_DICT.keys()]


CONNECT_CONFIG = {
    "database": "guardian",
    "user": "guardian",
    "password": "123456",
    "host": "192.168.3.126",
    "port": "5432",
}

CONNECT_CONFIG_TO_MENU = {
    "database": "guardian_new",
    "user": "guardian",
    "password": "123456",
    "host": "192.168.3.143",
    "port": "5432",
}

CONNECT_CONFIG_UPDATE = {
    "database": "guardian_new",
    "user": "guardian",
    "password": "123456",
    "host": "127.0.0.1",
    "port": "5432",
}

KEY_STONE_DB = {
    'host': '192.168.3.126',
    'user': 'root',
    'password': 'Sa_1234567',
    'db': 'keystone',
    'charset': 'utf8',
    'port': 3306,
}


def new_add_menu_init():

    pass


def assign_new_menu_to_all_role():
    pass


def get_role_id_list():
    # 查询新老 role_id 对应关系
    # 获取初始化角色的id list
    conn = psycopg2.connect(**CONNECT_CONFIG)
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name in (%s)" % ','.join(['%s'] * len(OLD_ROLE_TYPE_LIST))
    cursor.execute(sql, OLD_ROLE_TYPE_LIST)
    res_dept = cursor.fetchall()
    # print(res_dept)

    old_role_id_list = [dept_id for dept_id, role_name in res_dept]
    sql = 'select role_id, role.name from assignment left join role on assignment.role_id = role.id ' \
          'where role_id in (%s)' % ','.join(['%s'] * len(old_role_id_list))
    cursor.execute(sql, old_role_id_list)
    new_old_role_dict = {}
    ole_new_role_id_list = []
    for role_id, role_name in cursor.fetchall():
        new_old_role_dict[role_id] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(ROLE_TYPE_DICT.get(role_name))
        ole_new_role_id_list.append(role_id)

    # 获取自定义角色的id list
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql2 = "select id from role where name not in (%s)" % ','.join(['%s'] * len(OLD_ROLE_TYPE_LIST))
    cursor.execute(sql2, OLD_ROLE_TYPE_LIST)
    res_dept = cursor.fetchall()
    # print(res_dept)

    old_role_id_list = [dept_id for dept_id, in res_dept]
    sql = 'select role_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(old_role_id_list))
    cursor.execute(sql, old_role_id_list)
    cus_role_id_list = []
    for role_id, in cursor.fetchall():
        cus_role_id_list.append(role_id)

    cursor.close()
    link.close()
    conn.close()

    return new_old_role_dict, ole_new_role_id_list, cus_role_id_list


def init_role_permission():
    new_old_role_dict, ole_new_role_id_list, cus_role_id_list = get_role_id_list()

    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql = "select role.role_id, role.menu_id, menu.app_id from rolepermission as role " \
          "left join menu on role.menu_id = menu.id " \
          "where role.role_id != 'None'"
    cur.execute(sql)
    rows = cur.fetchall()

    old_role_menu_app_list = []
    for old_role_id, menu_id, app_id in rows:
        old_role_menu_app_dict = {}
        old_role_menu_app_dict['old_role_id'] = old_role_id
        old_role_menu_app_dict['menu_id'] = menu_id
        old_role_menu_app_dict['module_id'] = app_id
        old_role_menu_app_list.append(old_role_menu_app_dict)

    for old_role_info_dict in old_role_menu_app_list:
        old_id = old_role_info_dict['old_role_id']
        old_role_info_dict['role_id'] = new_old_role_dict.get(old_id, old_role_info_dict['old_role_id'])

    for old_role_info_dict in old_role_menu_app_list:

        if old_role_info_dict['role_id'] == INIT_ROLE_ID.get(PLATFORM_UCMP).get(USER):
            new_role_info = {}
            new_role_info['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(DEPT_ADMIN)
            new_role_info['menu_id'] = old_role_info_dict['menu_id']
            new_role_info['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info)
            new_role_info1 = {}
            new_role_info1['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(PROJECT_ADMIN)
            new_role_info1['menu_id'] = old_role_info_dict['menu_id']
            new_role_info1['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info1)
            new_role_info2 = {}
            new_role_info2['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(ROOT_ADMIN)
            new_role_info2['menu_id'] = old_role_info_dict['menu_id']
            new_role_info2['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info2)
        if old_role_info_dict['role_id'] == INIT_ROLE_ID.get(PLATFORM_UCMP).get(DEPT_ADMIN):
            new_role_info1 = {}
            new_role_info1['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(PROJECT_ADMIN)
            new_role_info1['menu_id'] = old_role_info_dict['menu_id']
            new_role_info1['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info1)
            new_role_info2 = {}
            new_role_info2['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(ROOT_ADMIN)
            new_role_info2['menu_id'] = old_role_info_dict['menu_id']
            new_role_info2['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info2)
        if old_role_info_dict['role_id'] == INIT_ROLE_ID.get(PLATFORM_UCMP).get(PROJECT_ADMIN):
            new_role_info2 = {}
            new_role_info2['role_id'] = INIT_ROLE_ID.get(PLATFORM_UCMP).get(ROOT_ADMIN)
            new_role_info2['menu_id'] = old_role_info_dict['menu_id']
            new_role_info2['module_id'] = old_role_info_dict['module_id']
            old_role_menu_app_list.append(new_role_info2)

    # print(len(old_role_menu_app_list))

    UserRolePermissionModel.create_role_permission_batch(old_role_menu_app_list)


def create_root_permission():
    role_id_list = [
        '3e9d6630e66240518cd2d6eed60f7260',
        '232b1b474b7e4679a5690ff3cde6fdfc',
        'becb83c52b394dd4b16ebcee5ba492f3',
        '757b983966e6425e8d7348d9e550db19'
    ]
    module_id_list = [
        '2b6ff65d-ab3d-476d-94e5-25bd9f26f0ea',
        '960a89cc-044f-4233-ad7e-50c14a290071',
        '8aa018b4-df9c-4990-8d2b-6e1dc02bd29d',
        '3f6943f6-60a1-4b66-be9e-7deef375bbeb',
        '8e0054f7-ad38-4616-913b-47cd08f9c78d'
    ]
    menu_id_list = [
        'a7a053ba-2473-49be-8e94-9826a24b484b',
        'aa562131-7545-4350-bc46-67c6ab6ea042',
        '673e57e2-b43e-47c3-9150-a519d1b30ac8',
        'e48c0be4-d669-4a7a-ac15-1e79df0f40fa',
        'f30c0be4-b419-4c4a-ac15-a729dfee45d1',
        '2d367723-9109-40eb-9312-2481168499d2',
        '9331e59b-aafd-483f-a6ca-2a83f6325d74',
        'f091d0ea-3de3-43c9-94c4-23d83aa51332',
        'd7a676a4-0ae6-472d-b9bd-86d1a16827e1',
        '7609d407-ef30-4bf1-8b96-66617b099228',
        '759732fa-07f9-4ce5-bb69-acb5610edcb5',
        'b6d5aca1-c8ba-4abe-88d1-d00d998e8d4d',
        '2b36eb1f-99e1-4ac6-b11e-ef68bd94c8fb',
        '1212678f-6241-4430-91c1-21ea76b220d1',
        '7c7ac9a6-d4c5-41e0-b6a2-25246d2548de',
        '62976df7-5e12-439c-a9cc-3071ace8ec01',
        'c470ec37-69bc-45f4-ae48-8c8ae3060567',
        '29dae574-51ad-4301-bf43-9d6740d2503f',
        '21cfd78c-06ea-4cbe-8841-c637d58abbcc',
        '751b6f86-e6d0-481d-9b1a-403ecc6cad84',
        'e99ea268-d5b3-4072-b16b-8fc168703417',
        'cd49d97c-bf66-481f-a33d-06350d4aa8ba',
        'd58419b4-83b7-4252-86f2-2a68ca113f8f',
        '30532050-2966-4bea-a90f-bba4e18c1d12',
        '727563a4-993a-4c6f-9ccc-2ee18e862a55',
        '113604cd-fb93-4ab1-8d07-8f6eb9294b90',
        '785944e1-c309-4179-bbf8-8ab45a270012',
        '785944e1-c309-4179-bbf8-8ab45a27000d',
        '5daa36cf-645e-4f84-ba2f-1200181cc4b6',
        '48addd08-4862-487c-a804-9999057b8d9b',
        '65d32025-11fa-44bc-b0e0-555462759979',
        '65d32025-11fa-44cc-b0e0-55546275997c',
        '0b5b4518-cacb-4e0b-9440-2c29a0012ea2',
        '1fba7e49-671d-4a10-b7bd-0fdbac77a401',
        'c07e830e-1bbc-461e-8e15-a6369fc940e1',
        '5af20631-dde0-42d6-bd3a-b948d6b8630b',
        'd02c01bf-b755-4a00-b82b-3f7440bc9580',
        '4e8e690f-a7ab-43a1-a348-2e885dd85b8c',
        '6e8cc90f-a7ab-4ba1-a348-2e885dd85e2c',
        'ce546296-f5ac-4d52-ae5d-478fd4df4081',
        '0e639e79-0f6f-4cd0-9b6b-dc7d6d12b4a3',
        'd63b8d20-3491-49bb-b01f-24d2aea62d6a',
        '890e2f70-faaf-4f1b-9fcc-d83f018267d2',
        '1b5678b1-d157-4357-bdf7-8495f353d253',
        '1b5678b1-d157-4257-bdf7-8495f353d252',
        '5bd0f580-bc7f-11e8-877b-a45e60e0ba23',
        '1b447f6f-1431-4745-ac48-feb2ddf936e2',
        'b712f1c5-c86a-4d09-96e7-bac09550a2c1',
        'cf2ad9dd-0d75-42b7-8abf-2df78826839c',
        '4310f614-655e-4e86-b3c2-8a44c9d2fc48',
        '575b0b84-5621-4e2c-b549-5f5f7455ad08',
        'bb9aeb22-34a7-4e34-9421-6dc5d205c97e',
        '6f29192b-03ae-4442-98fd-dbb0ee8114bb',
        '3a49192b-01ae-3332-65fd-dbb0ee8332ca',
        '1b447f6f-1431-4745-ac48-feb2dfe112f936e2',
        '0638a444-6d87-41d2-934b-6afa926d22c5',
        '0638a444-6d87-41d2-956c-6afa926d22c6',
        '2b12121f-9464-4e65-8582-fff615cb30ee',
        '5b7bcee7-0e1a-49c2-9999-1bffeccaa503',
        '2ffd0db0-9ee4-4ded-bb4a-313a7e731a1a',
        'cae3f7a7-1e96-40bc-8958-27ee203f4fca',
        '4b9b4d27-35e4-4f1a-aa46-15a7175544e2',
        '381d5eb9-1dd3-4318-bcfc-70d9b6046ae8',
        '9ebf757a-01c0-4b81-b08f-96b45f962cd0',
        '58d61cee-7f96-41d4-a79e-ce2aa7b7934a',
        '23270776-44a1-47a5-a0b9-67599bb8aee1',
        'f15486e9-9678-41aa-a532-6e13852ba8e1',
        '3384dca5-ea64-497a-80da-4c4e305c1a83',
        'f15486e9-9678-41la-a532-6e13852ba8e2',
        '3384dca5-ea64-49ga-80da-4c4e305c1a84',
        'abcd0db0-8ee4-3ded-bb4a-313a7e731a1a',
        '41df9804-022e-4524-9d50-4d2b642b7d91',
        '840daa0e-8b93-46cd-946b-aad4bf8c4efd',
        '0b29aeb5-0b10-4898-a7d7-2f4140b31dc0',
        'fa737f54-b82c-4ca0-8f38-4ec4cba95498',
        '45a64247-ab74-4026-8388-227282e38b04',
        '41a64247-ab74-4026-8388-227282e38b22',
        '42a64247-ab74-4026-8388-227282e38b32',
        'ec20694d-4c50-4bd8-a35f-f2b6aaff0e71',
        '487e969b-c862-4219-b84e-d4822c85a7f8',
        '9c60924b-47d9-45e0-b471-151590fc5add',
    ]
    print(len(menu_id_list))
    print(len(set(menu_id_list)))
    data = []
    for role_id in role_id_list:
        for module_id in module_id_list:
            for menu_id in menu_id_list:
                data.append(
                    {"role_id": role_id,
                     "module_id": module_id,
                     "menu_id": menu_id,
                     }
                )
    print(len(data))
    UserRolePermissionModel.create_role_permission_batch(data)
    

def init_root_menu():
    system_module_id = '8aa018b4-df9c-4990-8d2b-6e1dc02bd29d'
    system_menu_id_list = [
        '4310f614-655e-4e86-b3c2-8a44c9d2fc48',
        '575b0b84-5621-4e2c-b549-5f5f7455ad08',
        'bb9aeb22-34a7-4e34-9421-6dc5d205c97e',
        '6f29192b-03ae-4442-98fd-dbb0ee8114bb',
        '3a49192b-01ae-3332-65fd-dbb0ee8332ca',
        '1b447f6f-1431-4745-ac48-feb2dfe112f936e2',
        '0638a444-6d87-41d2-934b-6afa926d22c5',
        '0638a444-6d87-41d2-956c-6afa926d22c6',
    ]

    atomflow_menu_id = '2b6ff65d-ab3d-476d-94e5-25bd9f26f0ea'
    atomflow_menu_id_list = [
        '2b12121f-9464-4e65-8582-fff615cb30ee',
        '5b7bcee7-0e1a-49c2-9999-1bffeccaa503',
        '2ffd0db0-9ee4-4ded-bb4a-313a7e731a1a',
        'cae3f7a7-1e96-40bc-8958-27ee203f4fca',
        '4b9b4d27-35e4-4f1a-aa46-15a7175544e2',
        '381d5eb9-1dd3-4318-bcfc-70d9b6046ae8',
        '9ebf757a-01c0-4b81-b08f-96b45f962cd0',
        '58d61cee-7f96-41d4-a79e-ce2aa7b7934a',
        '23270776-44a1-47a5-a0b9-67599bb8aee1',
        'f15486e9-9678-41aa-a532-6e13852ba8e1',
        '3384dca5-ea64-497a-80da-4c4e305c1a83',
        'f15486e9-9678-41la-a532-6e13852ba8e2',
        '3384dca5-ea64-49ga-80da-4c4e305c1a84',
        'abcd0db0-8ee4-3ded-bb4a-313a7e731a1a',
    ]
    cmdb_module_id = '960a89cc-044f-4233-ad7e-50c14a290071'
    cmdb_menu_id_list = [
        '41df9804-022e-4524-9d50-4d2b642b7d91',
        '840daa0e-8b93-46cd-946b-aad4bf8c4efd',
        '0b29aeb5-0b10-4898-a7d7-2f4140b31dc0',
        'fa737f54-b82c-4ca0-8f38-4ec4cba95498',
        '45a64247-ab74-4026-8388-227282e38b04',
        '41a64247-ab74-4026-8388-227282e38b22',
        '42a64247-ab74-4026-8388-227282e38b32',
        'ec20694d-4c50-4bd8-a35f-f2b6aaff0e71',
        '487e969b-c862-4219-b84e-d4822c85a7f8',
        '9c60924b-47d9-45e0-b471-151590fc5add',
    ]
    module_id_list = [
        '960a89cc-044f-4233-ad7e-50c14a290071',
        '2b6ff65d-ab3d-476d-94e5-25bd9f26f0ea',
        '8aa018b4-df9c-4990-8d2b-6e1dc02bd29d',
        '8e0054f7-ad38-4616-913b-47cd08f9c78d',
        '3f6943f6-60a1-4b66-be9e-7deef375bbeb',
    ]
    conn = psycopg2.connect(**CONNECT_CONFIG_TO_MENU)
    cur = conn.cursor()
    """
    sql2 = "select id from role where name not in (%s)" % ','.join(['%s'] * len(OLD_ROLE_TYPE_LIST))
    cursor.execute(sql2, OLD_ROLE_TYPE_LIST)
    """
    sql_str = "SELECT id, title, parent_id, url, sys_module_id, icon, sortby from sys_menu " \
              "WHERE sys_module_id in (%s)" % ','.join(['%s'] * len(module_id_list))
    cur.execute(sql_str, module_id_list)
    rows = cur.fetchall()
    data = []
    for menu_id, title, parent_id, url, sys_module_id, icon, sortby in rows:
        data.append({
            "id": menu_id,
            "title": title,
            "parent_id": parent_id,
            "url": url,
            "sys_module_id": sys_module_id,
            "icon": icon,
            "sortby": sortby,
            "project_id": PROJECT_ID,
        })
    # print(data)

    for data_info in data:
        data_list = []
        data_list.append(data_info)
        # print(data_list)

        try:
            SysMenuModel.add_menu_batch(data_list)
            print('插入成功')
        except:
            conn.rollback()
            continue


if __name__ == '__main__':
    # init_role_permission()
    create_root_permission()
    # init_root_menu()
