#-*- coding: utf-8 -*-
'''
@author: mathews
'''

import re


def is_date(date_str):
    date_format = '^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}'
    m = re.match(date_format, date_str)
    return m is not None


def is_datetime(datetime_str):
    datetime_format = '^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2} [0-9]{1,2}:[0-9]{1,2}:[0-9]{1,2}'
    m = re.match(datetime_format, datetime_str)
    return m is not None