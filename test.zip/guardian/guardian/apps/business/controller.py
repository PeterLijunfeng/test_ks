import math
import json
from flask import request
from flask import Blueprint
from guardian.common.errors import ParamsException, ApiException, HAS_SUB_ELE_ERROR
from guardian.common.rest import restful
from guardian.common.ucmp.ucmp_api import chk_resource_in_apps
from guardian.log4 import app_logger as log
from guardian.settings import APIBASEURL
from guardian.apps.business.services import gen_segmentation_words
from guardian.apps.business.services import get_app_name_similar_by_seg
from guardian.apps.business.models import BusinessModel, BusinessAppsModel, BusinessAppOrgModel
from guardian.apps.business.models import get_business_info_by_app_id
from guardian.apps.users.models import UsersOrgsModel, UsersModel

business_site = Blueprint('business', __name__, url_prefix="%s/business" % APIBASEURL)


@business_site.route('/chk/name', methods=["GET"])
@restful
def check_business_name(*args, **kwargs):
    """
    name
    :param args:
    :param kwargs:
    :return:
    不存在 返回 {}
    存在 返回 业务的信息
    """
    user = kwargs.get("user")
    project_id = user["project_id"]
    name = request.args.get('name', '')
    if not name:
        raise ParamsException("[name] is missing or not support")
    business_obj = BusinessModel.get_one_name(name, project_id)
    if not business_obj:
        return {}
    return {
        "id": business_obj.id,
        "name": business_obj.name,
        "description": business_obj.description,
        "project_id": business_obj.project_id,
        "org_id": business_obj.org_id,
        "org_array": json.loads(business_obj.org_array),
        "sortby": business_obj.sortby,
        "enable": business_obj.enable
    }


@business_site.route('/save', methods=['POST'])
@restful
def create_business(*args, **kwargs):
    """
    {
        "id": "",  # 更新提供此字段
        "name": "test123",
        "description": "test123",
        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
        "org_id": "42ea4f38d8774999b6bce443a78e3d6f",
        "org_array": [],
        "sortby": 0,
        "enable": 1
    }
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'id': 'dbdf7fbd-att1-4d34-9ba5-2d3779c11b21'
        }
    }
    """
    user = kwargs.get("user")
    data = request.get_json()
    data["project_id"] = user["project_id"]
    if "id" in data:
        log.info("find [id] in request data；DO Update !")
        if not data.get("id"):
            raise ParamsException("update failed! the business id is [\"\"]")
        business = BusinessModel.get_one(data.get("id"))
        if not business:
            raise ParamsException("update failed! can not find anyone by id:[%s]" % data.get("id"))
        business.update_business(**data)
    else:
        must_params = ["name", "project_id", "org_id", "org_array"]
        chk_params = set(must_params) - set(data.keys())
        if chk_params:
            log.error("Params missing: [%s] " % (','.join(chk_params)))
            raise ParamsException("Params missing: [%s] " % (','.join(chk_params)))
        business = BusinessModel.create_business(**data)
    return {
        "id": business.id
    }


@business_site.route('/del', methods=['DELETE'])
@restful
def delete_business(*args, **kwargs):
    data = request.get_json()
    if not data.get("id"):
        raise ParamsException("del failed! the business id is [\"\"]")
    business_obj = BusinessModel().get_one(data.get("id"))
    if not business_obj:
        raise ParamsException("del failed! can not find anyone by id:[%s]" % data.get("id"))
    cnt, business_apps_obj = BusinessAppsModel().get_list(business_id=data.get("id"))
    if business_apps_obj:
        raise ParamsException("del failed! can not delete business by id:[%s] which has apps" % data.get("id"))
    log.info('......business_obj.is_del is %s', business_obj.is_del)
    obj_id = business_obj.del_business()
    return {
        "id": obj_id
    }


@business_site.route('/list', methods=['GET'])
@restful
def list_business(*args, **kwargs):
    """

    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'business': [
                {'id': '7b7e25ecf1c3452b8e637870c8539719',
                 'name': 'test',
                 'description': 'tttt',
                 'project_id': '0eb082df17d44c8abf46414d8a1397f8',
                 'org_id': '7249332a-f7fc-4a84-9a00-77008713f92e',
                 'org_name': '测试组织机构A',
                 'enable': 1
                }
            ],
            'page': 1,
            'page_count': 1,
            'total': 2
        }
    }
    """
    user = kwargs.get("user")
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    filters = {
        "project_id": user["project_id"],
        "name": request.args.get("name", ""),
        "org_id": request.args.get("org_id", "")
    }
    cnt, business_lists = BusinessModel.get_list(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for business, org in business_lists:
        rst.append({
            "id": business.id,
            "name": business.name,
            "description": business.description,
            "project_id": business.project_id,
            "org_id": business.org_id,
            "org_name": org.org_name,
            "org_array": json.loads(business.org_array),
            "sortby": business.sortby,
            "enable": business.enable
        })
    return {
        "business": rst,
        "page": page_idx,
        "page_count": math.ceil(cnt / limit),
        "total": cnt
    }


@business_site.route('/org/businessinfo', methods=['GET'])
@restful
def get_business_info_by_org(*args, **kwargs):
    """
    :param args: org_id
    :param kwargs:
    :return:
    {
    'rst': 'ok',
    'data': {
             'business': [{
                 'id': '7fa4950e010a4b31bb7af1eb1d3ed070',
                 'name': 'dwa'
                    },
                {
                 'id': '200014150bfc40b89c34d3f2723afb93',
                 'name': 'dwa1'
                }],
           'page': 1,
           'page_count': 1,
           'total': 2
          }
     }
    """
    org_id = request.args.get("org_id")
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    if not org_id:
        raise ParamsException("id maybe missing")
    org_obj = UsersOrgsModel(id=org_id).get_one()
    if not org_obj:
        log.error("can not found org by id [%s]" % org_id)
        raise ParamsException("can not found org by id [%s]" % org_id)
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"],
    }
    sub_orgs_list = UsersOrgsModel.get_sub_orgs(org_obj.node_id, org_obj.parent_code, **filters)
    rst = [org_id]
    for org in sub_orgs_list:
        rst.append(org.id)
    log.info('rst is %s', rst)
    business_filters = {
        "org_ids": rst
    }
    cnt, business_lists = BusinessModel.get_list(page_idx=page_idx, limit=limit, **business_filters)
    res = []
    for business, org in business_lists:
        res.append({
            "id": business.id,
            "name": business.name
        })
    return {
        "business": res,
        "page": page_idx,
        "page_count": math.ceil(cnt / limit),
        "total": cnt
    }


@business_site.route('/app/businessinfo', methods=['GET'])
@restful
def get_business_info_by_app(*args, **kwargs):
    """
    :param args: app_id
    :param kwargs:
    :return:{
               'rst': 'ok',
               'data': {
                       'business_id': '200014150bfc40b89c34d3f2723afb93',
                       'business_name': 'dwa1'
                       }
            }
    """
    app_id = request.args.get('app_id', '')
    if not app_id:
        log.error("[app_id] params is missing")
        raise ParamsException("[app_id] params is missing")
    business_info = get_business_info_by_app_id(app_id=app_id)
    if not business_info:
        log.error("can not get business info by app_id: {0}".format(app_id))
        raise ParamsException("can not get business info by app_id: {0}".format(app_id))
    return {
        'business_id': business_info.id,
        'business_name': business_info.name
    }


@business_site.route('/apps/list', methods=['GET'])
@restful
def list_apps_by_business(*args, **kwargs):
    """

    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'apps': [
                {'app_name': 'ttt2',
                 'description': 'ttt',
                 'id': '66009391c17549d3a85b32c57b12c2c6',
                 'business_id': '7b7e25ecf1c3452b8e637870c8539719',
                 'short': 'ttt2', 'enable': 1}
            ],
            'page': 1,
            'page_count': 1,
            'total': 4
        }
    }
    """
    user = kwargs.get("user")
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    filters = {
        "project_id": user["project_id"],
        "app_ids": request.args.get("app_ids", ""),
        "business_app_name": request.args.get("name", ""),
        "shorter_name": request.args.get("name", ""),
        "business_id": request.args.get("business_id", "")
    }
    cnt, business_lists = BusinessAppsModel.get_list(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for item in business_lists:
        rst.append({
            "app_name": item.business_app_name,
            "description": item.description,
            "id": item.id,
            "business_id": item.business_id,
            "short": item.shorter_name,
            "enable": item.enable,
        })
    return {
        "apps": rst,
        "page": page_idx,
        "page_count": math.ceil(cnt / limit),
        "total": cnt
    }


@business_site.route('/org/apps/list', methods=['GET'])
@restful
def list_apps_by_user_org(*args, **kwargs):
    """
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {
            'apps': [
                {'app_name': 'ttt2',
                 'description': 'ttt',
                 'id': '66009391c17549d3a85b32c57b12c2c6',
                 'business_id': '7b7e25ecf1c3452b8e637870c8539719',
                 'short': 'ttt2', 'enable': 1}
            ],
            'page': 1,
            'page_count': 1,
            'total': 4
        }
    }
    """
    user = kwargs.get("user")
    limit = request.args.get('limit', default=20, type=int)
    page_idx = request.args.get('page', default=1, type=int)
    user_id = user["id"]
    user_obj = UsersModel.get_one(user_id=user_id)
    filters = {
        "org_id": user_obj.org_id,
    }
    cnt, apps_lists = BusinessAppOrgModel.list_app_info_by_org(page_idx=page_idx, limit=limit, **filters)
    rst = []
    for _, item in apps_lists:
        rst.append({
            "app_name": item.business_app_name,
            "description": item.description,
            "id": item.id,
            "business_id": item.business_id,
            "short": item.shorter_name,
            "enable": item.enable,
        })
    return {
        "apps": rst,
        "page": page_idx,
        "page_count": math.ceil(cnt / limit),
        "total": cnt
    }


@business_site.route('/app/name/similar', methods=['GET'])
@restful
def get_apps_similarity(*args, **kwargs):
    """
    获取应用相似度，按照相似度降序返回
    :param args: name 应用名称， similar 相似度比例 0-1 float
    :param kwargs:
    :return:
    {
        "rst": "ok",
        "data": [
            {
                "id": "6c91140d6cc4448daf388262ff9a5933",
                "business_app_name": "t1",
                "shorter_name": "t1",
                "similar": 1
            }
        ]
    }
    """
    business_app_name, = request.args.get("name", ""),
    name_seg_set = gen_segmentation_words(business_app_name)
    similar = request.args.get("similar", default=0.1, type=float)
    user = kwargs.get("user")
    filters = {
        "project_id": user["project_id"],
        "app_name_seg": ','.join(name_seg_set),
    }
    app_tuples = BusinessAppsModel.get_apps_similarity(**filters)
    if app_tuples:
        return get_app_name_similar_by_seg(name_seg_set, app_tuples, similar)
    else:
        return []


@business_site.route('/apps/chk/name', methods=["GET"])
@restful
def check_business_apps_name(*args, **kwargs):
    """
    name
    :param args: name
    :param kwargs:
    :return:
    不存在 返回 {}
    存在 返回 业务的信息
    """
    user = kwargs.get("user")
    project_id = user["project_id"]
    name = request.args.get('name', '')
    if not name:
        raise ParamsException("[name] is missing or not support")
    app_obj = BusinessAppsModel.get_one_name(name, project_id)
    if not app_obj:
        return {}
    return {
        "id": app_obj.id,
        "business_app_name": app_obj.business_app_name,
        "shorter_name": app_obj.shorter_name,
        "description": app_obj.description,
        "project_id": app_obj.project_id,
        "business_id": app_obj.business_id,
        "enable": app_obj.enable
    }


@business_site.route('/apps/save', methods=['POST'])
@restful
def create_business_apps(*args, **kwargs):
    user = kwargs.get("user")
    data = request.get_json()
    data["project_id"] = user["project_id"]
    if "id" in data:
        log.info("find [id] in request data；DO Update !")
        if not data.get("id"):
            raise ParamsException("update failed! the business id is [\"\"]")
        business_app = BusinessAppsModel.get_one(data.get("id"))
        if not business_app:
            raise ParamsException("update failed! can not find anyone by id:[%s]" % data.get("id"))
        if data.get("business_app_name"):
            data["segmentation"] = ','.join(gen_segmentation_words(data.get("business_app_name")))
        business_app.update_app(**data)
    else:
        must_params = ["business_app_name", "shorter_name", "business_id", "project_id"]
        chk_params = set(must_params) - set(data.keys())
        if chk_params:
            log.error("Params missing: [%s] " % (','.join(chk_params)))
            raise ParamsException("Params missing: [%s] " % (','.join(chk_params)))
        data["segmentation"] = ','.join(gen_segmentation_words(data.get("business_app_name")))
        business_app = BusinessAppsModel.create_app(**data)
        business_obj = BusinessModel().get_one(data.get("business_id"))
        BusinessAppOrgModel.create_business_app_org(business_app.id, business_obj.org_id)
    return {
        "id": business_app.id
    }


@business_site.route('/apps/del', methods=['DELETE'])
@restful
def delete_apps(*args, **kwargs):
    user = kwargs.get("user")
    token = user["token"]
    data = request.get_json()
    if not data.get("id"):
        raise ParamsException("del failed! the business id is [\"\"]")
    if chk_resource_in_apps(token, data.get("id")):
        raise ApiException(HAS_SUB_ELE_ERROR["message"], HAS_SUB_ELE_ERROR["error_code"])

    log.debug("get app id is %s" % data.get("id"))
    business_apps_obj = BusinessAppsModel.get_one(data.get("id"))
    if not business_apps_obj:
        raise ParamsException("del failed! can not find anyone by id:[%s]" % data.get("id"))
    obj_id = business_apps_obj.del_app()
    return {
        "id": obj_id
    }


@business_site.route('/app/org', methods=['GET'])
@restful
def get_app_org(*args, **kwargs):
    """
    获取该应用已授权的组织机构
    :param args: app_id
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': ['2']
    }
    """
    app_id = request.args.get('app_id', "")
    if not app_id.strip():
        raise ParamsException("app_id is empty")
    app_orgs = BusinessAppOrgModel.get_orgs_by_app_id(app_id)
    rst = []
    for item in app_orgs:
        rst.append(item.org_id)
    return rst


@business_site.route('/app/org', methods=['PUT'])
@restful
def update_app_org(*args, **kwargs):
    """

    :param args:
    :param kwargs:
    :return:
    """
    app_id = request.json.get("app_id", "")
    org_ids = request.json.get("org_ids", [])
    if not app_id.strip():
        raise ParamsException("app_id is empty")
    if not org_ids:
        raise ParamsException("org_ids array is empty")
    app_orgs = BusinessAppOrgModel.get_orgs_by_app_id(app_id)
    db_org_ids = []
    for item in app_orgs:
        db_org_ids.append(item.org_id)
    org_ids_diff_org_info = list(set(org_ids).difference(set(db_org_ids)))
    for org in org_ids_diff_org_info:
        BusinessAppOrgModel.create_business_app_org(app_id, org)
    org_info_diff_org_ids = list(set(db_org_ids).difference(set(org_ids)))
    for org in org_info_diff_org_ids:
        BusinessAppOrgModel.delete_app_org_by_app_org(app_id, org)

    return {}


@business_site.route('/apps/orgs', methods=['POST'])
@restful
def incre_auth_bulk_apps_orgs(*args, **kwargs):
    """
    增量授权多个应用到组织机构
    {
        "app_ids": ["facd2c8475e543c1b7f705e2ff056cfe"],
        "org_ids": ["571ab95c37174d20a00ff5d2840993b0"]
    }
    :param args:
    :param kwargs:
    :return:
    {
        'rst': 'ok',
        'data': {}
    }
    """
    app_ids = request.json.get("app_ids", [])
    org_ids = request.json.get("org_ids", [])
    if not app_ids:
        raise ParamsException("app_ids  array is empty")
    if not org_ids:
        raise ParamsException("org_ids array is empty")
    app_org_ids_dict = {}
    for app_id in app_ids:
        exist_org_id_list = app_org_ids_dict.get(app_id, [])
        app_orgs = BusinessAppOrgModel.get_orgs_by_app_id(app_id)
        for app in app_orgs:
            exist_org_id_list.append(app.org_id)
        add_org_ids = list(set(org_ids).difference(set(exist_org_id_list)))
        app_org_ids_dict[app_id] = add_org_ids
    add_app_org_list = []
    for app_id, add_org_ids in app_org_ids_dict.items():
        for add_org_id in add_org_ids:
            add_app_org_list.append((app_id, add_org_id))
    if add_app_org_list:
        BusinessAppOrgModel.bulk_add_app_org(add_app_org_list)

    return {}


@business_site.route('/businessinfo', methods=['GET'])
@restful
def get_business_info_by_id(*args, **kwargs):
    """

    :param args:   business_id     # 业务id
    :param kwargs:
    :return:
            {
                "rst": "ok",
                "data": {
                        "business_id": "347d80f4115f4dee9a4b816490e5a26f",
                        "business_name": "test1234",
                        "description": "tttt",
                        "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                        "org_id": "7249332a-f7fc-4a84-9a00-77008713f92e"
          }
}
    """

    business_id = request.args.get("business_id", '')

    if not business_id:
        raise ParamsException("business_id is empty")

    business_info = BusinessModel().get_one(business_id)

    info_dict = {
        'business_id': business_info.id,
        'business_name': business_info.name,
        'description': business_info.description,
        'project_id': business_info.project_id,
        'org_id': business_info.org_id
    }

    return info_dict

