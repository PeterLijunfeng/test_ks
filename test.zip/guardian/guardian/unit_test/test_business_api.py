import unittest
import requests
from datetime import datetime
from time import time


class UsersTestCase(unittest.TestCase):
    def setUp(self):
        self.base_url = "http://127.0.0.1:7000/gd/v2"
        self.start_time = datetime.now()
        self.token = 'gAAAAABcrDumwxlnRvZj2vepvQA26VBaDeEcIlcdVlg8e4hvHJ4iSp6Tsbd7uUvsLLCCNEU83Ykz4bpx_V3wbL27PhrZNuH7Kt6JRoi8UPZXYW1pggJYPi9Mv9eD9Euwk3xGQAhWNA-6wYIwJvI3qKEG3x_4ix_ousxjBdmor85joX7zIb_Sf1A'
        self.headers = {'X-Subject-Token': self.token}
        print("start unittest -----{0}".format(datetime.now()))

    def _test_check_business_name(self):
        api_start_time = time()
        url = self.base_url + "/business/chk/name"
        print("url is %s" % url)
        params = {
            "name": "test"
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_check_business_name cost time: {0}".format(time() - api_start_time))

    def _test_create_business(self):
        api_start_time = time()
        url = self.base_url + "/business/save"
        print("url is %s" % url)
        req_data = {
            "id": "347d80f4115f4dee9a4b816490e5a26f",
            "name": "test123",
            "description": "tttt",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "org_id": "7249332a-f7fc-4a84-9a00-77008713f92e",
            "org_array": ["7249332a-f7fc-4a84-9a00-77008713f92e"],
            "sortby": 0,
            "enable": 1,
        }
        data = requests.post(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_create_business cost time: {0}".format(time() - api_start_time))

    def _test_delete_business(self):
        api_start_time = time()
        url = self.base_url + "/business/del"
        print("url is %s" % url)
        req_data = {
            "id": 'f715c4a59d7d4afea69434117d318853'
        }
        data = requests.delete(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_delete_business cost time: {0}".format(time() - api_start_time))

    def _test_list_business(self):
        api_start_time = time()
        url = self.base_url + "/business/list"
        print("url is %s" % url)
        params = {
            "limit": 2,
            "page": 3,
            # "name": "t"
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_list_business cost time: {0}".format(time() - api_start_time))

    def _test_get_business_info_by_app(self):
        api_start_time = time()
        url = self.base_url + "/business/app/businessinfo"
        print("url is %s" % url)
        params = {
            "app_id": '0d7ca344ecfc4763bf3f1d18486db5f4'
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_get_business_info_by_app cost time: {0}".format(time() - api_start_time))

    def _test_create_business_apps(self):
        api_start_time = time()
        url = self.base_url + "/business/apps/save"
        print("url is %s" % url)
        req_data = {
            "id": "7a00c3a8dfbc4c6b82bb62af32a5eac5",
            "business_app_name": "test333333",
            "shorter_name": "test333333",
            "description": "test333333",
            "business_id": "347d80f4115f4dee9a4b816490e5a26f",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "enable": 1
        }
        data = requests.post(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_create_business_apps cost time: {0}".format(time() - api_start_time))

    def _test_check_business_apps_name(self):
        api_start_time = time()
        url = self.base_url + "/business/apps/chk/name"
        print("url is %s" % url)
        params = {
            "name": "ttt"
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_check_business_apps_name cost time: {0}".format(time() - api_start_time))

    def _test_delete_apps(self):
        api_start_time = time()
        url = self.base_url + "/business/apps/del"
        print("url is %s" % url)
        req_data = {
            "id": '0dc4d733e4b34df69404a0714da89346'
        }
        data = requests.delete(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_delete_apps cost time: {0}".format(time() - api_start_time))

    def _test_list_apps_by_business(self):
        api_start_time = time()
        url = self.base_url + "/business/apps/list"
        print("url is %s" % url)
        params = {
            "limit": 20,
            "page": 1,
            "name": "h"
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_list_apps_by_business cost time: {0}".format(time() - api_start_time))

    def test_list_apps_by_org(self):
        api_start_time = time()
        url = self.base_url + "/business/org/apps/list"
        print("url is %s" % url)
        params = {}
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_list_apps_by_org cost time: {0}".format(time() - api_start_time))

    def _test_get_apps_similarity(self):
        api_start_time = time()
        url = self.base_url + "/business/app/name/similar"
        print("url is %s" % url)
        params = {
            "name": "t1",
            "similar": 0.2
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_get_apps_similarity cost time: {0}".format(time() - api_start_time))

    def _test_list_sys_conf(self):
        api_start_time = time()
        url = self.base_url + "/conf"
        print("url is %s" % url)
        data = requests.post(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_sys_conf cost time: {0}".format(time() - api_start_time))

    def _test_get_app_org(self):
        api_start_time = time()
        url = self.base_url + "/business/app/org"
        print("url is %s" % url)
        data = requests.get(url, params={'app_id': '1'}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_app_org cost time: {0}".format(time() - api_start_time))

    def _test_get_business_by_org(self):
        api_start_time = time()
        url = self.base_url + "/business/org/businessinfo"
        print("url is %s" % url)
        data = requests.get(url, params={'org_id': '639aff32-23b8-4ded-9820-92618cd88d9e'}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_business_by_org cost time: {0}".format(time() - api_start_time))

    def _test_update_app_org(self):
        api_start_time = time()
        url = self.base_url + "/business/app/org"
        print("url is %s" % url)
        r_data = {
            "app_id": "1",
            "org_ids": ["2"],
        }
        data = requests.put(url, json=r_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_update_app_org cost time: {0}".format(time() - api_start_time))

    def _test_incre_auth_bulk_apps_orgs(self):
        api_start_time = time()
        url = self.base_url + "/business/apps/orgs"
        print("url is %s" % url)
        r_data = {
            "app_ids": ["45370ca9bbc14a7f8f914ccc089884aa", "3d07cffb51944e73b35342803100fab8"],
            "org_ids": ["42ea4f38d8774999b6bce443a78e3d6f"],
        }
        data = requests.post(url, json=r_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("incre_auth_bulk_apps_orgs cost time: {0}".format(time() - api_start_time))

    def _test_business_info(self):
        api_start_time = time()
        url = self.base_url + "/business/businessinfo"
        print("url is %s" % url)
        params = {
            # "business_id": "347d80f4115f4dee9a4b816490e5a26f"
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("incre_auth_bulk_apps_orgs cost time: {0}".format(time() - api_start_time))


def tearDown(self):
    print("end unittest -----{0}".format(datetime.now()))
