
import json
from celery.decorators import task
from celery.utils.log import get_task_logger
from guardian.etc.strategy_conf import MessageTypeDict
from guardian.etc.strategy_conf import EMAIL, SMS, INNER_NOTICE
from guardian.settings import EMAIL_SUBJECT, EMAIL_CONTENT
from guardian.apps import SUCCESS, FAILED, MESSAGE_TYPE_DICT
from guardian.apps.messages.models import MessagesModel
from guardian.apps.messages.models import InnerNoticeModel
from guardian.apps.messages.models import EmailConfigModel
from guardian.apps.messages.models import SmsConfigModel
from guardian.common.message.mail import GuardianMail
from guardian.common.message.sms import GuardianSms

log = get_task_logger("celery_logger")


@task(name="tasks.message.celery_send_mail", queue="gd_message", routing_key="message.email")
def send_mail(mail_info_str):
    mail_info = json.loads(mail_info_str)
    status = GuardianMail.send_mail(
        mail_host=mail_info.get("mail_host"),
        smtp_port=mail_info.get("smtp_port"),
        is_tls=mail_info.get("is_tls"),
        user_name=mail_info.get("user_name"),
        from_addr=mail_info.get("from_addr"),
        mail_pass=mail_info.get("mail_pass"),
        to_addr=mail_info.get("to_addr"),
        sub=mail_info.get("sub"),
        content=mail_info.get("content")
    )
    if status.get("code") and status.get("code") == 200:
        log.info("celery_send_mailto_addr：'{0}' status：{1} messsage：'{2}'"
                 .format(mail_info.get("to_addr"), str(status.get("code")), status.get("message")))
        return status
    else:
        log.error("celery_send_mail to_addr：'{0}' status：{1} messsage：'{2}' error info:'{3}'"
                  .format(mail_info.get("to_addr"), str(status.get("code")), status.get("message"), status.get("error")))
        return status


@task(name="tasks.message.celery_send_template_mail", queue="gd_message", routing_key="message.template_email")
def send_mail_message(data):
    data = json.loads(data)
    msgs_id = data.get("msgs_id")
    status = FAILED
    status_info = "send mail message failed"
    try:
        project_id = data.get("project_id")
        email_list = data.get("email_list", "")
        no_email_users = data.get("no_email_users", "")
        all_user = data.get("all_user", "")
        messgs = data.get("messgs")
        email_obj = EmailConfigModel().get_one_by_project_id(project_id=project_id)
        if email_obj:
            to_addr = email_list if email_list else email_obj.test_to_user_addr
            status = GuardianMail.send_mail(
                mail_host=email_obj.server_addr,
                smtp_port=email_obj.server_port,
                is_tls=email_obj.is_tls,
                user_name=email_obj.user_name,
                from_addr=email_obj.from_user_addr,
                mail_pass=email_obj.user_pass,
                to_addr=to_addr,
                sub=messgs.get("title") if messgs.get("title") else EMAIL_SUBJECT,
                content=messgs.get("content") if messgs.get("content") else EMAIL_CONTENT
            )
            if status.get("code") and status.get("code") == 200:
                log.info("celery_send_mail to_addr：'{0}' status：{1} messsage：'{2}'".format(
                    to_addr, str(status.get("code")), status.get("message")))
                status = SUCCESS
                status_info = MessageTypeDict.get(EMAIL)
            else:
                log.error("celery_send_mail to_addr：'{0}' status：{1} messsage：'{2}' error info:'{3}'".format(
                    to_addr, str(status.get("code")), status.get("message"), status.get("error")))
                status = FAILED
                status_info = "Failed celery_send_mail messsage：'{0}' error info:'{1}'".format(
                    status.get("message"), status.get("error"))
        else:
            log.error("Failed get_mail_conf by project_id：'{0}'".format(project_id))
            status = FAILED
            status_info = "Failed get_mail_conf by project_id：'{0}'".format(project_id)
        if status and no_email_users:
            status_info = "Failed to username: %s" % no_email_users
        elif not status:
            status_info += "to username: %s" % all_user
        else:
            status_info = status_info
    except Exception as e:
        status = FAILED
        status_info = "ERROR send mail:" + str(e)
    finally:
        data = {
            "message_type_id": EMAIL,
            "message_type_name": MessageTypeDict.get(EMAIL),
            "status": status,
            "status_info": status_info
        }
        msgs_obj = MessagesModel(id=msgs_id).get_one()
        msgs_obj.update_message(**data)


@task(name="tasks.message.celery_send_inner_notice", queue="gd_message", routing_key="message.innernotice")
def send_inner_notice_message(data):
    data = json.loads(data)
    message_type_id = data.get("notice_type_id")
    msgs_id = data.get("msgs_id")
    status = FAILED
    status_info = "send inner notice message failed"
    try:
        user_id_list = data.get("user_id_list")
        msgs = data.get("messgs")
        msgs_id = data.get("msgs_id")
        notice_msgs_info_list = []
        for user_id in user_id_list:
            notice_msgs_info_list.append({
                "notice_type": message_type_id,
                "notice_type_name": MESSAGE_TYPE_DICT.get(message_type_id),
                "title": msgs.get("title"),
                "content": msgs.get("content"),
                "user_id": user_id,
                "project_id": data.get("project_id"),
                "level": data.get("level")
            })
        InnerNoticeModel.add_notice_batch(notice_msgs_info_list)
        status = SUCCESS
        status_info = MessageTypeDict.get(INNER_NOTICE)
    except Exception as e:
        status = FAILED
        status_info = "send inner notice:" + str(e)
    finally:
        data = {
            "message_type_id": message_type_id,
            "message_type_name": MESSAGE_TYPE_DICT.get(message_type_id),
            "status": status,
            "status_info": status_info
        }
        msgs_obj = MessagesModel(id=msgs_id).get_one()
        msgs_obj.update_message(**data)


@task(name="tasks.message.celery_send_sms", queue="gd_message", routing_key="message.sms")
def send_sms_message(data):
    data = json.loads(data)
    msgs_id = data.get("msgs_id")
    status = FAILED
    status_info = "send sms message failed"
    try:
        messgs = data.get("messgs")
        project_id = data.get("project_id")
        phone_list = data.get("phone_list")
        no_phone_users = data.get("no_phone_users")
        all_user = data.get("all_user")
        sms_obj = SmsConfigModel().get_one_by_project_id(project_id=project_id)
        if sms_obj:
            status = GuardianSms.send_sms(
                server_addr=sms_obj.server_addr,
                server_port=sms_obj.server_port,
                account_id=sms_obj.account_id,
                account_token=sms_obj.account_token,
                extra_params=json.loads(sms_obj.extra_params) if sms_obj.extra_params else [],
                phones=phone_list,
                text=messgs.get("content"),
                title=messgs.get("title")
            )
            if status.get("code") and status.get("code") == 200:
                log.info("celery_send_sms account_id：'{0}' status：{1} messsage：'{2}'"
                         .format(sms_obj.account_id, str(status.get("code")), status.get("message")))
                status = SUCCESS
                status_info = MessageTypeDict.get(SMS)
            else:
                log.error("celery_send_sms account_id：'{0}' status：{1} messsage：'{2}' error info:'{3}'"
                          .format(sms_obj.account_id, str(status.get("code")), status.get("message"),
                                  status.get("error")))
                status = FAILED
                status_info = "Failed celery_send_sms messsage：'{0}' error info:'{1}'" \
                    .format(status.get("message"), status.get("error"))
        else:
            status = FAILED
            status_info = "Failed get_sms_conf by project_id：'{0}'".format(project_id)
        if status and no_phone_users:
            status_info = "Failed to username: %s" % no_phone_users
        elif not status:
            status_info += "to username: %s" % all_user
        else:
            status_info = status_info
    except Exception as e:
        status = FAILED
        status_info = "ERROR send sms:" + str(e)
    finally:
        data = {
            "message_type_id": SMS,
            "message_type_name": MessageTypeDict.get(SMS),
            "status": status,
            "status_info": status_info
        }
        msgs_obj = MessagesModel(id=msgs_id).get_one()
        msgs_obj.update_message(**data)
