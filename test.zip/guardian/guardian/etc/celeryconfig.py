import sys
import time
from celery.schedules import crontab
from guardian.settings import MQ_HOST, MQ_PASSWD, MQ_PORT, MQ_TYPE, MQ_USER, MQ_V_HOST
from guardian.settings import REDIS_HOST, REDIS_PORT, REDIS_PASSWD, REDIS_DB
from guardian.settings import LICENSE_CHECK_DURATION

from guardian.log4 import celery_logger

celery_logger.debug("init celery")

celery_logger.debug("init celery, check env: %s" % str(sys.path))

# ----------------------------
BROKER_HOST = MQ_HOST
BROKER_PORT = MQ_PORT
BROKER_USER = MQ_USER
BROKER_PASSWORD = MQ_PASSWD
BROKER_VHOST = MQ_V_HOST
BROKER_TRANSPORT = MQ_TYPE

CELERY_RESULT_BACKEND = 'redis'
CELERY_REDIS_HOST = REDIS_HOST
CELERY_REDIS_PORT = REDIS_PORT
CELERY_REDIS_DB = REDIS_DB
CELERY_REDIS_PASSWORD = REDIS_PASSWD
REDIS_CONNECT_RETRY = True
CELERY_IMPORTS = (
    "guardian.tasksmgr.normal.helloceleryworker",
    "guardian.tasksmgr.normal.message_worker",
    "guardian.tasksmgr.timed.schedule_test",
    "guardian.tasksmgr.timed.license_expire_reminder",
)
CELERY_SEND_EVENTS = True
CELERY_TASK_RESULT_EXPIRES = 1800
CELERY_DISABLE_RATE_LIMITS = True
# CELERYD_LOG_FILE = "/var/log/celeryd.log"
# CELERYD_LOG_LEVEL = "INFO"
CELERYD_MAX_TASKS_PER_CHILD = 1024
CELERYD_SOFT_TASK_TIME_LIMIT = 1800
CELERYD_TASK_TIME_LIMIT = 1800
CELERY_DEFAULT_QUEUE = "default"
CELERY_DEFAULT_EXCHANGE = "guardian"
CELERY_DEFAULT_ROUTING_KEY = "default"
CELERY_DEFAULT_EXCHANGE_TYPE = "topic"

TIMEZONE = "UTC"
CELERY_QUEUES = {
    "default": {
        "binding_key": CELERY_DEFAULT_ROUTING_KEY,
        "exchange_type": CELERY_DEFAULT_EXCHANGE_TYPE,
        "exchange": CELERY_DEFAULT_EXCHANGE
    },
    "musir": {
        "binding_key": "test.#",
        "exchange_type": CELERY_DEFAULT_EXCHANGE_TYPE,
        "exchange": CELERY_DEFAULT_EXCHANGE
    },
    "gd_message": {
        "binding_key": "message.#",
        "exchange_type": CELERY_DEFAULT_EXCHANGE_TYPE,
        "exchange": CELERY_DEFAULT_EXCHANGE
    },
    "gd_auth": {
        "binding_key": "auth.#",
        "exchange_type": CELERY_DEFAULT_EXCHANGE_TYPE,
        "exchange": CELERY_DEFAULT_EXCHANGE
    },
    "test": {
        "binding_key": "test.#",
    },
}
#
# CELERY_ROUTES = {
#     'test.hello_test': {
#         'queue': 'musir',
#         'exchange': CELERY_DEFAULT_EXCHANGE,
#         'routing_key': 'test.hello_test',
#         'serializer': 'json',
#     },
# }

CELERYBEAT_SCHEDULE = {
    # "test1": {
    #     "task": "tasks.helloworld.task_test",
    #     "schedule": 3,
    #     "args": (),
    # },
    # "test2": {
    #     "task": "schedule_run_1",
    #     "schedule": 3,
    #     "args": (),
    # },
    "check_license_expire": {
            "task": "tasks.default.check_license_expire",
            "schedule": LICENSE_CHECK_DURATION,
            "args": (time.strftime('%Y-%m-%d',time.localtime(time.time())),),
    },
}
