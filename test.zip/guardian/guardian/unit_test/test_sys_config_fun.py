import unittest
from guardian.apps.sys_config.services import check_license_expire_task


class SysTestCase(unittest.TestCase):

    @staticmethod
    def test_check_license_expire_task(self):
        check_license_expire_task()

