# -*- coding: utf-8 -*-
'''
此脚本执行的情形：
    1、本地域下已经执行过 init_data.py脚本，完成了数据库的初始化及角色创建
    2、keystone已经完成设置，并重启服务

不能执行此脚本的情形：
    ×× 若没有设置过本地域，需要直接在LDAP域进行初始化，需要在keystone完成设置并重启服务后，执行 init_data.py 脚本

本脚本内容概述：
    1、创建LDAP域 (domain)，若存在，不创建
    2、创建租户 (project)，若存在，不创建
    3、创建LDAP域的超级管理员(在keystone和本地同时创建)，需要在 SUPER_ROOT_INFO 配置 LDAP的管理员的username
    4、给超级管理员的绑定 ROOT_ROLE_LIST 配置的 角色类型
'''


from guardian.settings import LOGIN_DEFAULT_DOMAIN_NAME
from guardian.settings import KEYSTONE_DEFAULT_ROLE_NAME
from guardian.settings import UCMP_ROLE_KIND_ROOT
from guardian.settings import CMDB_ROLE_KIND_ROOT
from guardian.settings import ATOMFLOW_ROLE_KIND_ROOT
from guardian.settings import GUARDIAN_ROLE_KIND_ROOT
from guardian.apps.users.models import UserRolesModel
from guardian.common.init_guardian.init_data import create_domain
from guardian.common.init_guardian.init_data import create_project
from guardian.common.init_guardian.init_data import create_user
from guardian.common.init_guardian.init_data import assign_role_to_superadmin


# 以下信息需要在执行前进行修改
SUPER_ROOT_INFO = {
    "project_name": "system_root",
    "username": "superadmin",  # ldap中管理员的username
    "password": "system_super_root",
    "email": "superadmin@company.com",
    "comments": "superadmin",
    "domain_name": LOGIN_DEFAULT_DOMAIN_NAME,
    "domain_comments": "ldap_domain",
    "keystone_default_role": KEYSTONE_DEFAULT_ROLE_NAME,
}
# 角色类型
ROOT_ROLE_LIST = [UCMP_ROLE_KIND_ROOT, CMDB_ROLE_KIND_ROOT, ATOMFLOW_ROLE_KIND_ROOT, GUARDIAN_ROLE_KIND_ROOT]


def main():
    domain_name = SUPER_ROOT_INFO.get("domain_name")
    domain_comments = SUPER_ROOT_INFO.get("domain_comments")
    domain_id = create_domain(domain_name, domain_comments)

    project_name = SUPER_ROOT_INFO.get("project_name")
    project_id = create_project(project_name, domain_id)

    keystone_role_name = SUPER_ROOT_INFO.get("keystone_default_role")
    # 若当前domain下已经存在该用户，只更新project_id
    super_admin_id = create_user(project_id, domain_id, keystone_role_name, **SUPER_ROOT_INFO)

    filters = {
        "project_id": project_id,
        "role_data_list": ROOT_ROLE_LIST
    }
    cnt, role_info = UserRolesModel().get_list(**filters)
    role_id_list = []
    for role in role_info:
        role_id_list.append(role.id)
    assign_role_to_superadmin(super_admin_id, role_id_list)


if __name__ == '__main__':
    main()
