from guardian import settings
from guardian.log4 import app_logger as LOG
import requests
from guardian.common.errors import KeystoneHandleException


def create_user(domain_id, user_name, passwd, enabled, project_id=None):
    req_data = {
        "user": {
            "default_project_id": "263fd9",
            "domain_id": "1789d1",
            "enabled": True,
            "name": "James Doe",
            "password": "secretsecret"
        }
    }

    req_data['user']['domain_id'] = domain_id
    req_data['user']['name'] = user_name
    req_data['user']['password'] = passwd
    req_data['user']['enabled'] = enabled

    if project_id is not None:
        req_data['user']['default_project_id'] = project_id
    else:
        req_data['user'].pop('default_project_id')
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
                          json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            return resp_json
    else:
        LOG.error('error create a new user, response: {0}'.format(_resp))
        raise KeystoneHandleException('error create user {0} with response status {1}'
                                      .format(user_name, _resp.status_code),
                                      _resp.status_code)


def update_user(domain_id, user_id, user_name=None, passwd=None, project_id=None, enable=True):
    req_data = {
        "user": {
            "default_project_id": "263fd9",
            "domain_id": "1789d1",
            "enabled": True,
            "name": "James Doe",
            "password": "secretsecret"
        }
    }
    req_data['user']['domain_id'] = domain_id

    if user_name is not None:
        req_data['user']['name'] = user_name
    else:
        del req_data['user']['name']

    if passwd is not None:
        req_data['user']['password'] = passwd
    else:
        del req_data['user']['password']

    req_data['user']['enabled'] = enable

    if project_id is not None:
        req_data['user']['default_project_id'] = project_id
    else:
        del req_data['user']['default_project_id']

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.patch(settings.KEYSTONE_BASE + '/v3/users/'+user_id, headers=myheaders,
                           json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            return resp_json
    else:
        LOG.error('error update user {0}, response: {1}'.format(user_id, _resp))
        raise KeystoneHandleException('error update user {0} with response status {1}'
                                      .format(user_id, _resp.status_code),
                                      _resp.status_code)


def set_default_project(user_id, project_id):
    req_data = {
        "user": {
            "default_project_id": "263fd9"
        }
    }

    if project_id is not None:
        req_data['user']['default_project_id'] = project_id
    else:
        req_data['user'].pop('default_project_id')

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.patch(settings.KEYSTONE_BASE + '/v3/users/' + user_id, headers=myheaders,
                           json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            return resp_json
    else:
        LOG.error('error set user project {0}, response: {1}'.format(user_id, _resp))
        raise KeystoneHandleException('error update user {0} with response status {1}'
                                .format(user_id, _resp.status_code),
                                _resp.status_code)

def list_user(domainid):
    req_data = {"domain_id": "domain_id"}
    req_data['domain_id'] = domainid

    LOG.debug('list_roles - domain_id: {0}'.format(domainid))

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
                         params=req_data, verify=False)

    if _resp.ok:
        LOG.debug('list_users -- response {0}'.format(_resp))
        resp_json = _resp.json()

        return resp_json

    else:
        LOG.error('error list users, response: {0}'.format(_resp.content))
        raise KeystoneHandleException('error list users for domain {0} with response status {1}'
                                .format(domainid, _resp.status_code), _resp.status_code)

def delete_user(user_id):
    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.delete(settings.KEYSTONE_BASE + '/v3/users/'+user_id,
                            headers=myheaders, verify=False)

    if _resp.status_code == 204:
        LOG.debug('delete users -- response {0}'.format(_resp))
        return _resp.status_code
    else:
        LOG.error('error list users, response: {0}'.format(_resp))
        raise KeystoneHandleException('error delete user {0} with response status {1}'
                                .format(user_id, _resp.status_code), _resp.status_code)


def query_user(domain_id, user_name):
    req_data = {"domain_id": "domain_id", "name":"name"}
    req_data['domain_id'] = domain_id
    req_data['name'] = user_name

    LOG.debug('query_user in domain: {0} with user_name: {1}'.format(domain_id, user_name))

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
                         params=req_data, verify=False)

    if _resp.ok:
        LOG.debug('query_user -- response {0}'.format(_resp))
        resp_json = _resp.json()
        return resp_json

    else:
        LOG.error('error query users, response: {0}'.format(_resp))
        raise KeystoneHandleException('error query users for domain {0}, user_name {1} with response status {2}'
                                .format(domain_id, user_name,  _resp.status_code), _resp.status_code)


def query_user_by_domain_id(domain_id):
    req_data = {"domain_id": "domain_id", "name":"name"}
    req_data['domain_id'] = domain_id

    LOG.debug('query_user_by_domain_id in domain: {0}'.format(domain_id))

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/users', headers=myheaders,
                         params=req_data, verify=False)

    if _resp.ok:
        LOG.debug('query_user_by_domain_id with response {0}'.format(_resp))
        resp_json = _resp.json()
        return resp_json
    else:
        LOG.error('error query users, response: {0}'.format(_resp))
        raise KeystoneHandleException('error query_user_by_domain_id: {0}, with response status {1}'
                                .format(domain_id, _resp.status_code), _resp.status_code)


def query_project_role_users(project_id, role_id):

    LOG.debug('query_project_role_users:project: {0} with role: {1}'.format(project_id, role_id))

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/role_assignments?scope.project.id='+project_id+'&role.id='+role_id, headers=myheaders, verify=False)

    if _resp.ok:
        LOG.debug('query_user -- response {0}'.format(_resp))
        resp_json = _resp.json()
        return resp_json

    else:
        LOG.error('error query_project_role_users, response: {0}'.format(_resp))
        raise KeystoneHandleException('error query_project_role_users domain: {0}, role {1} with response status {2}'
                                .format(project_id, role_id,  _resp.status_code), _resp.status_code)

def change_user_password(userid, new_pass, old_pass):
    req_data = {
        "user": {
            "password": "new_secretsecret",
            "original_password": "secretsecret"
        }
    }

    req_data['user']['password'] = new_pass
    req_data['user']['original_password'] = old_pass


    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/users/' + userid + '/password', headers=myheaders,
                          json=req_data, verify=False)

    if _resp.ok:
        return _resp.status_code
    else:
        LOG.error('error change a user password, response: {0}'.format(_resp))
        return _resp.status_code
