import unittest
import requests
from datetime import datetime
from time import time
from guardian.settings import APIBASEURL


class UsersTestCase(unittest.TestCase):
    def setUp(self):
        self.base_url = "http://127.0.0.1:8080{0}".format(APIBASEURL)
        self.data = None
        self.start_time = datetime.now()
        self.token = 'gAAAAABcrFmBc6Pdk5vEEyQ8PThCiT0K7hda58nPSRljtluiutZX1PAoFjEuYqtRcLnk1GMV_kir79T1KXnaks_MU_daoJQPC8mAyOxMc3GWVyQuh9hi1v0XC3rzL5U8TQtb9fwWrrTdHpxo5Rlndbyi8otSI83ld-U442R_D_V8qdzh-Q-TbLk'
        self.headers = {'X-Subject-Token': self.token}
        print("start unittest -----{0}".format(datetime.now()))

    def _test_validate_token(self):
        api_start_time = time()
        url = self.base_url + "/user/token"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_validate_token cost time: {0}".format(time() - api_start_time))

    def _test_list_domains(self):
        api_start_time = time()
        url = self.base_url + "/user/domain/list"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_domains cost time: {0}".format(time() - api_start_time))

    def _test_login_user(self):
        api_start_time = time()
        url = self.base_url + "/user/login"
        print("url is %s" % url)
        login_body = {
            "domain_id": "default",
            "username": "admin",
            "password": "123456"
        }
        data = requests.post(url, json=login_body, headers={'Content-Type': 'application/json'})
        print(data.status_code)
        print(data.json())
        print("test_login_user cost time: {0}".format(time() - api_start_time))

    def _test_logout_user(self):
        api_start_time = time()
        url = self.base_url + "/user/logout"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_logout_user cost time: {0}".format(time() - api_start_time))

    def _test_create_user(self):
        api_start_time = time()
        url = self.base_url + "/user/create"
        print("url is %s" % url)
        create_user_body = {"name": "zhangxiaodong", "realname": "zhangxiaodong789", "password": "123456",
                            "default_project_id": "0eb082df17d44c8abf46414d8a1397f8", "tel": "15691880739",
                            "phone": "15691880736", "email": "123456789@qq.com", "enabled": 1, "comments": "",
                            "domain_id": "default", "org_id": "5aa0028069314b469d69bd5b586dd0a9",
                            "org_array": ["ec6f498747c04f6c8e0fdbb1ef220595", "5aa0028069314b469d69bd5b586dd0a9"]}
        data = requests.post(url, headers=self.headers, json=create_user_body)
        print(data.status_code)
        print(data.json())
        print("test_create_user cost time: {0}".format(time() - api_start_time))

    def _test_update_user(self):
        api_start_time = time()
        url = self.base_url + "/user/update"
        print("url is %s" % url)
        update_user_body = {"id": "04e0826df5df4879b94be3a20583306d", "name": "taikang78910",
                            "realname": "chenxu.baia123", "password": "123456789",
                            "default_project_id": "0eb082df17d44c8abf46414d8a1397f8", "tel": "",
                            "phone": "", "email": "38365678@qq.com", "enabled": 0, "comments": "",
                            "domain_id": "default", "org_id": "ec6f498747c04f6c8e0fdbb1ef220595",
                            "org_array": ["ec6f498747c04f6c8e0fdbb1ef220595"]}
        data = requests.post(url, headers=self.headers, json=update_user_body)
        print(data.status_code)
        print(data.json())
        print("test_update_user cost time: {0}".format(time() - api_start_time))

    def _test_reset_user_passwd(self):
        api_start_time = time()
        url = self.base_url + "/user/passwd/reset"
        print("url is %s" % url)
        req_data = {
            "id": "c271ffefb4394f46ac21217854543a63",
            "domain_id": "default"
        }
        data = requests.post(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_reset_user_passwd cost time: {0}".format(time() - api_start_time))

    def _test_modify_user_passwd(self):
        api_start_time = time()
        url = self.base_url + "/user/passwd/modify"
        print("url is %s" % url)
        req_data = {
            "new_passwd": "12345678",
            "original_passwd": "123456"
        }
        data = requests.post(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_modify_user_passwd cost time: {0}".format(time() - api_start_time))

    def _test_delete_user(self):
        api_start_time = time()
        url = self.base_url + "/user/delete"
        print("url is %s" % url)
        data = requests.delete(url, params={"user_id": "89d7d0d6b0484ea6a0ce8857d052ed66"}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_delete_user cost time: {0}".format(time() - api_start_time))

    def _test_user_detail(self):
        api_start_time = time()
        url = self.base_url + "/user/detail"
        print("url is %s" % url)
        data = requests.get(url, params={"user_id": "87cb4da3919a47688d6a0669ea3d"}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_logout_user cost time: {0}".format(time() - api_start_time))

    def _test_sync_ad_users(self):
        api_start_time = time()
        url = self.base_url + "/user/sync"
        print("url is %s" % url)
        org_info = {
            "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
        }
        data = requests.post(url, headers=self.headers, json=org_info)
        print(data.status_code)
        print(data.json())
        print("sync_ad_users_api cost time: {0}".format(time() - api_start_time))

    def _test_create_role(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/create"
        print("url is %s" % url)
        role_info = {
            "name": "F5管理员",
            "role_model_menu": [{
                "module_id": "3f6943f6-60a1-4b66-be9e-7deef375bbeb",
                "sub_menu": ["a7a053ba-2473-49be-8e94-9826a24b484b"]
            }],
            "role_data": "ucmp_root",
            "role_ctl": {"F5": {"ip": ["192.168.1.1"]},
                         "ECS": {"vm": ["c2d3ec86-84b6-4b02-9e5e-df5c573976d3"]},
                         "Nas": {"app": ["e039ef58-9d9e-4a08-a7ae-5f9a6329ba8a"]}},
            "comments": "",
            "platform_name": "ucmp"
        }
        data = requests.post(url, headers=self.headers, json=role_info)
        print(data.status_code)
        print(data.json())
        print("test_create_role cost time: {0}".format(time() - api_start_time))

    def test_update_role(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/update"
        print("url is %s" % url)
        role_info = {"id": "a34f0cb5ff634949a087d319b987a507", "name": "租户管理员", "role_data": "cmdb_admin",
                     "role_ctl": {}, "platform_name": "cmdb", "project_id": "bcd42a4591f94e6cbf8e8033a6492203",
                     "comments": "system init role",
                     "role_model_menu": [{"module_id": "960a89cc-044f-4233-ad7e-50c14a290071", "sub_menu": []}]}
        data = requests.post(url, headers=self.headers, json=role_info)
        print(data.status_code)
        print(data.json())
        print("test_update_role cost time: {0}".format(time() - api_start_time))

    def _test_delete_role(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/delete"
        print("url is %s" % url)
        data = requests.delete(url, headers=self.headers, params={"role_id": "757b983966e6425e8d7348d9e550db19"})
        print(data.status_code)
        print(data.json())
        print("test_delete_role cost time: {0}".format(time() - api_start_time))

    def _test_assign_role(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/assign"
        print("url is %s" % url)
        data = {"user_id": "5b30c9038dd845eb95c2d55441ec2b55",
                "role_id": ["1278945210e1458290cdde9417e0d7d1"]}
        data = requests.post(url, headers=self.headers, json=data)
        print(data.status_code)
        print(data.json())
        print("test_assign_role cost time: {0}".format(time() - api_start_time))

    def _test_get_user_role(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/assigned"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers, params={"user_id": "87cb4da3919a47688d6a0669ea366fed"})
        print(data.status_code)
        print(data.json())
        print("test_get_user_role cost time: {0}".format(time() - api_start_time))

    def _test_get_role_detail(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/detail"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers, params={"role_id": "1278945210e1458290cdde9417e0d7d1"})
        print(data.status_code)
        print(data.json())
        print("test_get_role_detail cost time: {0}".format(time() - api_start_time))

    def _test_get_role_list(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/lists"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers, params={"project_id": "0eb082df17d44c8abf46414d8a1397f8"})
        print(data.status_code)
        print(data.json())
        print("test_get_role_list cost time: {0}".format(time() - api_start_time))

    def _test_get_role_kinds(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/kinds"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers, params={"platform": "system"})
        print(data.status_code)
        print(data.json())
        print("test_get_role_kinds cost time: {0}".format(time() - api_start_time))

    def _test_create_project(self):
        api_start_time = time()
        url = self.base_url + "/user/project/create"
        print("url is %s" % url)
        data = {
            "name": "test project",
            "description": "This is test project"
        }
        data = requests.post(url, headers=self.headers, json=data)
        print(data.status_code)
        print(data.json())
        print("test_create_project cost time: {0}".format(time() - api_start_time))

    def _test_update_project(self):
        api_start_time = time()
        url = self.base_url + "/user/project/update"
        print("url is %s" % url)
        data = {
            "project_id": "c5143669f6ac4db6b47c3f703ca2e82a",
            "name": "test project",
            "description": "This is demo project"
        }
        data = requests.post(url, headers=self.headers, json=data)
        print(data.status_code)
        print(data.json())
        print("test_update_project cost time: {0}".format(time() - api_start_time))

    def _test_list_project(self):
        api_start_time = time()
        url = self.base_url + "/user/project/lists"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_project cost time: {0}".format(time() - api_start_time))

    def _test_create_org(self):
        api_start_time = time()
        url = self.base_url + "/user/org/create"
        print("url is %s" % url)
        org_info = {
            "org_name": "test1",
            "parent_id": ""
        }
        data = requests.post(url, headers=self.headers, json=org_info)
        print(data.status_code)
        print(data.json())
        print("create_org_api cost time: {0}".format(time() - api_start_time))

    def _test_update_org(self):
        api_start_time = time()
        url = self.base_url + "/user/org/update"
        print("url is %s" % url)
        org_info = {
            "id": "1e98115062174d44b58865f7e8314f9f",
            "org_name": "新加712"
        }
        data = requests.post(url, headers=self.headers, json=org_info)
        print(data.status_code)
        print(data.json())
        print("create_org_api cost time: {0}".format(time() - api_start_time))

    def _test_delete_org(self):
        api_start_time = time()
        url = self.base_url + "/user/org/del"
        print("url is %s" % url)
        org_info = {
            "id": "1e98115062174d44b58865f7e8314f9f"
        }
        data = requests.delete(url, headers=self.headers, json=org_info)
        print(data.status_code)
        print(data.json())
        print("create_org_api cost time: {0}".format(time() - api_start_time))

    def _test_list_sub_org_id(self):
        api_start_time = time()
        url = self.base_url + "/user/sub_orgs"
        print("url is %s" % url)
        data = requests.get(url, params={"id": "1e98115062174d44b58865f7e8314f9f"}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_sub_org_id cost time: {0}".format(time() - api_start_time))

    def _test_list_parent_org_id(self):
        api_start_time = time()
        url = self.base_url + "/user/parent_orgs"
        print("url is %s" % url)
        data = requests.get(url, params={"id": "c534dbc6d2744420938c8b4e1753716c"}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_parent_org_id cost time: {0}".format(time() - api_start_time))

    def _test_get_org_code(self):
        api_start_time = time()
        url = self.base_url + "/user/org_code"
        print("url is %s" % url)
        data = requests.get(url, params={"user_id": "87cb4da3919a47688d6a0669ea366fed"}, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_org_code cost time: {0}".format(time() - api_start_time))

    def _test_list_orgs(self):
        api_start_time = time()
        url = self.base_url + "/user/orgs"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_orgs cost time: {0}".format(time() - api_start_time))

    def _test_get_org_trees(self):
        api_start_time = time()
        url = self.base_url + "/user/orgtree"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_org_trees cost time: {0}".format(time() - api_start_time))

    def _test_org_business_trees(self):
        api_start_time = time()
        url = self.base_url + "/user/org/business"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_org_business_trees cost time: {0}".format(time() - api_start_time))

    def _test_list_users(self):
        api_start_time = time()
        url = self.base_url + "/user/lists?name=lj"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_list_users cost time: {0}".format(time() - api_start_time))

    def _test_inside_list_users(self):
        api_start_time = time()
        url = self.base_url + "/user/inside/lists"
        print("url is %s" % url)
        user_ids = {'user_ids': ['87cb4da3919a47688d6a0669ea366fed', '89f71e87c85a45fdb9cb3c0f4a818073']}
        data = requests.post(url, json=user_ids)
        print(data.status_code)
        print(data.json())
        print("test_list_users cost time: {0}".format(time() - api_start_time))

    def _test_sync_ad_orgs(self):
        api_start_time = time()
        url = self.base_url + "/user/org/sync"
        print("url is %s" % url)
        org_info = {
            "base_dn": "OU=西安测试中心,DC=leaptocloud,DC=com"
        }
        data = requests.post(url, headers=self.headers, json=org_info)
        print(data.status_code)
        print(data.json())
        print("sync_ad_orgs_api cost time: {0}".format(time() - api_start_time))

    def _test_chk_org_by_name(self):
        api_start_time = time()
        url = self.base_url + "/user/orgname/check"
        print("url is %s" % url)
        params = {
            "org_name": "test11",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "parent_org_id": ""
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_chk_org_by_name cost time: {0}".format(time() - api_start_time))

    def _test_get_org_by_name_or_id(self):
        api_start_time = time()
        url = self.base_url + "/user/org/query"
        print("url is %s" % url)
        params = {
            "org_name": "",
            "org_id": "ec6f498747c04f6c8e0fdbb1ef220595",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8"
        }
        data = requests.get(url, headers=self.headers, params=params)
        print(data.status_code)
        print(data.json())
        print("test_get_org_by_name_or_id cost time: {0}".format(time() - api_start_time))

    def _test_get_users_by_username(self):
        api_start_time = time()
        url = self.base_url + "/user/check"
        params = {"username": "zhaoxiaobing"}
        print("url is %s" % url)
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_users_by_username cost time: {0}".format(time() - api_start_time))

    def _test_get_org_info(self):
        api_start_time = time()
        url = self.base_url + "/user/orgs/info?ids=42ea4f38d8774999b6bce443a78e3d6f,d481bf344fee4142aee933dd7e32b9d5"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_org_info cost time: {0}".format(time() - api_start_time))

    def _test_check_role_by_name(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/check?role_name=da"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_check_role_by_name cost time: {0}".format(time() - api_start_time))

    def _test_check_email_by_name(self):
        api_start_time = time()
        url = self.base_url + "/user/domain/check?email=383656225@qq.com"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_check_email_by_name cost time: {0}".format(time() - api_start_time))

    def _test_change_user_project(self):
        api_start_time = time()
        url = self.base_url + "/user/project/change?project_id=c5143669f6ac4db6b47c3f703ca2e82a"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.headers)
        print(data.json())
        print("test_change_user_project cost time: {0}".format(time() - api_start_time))

    def _test_role_id_to_user_info(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/listuser"
        print("url is %s" % url)
        params = {
            "role_id": "0b816a6cfa5a46d4a11d289969680625"
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("incre_auth_bulk_apps_orgs cost time: {0}".format(time() - api_start_time))

    def _test_get_administrator_users_by_role_id(self):
        api_start_time = time()
        url = self.base_url + "/user/list/administrator"
        print("url is %s" % url)
        params = {
            "role_id": "ad822b337d884cbb9b84f61a39aff904",
            "org_id": "5aa0028069314b469d69bd5b586dd0a9"
        }
        data = requests.post(url, json=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_administrator_users_by_role_id cost time: {0}".format(time() - api_start_time))

    def _test_get_dept_role_users(self):
        api_start_time = time()
        url = self.base_url + "/user/list/dept/admin"
        print("url is %s" % url)
        params = {
            "org_id": "5aa0028069314b469d69bd5b586dd0a9",
            "local_user": 1
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_dept_role_users cost time: {0}".format(time() - api_start_time))

    def _test_get_users_by_role_type(self):
        api_start_time = time()
        url = self.base_url + "/user/list/roles/admin"
        print("url is %s" % url)
        params = {
            "role_data": "ucmp_root"
        }
        data = requests.get(url, params=params, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_users_by_role_type cost time: {0}".format(time() - api_start_time))

    def _test_login_user_scope_project(self):
        api_start_time = time()
        url = self.base_url + "/user/login/scope_project"
        print("url is %s" % url)
        data = {
            "project_id": "c5143669f6ac4db6b47c3f703ca2e82a",
            "user_id": "87cb4da3919a47688d6a0669ea366fed",
            "password": "123456"
        }
        data = requests.post(url, json=data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print(data.headers)
        print("test_login_user_scope_project cost time: {0}".format(time() - api_start_time))

    def _test_get_user_allow_role_list(self):
        api_start_time = time()
        url = self.base_url + "/user/roles/allow/lists"
        print("url is %s" % url)
        data = {
            "project_id": "0eb082df17d44c8abf46414d8a1397f8"
        }
        data = requests.get(url, params=data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("_test_get_user_allow_role_list cost time: {0}".format(time() - api_start_time))


def tearDown(self):
    print("------------------data--------------")
    print(self.data)
    print("------------------data--------------")
    print("end unittest -----{0}".format(datetime.now()))
