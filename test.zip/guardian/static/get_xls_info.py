#coding=utf-8

"""
执行此脚本同步xml数据，需要填写的值为file_path, business_id,数据库相关的ip，端口号等
"""

import psycopg2
import time
import uuid
import xlrd


def get_info():
    file_path = r'/guardian/static/中国光大银行-系统配置信息表20181018-V1.3.xlsx'
    #获取数据
    data = xlrd.open_workbook(file_path)
    #获取sheet
    table = data.sheet_by_name('06-业务管理')
    #获取一列的数值，例如第3第4列
    col_values3 = table.col_values(3)  #key
    col_values4 = table.col_values(4)  #value
    # business_id = 'e1a737b1ab8f47b28df5b6f4c1e704f0'
    connent = psycopg2.connect(host='192.168.3.3', port=5432, user='guardian', password='123456', database='guardian')
    # print('---')
    cursor = connent.cursor()
    query_business_id = ("select id from business where create_at='admin';")
    cursor.execute(query_business_id)
    b_id = cursor.fetchone()
    if not b_id:
        print('获取bussiness_id 失败')
    business_id = b_id[0]
    print(business_id)
    for i in range(1,126):
        id = uuid.uuid4().hex
        now_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        sys_name = col_values3[i]
        code = col_values4[i]
        data = {
            "app_name": sys_name,
            "shorter_form": code,
            "id": id,
            "update_time": now_time,
            "business_id": business_id
        }

        try:
            save_ga_info = ("insert into business_app(app_name, shorter_form, id, business_id)values(%(app_name)s,%(shorter_form)s, %(id)s, %(business_id)s)")
            query_ga_info = ("select app_name,shorter_form from business_app;")
            cursor.execute(query_ga_info)
            res = cursor.fetchall()

            a = (data["app_name"],data["shorter_form"])

            if a not in res:
                cursor.execute(save_ga_info,data)
                connent.commit()
                print('ok____')
            else:
                print('数据已经存在')

        except Exception as e:
            print('保存数据失败！',e)

if __name__ == '__main__':
    get_info()
