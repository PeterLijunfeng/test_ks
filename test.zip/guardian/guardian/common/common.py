from guardian.common.errors import ParamsException
from guardian.log4 import app_logger as log


def check_param_is_null(param_dict):
    for param_name, param_value in param_dict.items():
        if param_value in [[], {}, '', (), None]:
            log.error("params %s is null", param_name)
            raise ParamsException("params {0} is null".format(param_name))
