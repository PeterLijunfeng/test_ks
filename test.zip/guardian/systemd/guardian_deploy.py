#!/usr/bin/python

import os
activate_this = '/opt/leaptocloud/guardianenv/bin/activate_this.py'
execfile(activate_this, dict(__file__=activate_this))
os.system("rm -f /opt/leaptocloud/gd_work/log/webserver-guardian-monitor.pid")
os.system("rm -f /opt/leaptocloud/gd_work/log/workers-guardian-workers.pid")
os.system("ps aux | grep workers | awk '{print $2}' | xargs kill -9")
os.system("ps aux | grep celery | awk '{print $2}' | xargs kill -9")
os.system("ps aux | grep guardianenv/bin/guardian | awk '{print $2}' | xargs kill -9")
os.system("ps aux | grep guardian-webserver | awk '{print $2}' | xargs kill -9")
os.chdir("/opt/leaptocloud/guardian_n/guardian/")
os.system("rm -rf /home/settings.py.bak")
os.system("cp /opt/leaptocloud/guardian_n/guardian/guardian/settings.py /home/settings.py.bak")
os.system("git reset --hard")
os.system("git pull")
os.system("cp -rf /home/settings.py.bak /opt/leaptocloud/guardian_n/guardian/guardian/settings.py")
os.system("guardian webserver -D")
os.system("guardian scheduler")
os.system("guardian workers")
os.system("guardian genapidoc")



