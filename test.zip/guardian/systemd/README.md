## 安装注册guardian服务

### 文件说明：
activate_this.py  用户切换虚拟环境。

guardian.service web服务的系统服务注册文件。

guardian_webserver.py web服务启动命令

guardian 为服务运行环境，可设置特殊的变量，暂时为空文件。


### 安装说明：

**以下文件需要chmod 到可执行权限**

1、将activate_this.py拷贝到 /opt/leaptocloud/cloudenv/bin  目录

2、将guardian_webserver.py 拷贝到 /opt/leaptocloud/cloudenv/bin 目录

3、将stop_webserver.sh 拷贝到 /opt/leaptocloud/cloudenv/bin 目录

4、将guardian.service 拷贝到/usr/lib/systemd/system 目录

5、将 guardian.conf 拷贝到 /etc/tmpfiles.d 目录

6、guardian 拷贝到 /etc/sysconfig 目录


### 启动服务：

systemctl start guardian


### 停止服务

systemctl stop guardian
