#-*- coding: utf-8 -*-

import os
import logging
from flask_caching import Cache

APPHOME = "/home/peter/works/guardian/guardian"
WORK_HOME = "/home/peter/works/yunshou/guardian/guardian"
APPDOC = "/home/peter/works/yunshou/guardian/doc"

API_DOC_PATH = "%s/API/" % APPDOC
API_DOC_NAME = "Api_docs_Guardian_v2"

APPHOMELOG = "%s/log" % WORK_HOME
FILE_UPLOAD_PATH = "%s/gd_file" % WORK_HOME
if not os.path.isdir(WORK_HOME):
    os.makedirs(WORK_HOME)

if not os.path.isdir(APPHOMELOG):
    os.makedirs(APPHOMELOG)

if not os.path.isdir(FILE_UPLOAD_PATH):
    os.makedirs(FILE_UPLOAD_PATH)

GUARDIAN_BASE = "http://192.168.3.127:9090"
APIBASEURL = "/gd/v2"

SECRET_KEY = "437GVjhT6U0KPhShAr9uQwXrJswPzAMqBapr1SPq"
# 重置默认登录密码
RESET_LOGIN_PASSWD = "123456"

POSTGRESQL_HOST_IP = '192.168.3.126'
POSTGRESQL_PORT = 5432
POSTGRESQL_DB_NAME = 'guardian_new'
POSTGRESQL_DB_USER = 'guardian'
POSTGRESQL_DB_PASSWORD = '123456'

SQL_ALCHEMY_POOL_ENABLED = True
# SQL_ALCHEMY_CONN = "mysql://root:Sa_1234567@192.168.3.126:3306/guardian_new"
SQL_ALCHEMY_CONN = "postgresql+psycopg2://%s:%s@%s:%s/%s" % \
                   (POSTGRESQL_DB_USER, POSTGRESQL_DB_PASSWORD,
                    POSTGRESQL_HOST_IP, POSTGRESQL_PORT, POSTGRESQL_DB_NAME)
SQL_ALCHEMY_POOL_SIZE = 5
SQL_ALCHEMY_POOL_RECYCLE = 1800
SQL_ALCHEMY_RECONNECT_TIMEOUT = 300


KEYSTONE_BASE = 'http://192.168.3.126:35357'
KEYSTONE_ADMIN_TOKEN = 'bb4eb0618420a94ed4d1'
KEYSTONE_ROOT_USER = 'root'
KEYSTONE_ROOT_PASS = 'cloud'
KEYSTONE_PORT = 22
KEYSTONE_CONF_HOME = "/etc/keystone/domains/keystone"

UCMP_BASE = 'http://192.168.3.127:8080'
TERRAFORM_BASE = 'http://192.168.3.126:8586'

ANSIBLE_HOST_IP = '192.168.3.174'
ANSIBLE_ROOT_USER = 'root'
ANSIBLE_ROOT_PASS = '123456'

# 过滤的LDAP属性
# LDAP_ATTRIBUTES_FILTERS = ["distinguishedName", "name", "objectGUID", "sAMAccountName", "userPrincipalName"]  # AD
LDAP_ATTRIBUTES_FILTERS = []  # LDAP
# 根据客户LDAP AD协议筛选同步获取的属性名称
# 例如：AD和LDAP中的邮箱配置不同
LDAP_ATTRIBUTES = {
            "dn": "entry_dn",  # AD：distinguishedName  LDAP：entry_dn
            "objectGUID": "uid",  # AD：objectGUID  LDAP：uid
            "realname": "cn",  # AD：name  LDAP：cn
            'username': "cn",  # AD：sAMAccountName  LDAP：cn
            'email': "mail"  # ad:userPrincipalName  LDAP:mail
}

LDAP_ORG_ATTRIBUTES = {
    "dn": "entry_dn",  # AD:distinguishedName  LDAP:entry_dn
    "objectGUID": "ou",  # AD:objectGUID  LDAP:ou
    "name": "ou"  # AD:name  LDAP:ou
}

# 需要同步LDAP的根组织机构名称
LDAP_TIMEOUT = 100
# LDAP单次获取条目数，不建议超过1000条
LDAP_PAGED_SIZE = 1000
OBJECTCLASS_ORG_LIST = ["organizationalUnit", "top"]
# LDAP_ORG_FILTER = '(&(objectclass=organizationalUnit)(objectclass=top))'  # AD
LDAP_ORG_FILTER = '(&(objectclass=organizationalUnit)(objectclass=top))'  # LDAP

OBJECTCLASS_USER_LIST = ['posixaccount', 'top']
# LDAP_USER_FILTER = '(&(!(objectclass=computer))(objectclass=user))'  #AD
LDAP_USER_FILTER = '(&(objectclass=posixAccount)(objectclass=top))'  # LDAP
# 同步用户一次操作数据库插入的用户数量(确保数据库的性能)
LDAP_SYNC_USER_COUNT = 100
# user_name_attribute=sAMAccountName 是AD属性，LDAP应该注释掉
LDAP_CONF_FILE = """[identity]
    driver = ldap
    [ldap]
    url = ldap://%s
    user = %s
    password = %s
    suffix = %s
    user_name_attribute=sAMAccountName
    query_scope=sub
    user_tree_dn = %s
    user_objectclass = organizationalPerson
    group_tree_dn = %s
    group_objectclass = groupOfNames
    user_attribute_ignore = enabled
    group_attribute_ignore = enabled
    user_allow_create = true
    user_allow_update = true
    user_allow_delete = true
    group_allow_create = true
    group_allow_update = true
    group_allow_delete = true"""


GUNICORN_WORKER_COUNT = 4
WORKER_REFRESH_INTERVAL = 30
GUNICORN_WORKER_TIMEOUT = 120
WORKER_REFRESH_BATCH_SIZE = 1
GUNICORN_WORKER_CLASS = "sync"

ACCESS_LOGFILE = "%s/webserver-access.log" % APPHOMELOG
ERROR_LOGFILE = "%s/webserver-error.log" % APPHOMELOG

CELERY_WORKER_LOGFILE = "%s/celery.log" % APPHOMELOG
SCHEDULER_LOGFILE = "%s/scheduler.log" % APPHOMELOG

WEB_SERVER_SSL_CERT = ""
WEB_SERVER_SSL_KEY = ""
WEB_SERVER_PORT = 7000
WEB_SERVER_HOST = '0.0.0.0'

LOGGING_LEVEL = logging.INFO

# the prefix to append to gunicorn worker processes after init
GUNICORN_WORKER_READY_PREFIX = "[ready] "

LOG_FORMAT = "[%%(asctime)s] {{%%(filename)s:%%(lineno)d}} %%(levelname)s - %%(message)s"
SIMPLE_LOG_FORMAT = "%%(asctime)s %%(levelname)s - %%(message)s"

DEBUG_LOG_PATH = "%s/guardian_debug.log" % APPHOMELOG
ERROR_LOG_PATH = "%s/guardian_error.log" % APPHOMELOG
CELERY_LOG_PATH = "%s/celery.log" % APPHOMELOG

MQ_TYPE = 'amqp'
MQ_HOST = '192.168.3.126'
MQ_PORT = 5672
MQ_USER = 'guardian'
MQ_PASSWD = '123456'
MQ_V_HOST = 'guardian_vh'

REDIS_HOST = '192.168.3.127'
REDIS_PORT = 6379
REDIS_PASSWD = '123456'
REDIS_DB = 1


FLASK_CACHE_CONF = {
    "CACHE_TYPE": "redis",
    "CACHE_KEY_PREFIX": "gd_",
    # "CACHE_REDIS_URL": "redis://user:password@localhost:6379/2",
    "CACHE_REDIS_HOST": REDIS_HOST,
    "CACHE_REDIS_PORT": REDIS_PORT,
    "CACHE_REDIS_DB": 2,
    "CACHE_REDIS_PASSWORD": REDIS_PASSWD
}
cache = Cache(config=FLASK_CACHE_CONF)

LOGIN_DEFAULT_DOMAIN_NAME = 'Default'

# role kind 用于决定数据范围
# UCMP PLATFORM
PLATFORM_UCMP = "ucmp"
# CMDB PLATFORM
PLATFORM_CMDB = "cmdb"
# ATOMFLOW PLATFORM
PLATFORM_ATOMFLOW = "atomflow"
# APPCENTER PLATFORM
PLATFORM_APPCEMTER = "appcenter"
# GUARDIAN PLATFORM
PLATFORM_GUARDIAN = "system"
# 角色对应名称
ROOT_ADMIN = "超级管理员"
PROJECT_ADMIN = "租户管理员"
DEPT_ADMIN = "部门管理员"
USER = "普通用户"
APP_ADMIN = "应用管理员"
BUSINESS_ADMIN = "业务管理员"

# root 拥有IT运营中枢的所有数据范围权限
UCMP_ROLE_KIND_ROOT = "%s_root" % PLATFORM_UCMP
# ucmp_admin 拥有特定租户下的数据范围权限
UCMP_ROLE_KIND_ADMIN = "%s_admin" % PLATFORM_UCMP
# ucmp_dept 拥有特定组织机构下的数据范围权限
UCMP_ROLE_KIND_DEPT = "%s_dept" % PLATFORM_UCMP
# ucmp_user 只能查看自己创建的数据
UCMP_ROLE_KIND_USER = "%s_user" % PLATFORM_UCMP
# ucmp_user 只能查看所属应用的数据
UCMP_ROLE_KIND_APP = "%s_app" % PLATFORM_UCMP
# ucmp_user 只能查看所属业务的数据
UCMP_ROLE_KIND_BUSINESS = "%s_business" % PLATFORM_UCMP
# 角色对应中文名称
UCMP_ROLE_KIND_CHOICES = {
    UCMP_ROLE_KIND_ROOT: ROOT_ADMIN,
    UCMP_ROLE_KIND_ADMIN: PROJECT_ADMIN,
    UCMP_ROLE_KIND_DEPT: DEPT_ADMIN,
    UCMP_ROLE_KIND_USER: USER,
    # UCMP_ROLE_KIND_APP: APP_ADMIN,  # 应用管理员
    # UCMP_ROLE_KIND_BUSINESS: BUSINESS_ADMIN  # 业务管理员
}

# root 拥有IT运营中枢的所有数据范围权限
CMDB_ROLE_KIND_ROOT = "%s_root" % PLATFORM_CMDB
# ucmp_admin 拥有特定租户下的数据范围权限
CMDB_ROLE_KIND_ADMIN = "%s_admin" % PLATFORM_CMDB
# ucmp_user 只能查看自己创建的数据
CMDB_ROLE_KIND_USER = "%s_user" % PLATFORM_CMDB
# 角色对应中文名称
CMDB_ROLE_KIND_CHOICES = {
    CMDB_ROLE_KIND_ROOT: ROOT_ADMIN,
    CMDB_ROLE_KIND_ADMIN: PROJECT_ADMIN,
    CMDB_ROLE_KIND_USER:USER
}

# root 拥有IT运营中枢的所有数据范围权限
ATOMFLOW_ROLE_KIND_ROOT = "%s_root" % PLATFORM_ATOMFLOW
# ucmp_admin 拥有特定租户下的数据范围权限
ATOMFLOW_ROLE_KIND_ADMIN = "%s_admin" % PLATFORM_ATOMFLOW
# ucmp_user 只能查看自己创建的数据
ATOMFLOW_ROLE_KIND_USER = "%s_user" % PLATFORM_ATOMFLOW
# 角色对应中文名称
ATOMFLOW_ROLE_KIND_CHOICES = {
    ATOMFLOW_ROLE_KIND_ROOT: ROOT_ADMIN,
    ATOMFLOW_ROLE_KIND_ADMIN: PROJECT_ADMIN,
    ATOMFLOW_ROLE_KIND_USER: USER
}

# root 拥有IT运营中枢的所有数据范围权限
GUARDIAN_ROLE_KIND_ROOT = "%s_root" % PLATFORM_GUARDIAN
# ucmp_admin 拥有特定租户下的数据范围权限
GUARDIAN_ROLE_KIND_ADMIN = "%s_admin" % PLATFORM_GUARDIAN
# ucmp_user 只能查看自己创建的数据
GUARDIAN_ROLE_KIND_USER = "%s_user" % PLATFORM_GUARDIAN
# 角色对应中文名称
GUARDIAN_ROLE_KIND_CHOICES = {
    GUARDIAN_ROLE_KIND_ROOT: ROOT_ADMIN,
    GUARDIAN_ROLE_KIND_ADMIN: PROJECT_ADMIN,
    GUARDIAN_ROLE_KIND_USER: USER
}

INIT_ADMIN_NAME = "superadmin"

# 隐藏的root管理员，用户名：INIT_ROOT_NAME
#                 密码：system_super_root
INIT_ROOT_NAME = "system_super_root"

# 初始化角色id
INIT_ROLE_ID = {
    PLATFORM_UCMP: {ROOT_ADMIN: "757b983966e6425e8d7348d9e550db19",
                    PROJECT_ADMIN: "fc37e6af5a284b01b67be6b4593f0fdf",
                    DEPT_ADMIN: "ad822b337d884cbb9b84f61a39aff904",
                    USER: "f4f1d588bf814e3a9784faff5f6231bf",
                    # APP_ADMIN: "4beaa187f98e4e2790661d698704dfcf",
                    # BUSINESS_ADMIN: "74411b31dd2d48b499ca02ddaebebd78"
                    },
    PLATFORM_CMDB: {ROOT_ADMIN: "eac811cdaa2c4e6ba7b4d51c71ee90cc",
                    PROJECT_ADMIN:"a34f0cb5ff634949a087d319b987a507",
                    USER: "2f43b30022e54cce8930e54d62518ecd"},
    PLATFORM_ATOMFLOW: {ROOT_ADMIN: "12a162a1ab044fee9f9d4bcedac43674",
                        PROJECT_ADMIN: "46aa4762b3034f11bec2360e1d087089",
                        USER: "58a76c23d21e458795e85110fb314401"},
    PLATFORM_GUARDIAN: {ROOT_ADMIN: "c496e694e86842d09aabff008956b518",
                        PROJECT_ADMIN: "b706485f793c48d69ef6a86f3f7b73dd",
                        USER: "4302829f7d154856865d84403e13cfe2"}
}
ROLE_START = "role_"

STATIC_PATH = "/gd_static/"

# 测试邮件 主题
EMAIL_SUBJECT = "Leaptocloud Test Mail"
# 测试邮件 内容
EMAIL_CONTENT = "This is a test mail, don't Reply !"

# token最大过期时间
TOKEN_MAX_TIME = 3600

# keystone默认角色名称
KEYSTONE_DEFAULT_ROLE_NAME = 'default'

MSM_TIPS = "【中国移动】"
MSM_TIPS_POSITION = "top"

# license过期检测时间间隔(秒)或者定时crontab(hour=7, minute=30, day_of_week=1)每周一7:30
LICENSE_CHECK_DURATION = 3600
