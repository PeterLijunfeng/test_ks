import unittest
import requests
from datetime import datetime
from time import time
from guardian.settings import APIBASEURL


class MessageTestCase(unittest.TestCase):
    def setUp(self):
        self.base_url = "http://127.0.0.1:7000{0}".format(APIBASEURL)
        self.data = None
        self.token = 'gAAAAABcla70fKi3fUUeBNR6eU5kAVknJ9_i6olf1iEcIIAHKCPcKjPmYxF9MJROz7WZWI1fPctBLMHzmb0laxddkFLN-uW0oie6X99kB3Dyg_vqzF99pIF9ueNJ94AwNnSkEs4YYINvnldIO6_WMWsS1BxGQvZoW-hKE3L4K_5a6cGrS8S3hyU'
        self.headers = {'X-Subject-Token': self.token}
        # self.headers = {'content-type': 'application/json', 'X-Auth-Token': 'bb4eb0618420a94ed4d1'}
        self.start_time = datetime.now()

        print("start unittest -----{0}".format(datetime.now()))

    def _test_create_update_msgs_strategy(self):
        api_start_time = time()
        url = self.base_url + "/msgs/strategy"
        print("url is %s" % url)

        request_data = [
            {
                "id": "5f3fd598c75b4952ad85a94bf8841a90",
                "strategy_app_id": "ucmp/iaas_apply/success",  # for Java & Go
                "strategy_app_name": "服务申请/成功",
                "project_id": "0eb082df17d44c8abf46414d8a1397f8",
                "title": "test1",
                "strategy_period_type": 1,
                "strategy_period_type_name": "单次",
                "accept_role_list": ["applicant", "admin"],
                "accept_user_list": ["user_id_uuid_1", "user_id_uuid_2"],
                "send_ahead_date": 0,
                "support_message_types": ["短信", "邮件"],
                "select_template_ids": [],
                "select_strategy_app_id": "9d371c1b076d46b5b1c91fc07cfc59e6"  # uuid for Web
            }
        ]
        data = requests.post(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("create_update_msgs_strategy_api cost time: {0}".format(time() - api_start_time))

    def _test_enable_disable_msgs_strategy(self):
        api_start_time = time()
        url = self.base_url + "/msgs/strategy/enable"
        print("url is %s" % url)
        request_data = {
            "id": "5f3fd598c75b4952ad85a94bf8841a90",
            "is_on": 1
        }
        data = requests.post(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("enable_disable_msgs_strategy_api cost time: {0}".format(time() - api_start_time))

    def _test_del_msgs_strategy(self):
        api_start_time = time()
        url = self.base_url + "/msgs/strategy/del"
        print("url is %s" % url)
        request_data = {
            "id": "5f3fd598c75b4952ad85a94bf8841a90",
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("del_msgs_strategy_api cost time: {0}".format(time() - api_start_time))

    def test_get_msgs_strategy(self):
        api_start_time = time()
        url = self.base_url + "/msgs/strategy/list"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("list_strategy_api cost time: {0}".format(time() - api_start_time))

    def _test_send_strategy_message(self):
        api_start_time = time()
        url = self.base_url + "/msgs/send"
        print("url is %s" % url)
        request_data = {
            "to_user": [
                "87cb4da3919a47688d6a0669ea366fed"
            ],
            "strategy_id": "ddc6f578553d4f64a53640ad5f5aeb55",
            "force": 1,
            "message_type_id": 0,
            "notice_type_id": 1,
            "level": 1,
            "variable": [
                {"key": "username", "value": "用户名"},
                {"key": "machine_name", "value": "name"},
                {"key": "cpu", "value": "CPU"},
                {"key": "memory", "value": "10%"}
            ]
        }
        data = requests.post(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_send_strategy_message cost time: {0}".format(time() - api_start_time))

    def _test_get_strategy_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/strategy/conf"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_strategy_conf cost time: {0}".format(time() - api_start_time))

    def _test_update_template(self):
        api_start_time = time()
        url = self.base_url + "/msgs/template/update"
        print("url is %s" % url)
        request_data = {
            "strategy_app_id": "statis/idle",
            "template_list": [
                {
                    "id": "cdfefd9dd-0d75-g2b7-8abf-2df788839c",
                    "title": "模板1",
                    "content": "用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, "
                               "内存使用率为{%memory%}, 网络流入{%network_in%}, "
                               "网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
                },
                {
                    "id": "fd9dd-0d75-g2b7-8abf-2efeofefe",
                    "title": "模板",
                    "content": "用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, "
                               "内存使用率为{%memory%}, 网络流入{%network_in%}, "
                               "网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
                },
                {
                    "id": "cdfefd9dd-0d75-g2b7-826839c-fewa",
                    "title": "模板2",
                    "content": "用户{%username%}, 目前云主机{%machine_name%}cpu使用率为{%cpu%}, "
                               "内存使用率为{%memory%}, 网络流入{%network_in%}, "
                               "网络流出{%network-out%}, 建议释放资源，如有问题请联系负责人"
                }
            ]
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("update_template_api cost time: {0}".format(time() - api_start_time))

    def _test_list_template(self):
        api_start_time = time()
        url = self.base_url + "/msgs/template/list"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("list_template_api cost time: {0}".format(time() - api_start_time))

    def _test_create_notice(self):
        api_start_time = time()
        url = self.base_url + "/msgs/notice"
        print("url is %s" % url)
        request_data = {
            "notice_type": "notice",
            "notice_type_name": "通知",
            "title": "test_1",
            "content": "123456"
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("update_template_api cost time: {0}".format(time() - api_start_time))

    def _test_list_notice(self):
        api_start_time = time()
        url = self.base_url + "/msgs/notice"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("list_notice_api cost time: {0}".format(time() - api_start_time))

    def _test_list_notice_not_read(self):
        api_start_time = time()
        url = self.base_url + "/msgs/notice/notread"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("list_notice_not_read_api cost time: {0}".format(time() - api_start_time))

    def _test_mark_notice_read(self):
        api_start_time = time()
        url = self.base_url + "/msgs/notice/read"
        print("url is %s" % url)
        request_data = {
            "notice_ids": ["4d8e690aae984a7aa567acbaee13d785"]
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("mark_notice_read_api cost time: {0}".format(time() - api_start_time))

    def _test_del_notice_status(self):
        api_start_time = time()
        url = self.base_url + "/msgs/notice/del"
        print("url is %s" % url)
        request_data = {
            "notice_ids": ["4d8e690aae984a7aa567acbaee13d785"]
        }
        data = requests.delete(url, json=request_data)
        print(data.status_code)
        print("del_notice_status_api cost time: {0}".format(time() - api_start_time))

    def _test_create_update_sms_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/sms_conf"
        print("url is %s" % url)
        request_data = {
            "id": "0eb082df17d44c8abf46414d8a1397f8",
            "server_addr": "123",
            "server_port": 22,
            "account_id": "12345",
            "account_token": "123",
            "test_phone": "18629876785",
            "extra_params": [
                {
                    "key": "test",
                    "value": "test"
                }
            ]
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("create_update_sms_conf_api cost time: {0}".format(time() - api_start_time))

    def _test_get_sms_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/sms_conf"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("get_sms_conf_api cost time: {0}".format(time() - api_start_time))

    def _test_create_update_email_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/email/conf"
        print("url is %s" % url)
        request_data = {
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "server_addr": "smtp.mxhichina.com",
            "server_port": 465,
            "is_tls": 1,
            "user_name": "云管测试",
            "user_pass": "×××××××",
            "from_user_addr": "junfeng.li@leaptocloud.com",
            "test_to_user_addr": "junfeng.li@leaptocloud.com"
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("create_update_email_conf_api cost time: {0}".format(time() - api_start_time))

    def _test_get_email_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/email"
        print("url is %s" % url)
        request_data = {}
        data = requests.get(url, json=request_data)
        print(data.status_code)
        print(data.json())
        print("get_email_conf_api cost time: {0}".format(time() - api_start_time))

    def _test_test_email_conf(self):
        api_start_time = time()
        url = self.base_url + "/msgs/email/test"
        print("url is %s" % url)
        request_data = {
            "id": "9d8b6b03cd864e7fb613f3ea198373a7",
            "project_id": "0eb082df17d44c8abf46414d8a1397f8",
            "server_addr": "smtp.mxhichina.com",
            "server_port": 465,
            "is_tls": 1,
            "user_name": "云管测试",
            "user_pass": "chichu261,",
            "from_user_addr": "junfeng.li@leaptocloud.com",
            "test_to_user_addr": "junfeng.li@leaptocloud.com"
        }
        data = requests.post(url, json=request_data, headers=self.headers)
        print(data.status_code)
        print(data.text)
        print("test_email_conf_api cost time: {0}".format(time() - api_start_time))

    def _test_send_email(self):
        api_start_time = time()
        url = self.base_url + "/msgs/email/send"
        print("url is %s" % url)
        request_data = {
            "to_user_addrs": ["junfeng.li@leaptocloud.com"],
            "sub": "Title",
            "content": "mail content."
        }
        data = requests.post(url, json=request_data)
        print(data.status_code)
        print("send_email_api cost time: {0}".format(time() - api_start_time))


def tearDown(self):
    print("------------------data--------------")
    print(self.data)
    print("------------------data--------------")
    print("end unittest -----{0}".format(datetime.now()))
