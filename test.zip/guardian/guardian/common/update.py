import psycopg2
import pymysql

from guardian import settings
from guardian.apps.business.services import gen_segmentation_words
from guardian.apps.business.models import BusinessAppsModel, BusinessAppOrgModel, BusinessModel
from guardian.apps.messages.models import MsgStrategyModel, MsgTemplateModel, SmsConfigModel, MessagesModel, \
    InnerNoticeStatusModel, InnerNoticeModel, EmailConfigModel
from guardian.apps.users.models import UsersModel, UserRoleRelationShip, UsersOrgsModel
from guardian.apps.sys_config.models import SysModuleModel, SysMenuModel, LicenseModel, LdapConfigModel, \
    SysInfoConfModel
from guardian.apps.device_agents.models import DeviceAgentModel
from guardian.log4 import app_logger as log
from guardian.settings import PLATFORM_ATOMFLOW, PLATFORM_CMDB

"""
升级脚本注意事项：
1.需要填写PROJECT_ID
2.需要创建新库，settings.py中
    POSTGRESQL_HOST_IP = '需要填写地址'
    POSTGRESQL_PORT = 5432
    POSTGRESQL_DB_NAME = 'guardian_new'
    POSTGRESQL_DB_USER = 'guardian'
    POSTGRESQL_DB_PASSWORD = '123456'
"""


PROJECT_ID = "25e03f8e67624f6ab5d271b51fb31edb"

CONNECT_CONFIG = {
    "database": "guardian",
    "user": "guardian",
    "password": "123456",
    "host": "192.168.3.124",
    "port": "5432",
}

NEW_CONNECT_CONFIG = {
    "database": "guardian_new_1",
    "user": "guardian",
    "password": "123456",
    "host": "192.168.3.124",
    "port": "5432",
}


KEY_STONE_DB = {
    'host': '192.168.3.126',
    'user': 'root',
    'password': 'Sa_1234567',
    'db': 'keystone',
    'charset': 'utf8',
    'port': 3306,
}

NOTICE_TYPE = {
    "INFO": 1,
    "NOTICE": 2,
    "ALARM": 3,
    "MAINTENANCE": 4
}

NOTICE_TYPE_CN = {
    "INFO": "提示",
    "NOTICE": "通知",
    "ALARM": "故障告警",
    "MAINTENANCE": "产品升级维护"
}


# 迁移apps 至 sys_module
def apps_to_sys_module():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, appname, app_url, sortby, remote_url from apps")
    rows = cur.fetchall()
    sys_module_content = []

    for module_id, module_name, module_url, sortby, remote_url in rows:
        data = {}
        data["id"] = module_id
        data["module_name"] = module_name
        data["module_url"] = module_url
        data["sortby"] = sortby
        data["remote_url"] = remote_url
        sys_module_content.append(data)

    SysModuleModel.add_module_batch(sys_module_content)

    # print("sys_module_content ==", sys_module_content)
    # log.info("迁移apps 至 sys_module", sys_module_content[0], len(sys_module_content))
    conn.close()


# 迁移operation_conf 至sys_info_conf
def operation_conf_to_sys_info_conf():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, sys_logo, sys_name, version_number, copyright, surport_mail, surport_tel, log_delete_time,"
                "create_time, update_time, session_time from operation_conf")
    rows = cur.fetchall()
    sys_content = []

    for sys_id, sys_logo, sys_name, version, copyright, surport_mail, \
        surport_tel, log_delete_time, create_at, update_at, session_expire in rows:
        data = {}
        data["id"] = sys_id
        data["sys_logo"] = sys_logo
        data["sys_name"] = sys_name
        data["version"] = version
        data["copyright"] = copyright
        data["surport_mail"] = surport_mail
        data["surport_tel"] = surport_tel
        data["log_delete_time"] = log_delete_time
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["session_expire"] = session_expire
        sys_content.append(data)

    SysInfoConfModel.add_sys_info_batch(sys_content)

    # print("sys_menu_content ==", sys_menu_content)
    # log.info("迁移 menu 至 sys_menu", sys_menu_content[0], len(sys_menu_content))

    conn.close()


def select_users_org_max_node_id():
    conn = psycopg2.connect(**NEW_CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT node_id from users_orgs "
    cur.execute(sql_str)
    rows = cur.fetchall()
    num_list = []
    for num in rows:
        if len(num) > 0:
            num_list.append(num[0])
        else:
            num_list = [0]

    max_node_id = max(num_list)
    max_node_id += 1
    return max_node_id


# 迁移 org 至 users_orgs
def org_to_users_orgs():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT id, org_name, parent_id, project_id, domain, objectguid, mgr_user_id, dn, " \
               "create_time, update_time from org " \
               "WHERE project_id='%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    org_content = []

    for org_id, org_name, parent_id, project_id, domain_id, object_uid, mgr_user_id, dn, create_at, update_at in rows:
        data = {}
        data["id"] = org_id
        data["org_name"] = org_name
        data["parent_id"] = parent_id
        data["project_id"] = project_id
        data["domain_id"] = domain_id
        data["object_uid"] = object_uid
        data["mgr_user_id"] = mgr_user_id
        data["dn"] = dn
        data["create_at"] = create_at
        data["update_at"] = update_at
        org_content.append(data)

    node_code = select_users_org_max_node_id()
    org_info_list = []
    for org_info in org_content:
        if not org_info["parent_id"]:
            org_info['node_id'] = int(node_code)
            org_info['parent_code'] = ""
            org_info_list.append(org_info)
        node_code += 1
    UsersOrgsModel.add_org_batch(org_info_list)

    org_info_list_1 = []
    for org_info in org_content:
        if not org_info.get('node_id'):
            org_id = org_info["parent_id"]
            data = select_users_org_by_data(PROJECT_ID, org_id)
            if not data.get('parent_id'):
                org_info['node_id'] = node_code
                org_info['parent_code'] = data.get('node_id')

                if org_info.get('parent_code'):
                    org_info_list_1.append(org_info)
        node_code += 1
    UsersOrgsModel.add_org_batch(org_info_list_1)

    org_info_list_2 = []
    for org_info in org_content:
        if not org_info.get('parent_code'):
            org_id = org_info["parent_id"]

            data = select_users_org_by_data(PROJECT_ID, org_id)
            if data.get('parent_id'):
                if data.get('node_id'):
                    if not data.get('parent_id'):
                        org_info['node_id'] = node_code
                        org_info['parent_code'] = data.get('node_id')
                        # org_info_list_2.append(org_info)
                    else:
                        data1 = select_users_org_by_data(PROJECT_ID, data["parent_id"])
                        org_info['node_id'] = node_code
                        org_info['parent_code'] = str(data1.get('node_id')) + '-' + str(data.get('node_id'))
            org_info_list_2.append(org_info)

        node_code += 1
    # print(org_info_list_2)
    org_info_data = []
    for org_data_info in org_info_list_2:
        if org_data_info['parent_code']:
            org_info_data.append(org_data_info)
    print(org_info_data)
    UsersOrgsModel.add_org_batch(org_info_data)

    conn.close()


def select_users_org_by_data(project_id, org_id):
    conn = psycopg2.connect(**NEW_CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT id, project_id, node_id, parent_id from users_orgs " \
              "WHERE project_id='%s' and id='%s'" % (project_id, org_id)
    cur.execute(sql_str)
    rows = cur.fetchall()
    data = {}
    for org_id, project_id, node_id, parent_id in rows:

        data["id"] = org_id
        data["project_id"] = project_id
        data["node_id"] = node_id
        data["parent_id"] = parent_id

    return data


# 迁移 menu 至 sys_menu
def menu_to_sts_menu():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, title, parent_id, url, app_id, icon, sortby from menu")
    rows = cur.fetchall()
    sys_menu_content = []

    for menu_id, title, parent_id, url, sys_module_id, icon, sortby in rows:
        data = {}
        data["id"] = menu_id
        data["title"] = title
        data["parent_id"] = parent_id
        data["url"] = url
        data["sys_module_id"] = sys_module_id
        data["icon"] = icon
        data["sortby"] = sortby
        data["project_id"] = PROJECT_ID
        sys_menu_content.append(data)

    SysMenuModel.add_menu_batch(sys_menu_content)

    # print("sys_menu_content ==", sys_menu_content)
    # log.info("迁移 menu 至 sys_menu", sys_menu_content[0], len(sys_menu_content))

    conn.close()


# 迁移 users 至 users
def users_to_users():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT user_id, username, realname, email, tel, phone, first_login, org_id, org_array, comments, " \
              "create_time, update_time, domain_id, objectguid, dn, enable, project_id from users " \
              "where domain_id='default' and project_id = '%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    user_content = []

    for user_id, username, realname, email, tel, phone, first_login, org_id, org_array, comment, \
        create_at, update_at, domain_id, object_suid, dn, enable, default_project_id in rows:
        data = {}
        data["user_id"] = user_id
        data["username"] = username
        data["realname"] = realname
        data["email"] = email
        data["tel"] = tel
        data["phone"] = phone
        data["first_login"] = first_login
        data["org_id"] = org_id
        data["comment"] = comment
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["object_suid"] = object_suid
        data["domain_id"] = domain_id
        data["dn"] = dn
        data["default_project_id"] = default_project_id
        data["org_array"] = org_array
        data["lower_username"] = username.lower()
        if enable:
            enable_code = 1
        else:
            enable_code = 0
        data["enable"] = enable_code

        user_content.append(data)

    UsersModel.create_user_batch_update(user_content)

    # print("sys_menu_content ==", user_content)
    # log.info("迁移 users 至 users", user_content[0], len(user_content))

    conn.close()


def license_to_sys_license():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, app_id, license_data, license_info, status, create_time from license")
    rows = cur.fetchall()
    license_content = []

    for license_id, sys_module_id, license_data, license_info, status, create_at in rows:
        data = {}
        data["id"] = license_id
        data["sys_module_id"] = sys_module_id
        data["license_data"] = license_data
        data["license_info"] = license_info
        data["status"] = status
        data["create_at"] = create_at
        data["project_id"] = PROJECT_ID

        license_content.append(data)

    LicenseModel.add_license_batch(license_content)

    # print("license_content ==", license_content)
    # log.info("迁移 license 至 sys_license", license_content[0], len(license_content))

    conn.close()


def strategy_to_msg_strategy():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT id, app_id, title, send_delay_date, create_time, modify_time, " \
              "role_list, user_list, is_delete, is_on, project_id from strategy " \
              "where project_id = '%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    strategy_content = []

    for strategy_id, strategy_app_id, title, send_ahead_date, create_at, update_at, accept_role_list, \
            accept_user_list, is_del, is_on, project_id in rows:
        data = {}
        data["id"] = strategy_id
        data["strategy_app_id"] = strategy_app_id
        data["title"] = title
        data["send_ahead_date"] = send_ahead_date
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["accept_role_list"] = accept_role_list
        data["accept_user_list"] = accept_user_list
        data["is_del"] = 1 if is_del else 0
        data["is_on"] = 1 if is_on else 0
        data["project_id"] = PROJECT_ID

        strategy_content.append(data)

    MsgStrategyModel.add_update_strategy_batch(strategy_content)

    # print("strategy_content ==", strategy_content)
    # log.info("迁移 strategy 至 sys_strategy", strategy_content[0], len(strategy_content))
    conn.close()


def template_to_msg_template():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT id, app_id, title, content, type, last_modify_time, variable, project_id from template " \
              "where project_id = '%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    template_content = []

    for template_id, strategy_app_id, title, content, type_id, update_at, variable, project_id in rows:
        data = {}
        data["id"] = template_id
        data["strategy_app_id"] = strategy_app_id
        data["title"] = title
        data["content"] = content
        data["type_id"] = type_id
        data["update_at"] = update_at
        data["variable"] = variable
        data["project_id"] = PROJECT_ID

        template_content.append(data)

    MsgTemplateModel.add_template_batch(template_content)

    # print("template_content ==", template_content)
    # log.info("迁移 template 至 sys_template", template_content[0], len(template_content))
    conn.close()


def sms_config_to_msg_sms_config():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, server_addr, server_port, to_phone, extra_params from sms_config")
    rows = cur.fetchall()
    sms_content = []

    for sms_id, server_addr, server_port, test_phone, extra_params in rows:
        data = {}
        data["id"] = sms_id
        data["server_addr"] = server_addr
        data["server_port"] = server_port
        data["test_phone"] = test_phone
        data["extra_params"] = extra_params
        data["project_id"] = PROJECT_ID

        sms_content.append(data)

    SmsConfigModel.add_sms_conf_batch(sms_content)

    # print("sms_content ==", sms_content)
    # log.info("迁移 sms_config 至 msg_sms_config", sms_content[0], len(sms_content))
    conn.close()


def message_to_msg_messages():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, template_id, status, status_info, content, create_time, project_id from message")
    rows = cur.fetchall()
    msg_content = []

    for msg_id, template_id, status, status_info, content, create_at, project_id in rows:
        data = {}
        data["id"] = msg_id
        data["template_id"] = template_id
        data["status"] = 1 if status == "success" else 0
        data["status_info"] = status_info
        data["content"] = content
        data["create_at"] = create_at
        data["project_id"] = PROJECT_ID

        msg_content.append(data)

    MessagesModel.add_message_batch(msg_content)

    # print("msg_content ==", msg_content)
    # log.info("迁移 messages 至 msg_messages", msg_content[0], len(msg_content))
    conn.close()


def notice_status_to_msg_inner_notice_status():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT notice_id, user_id, is_read, is_delete from notice_status")
    rows = cur.fetchall()
    notice_content = []

    for notice_id, user_id, is_read, is_del in rows:
        data = {}
        data["notice_id"] = notice_id
        data["user_id"] = user_id
        data["is_read"] = 1 if is_read else 0
        data["is_del"] = 1 if is_del else 0

        notice_content.append(data)

    InnerNoticeStatusModel.add_update_notice_status_batch(notice_content)

    # print("notice_content ==", notice_content)
    # log.info("迁移 notice_status 至 msg_inner_notice_status", notice_content[0], len(notice_content))
    conn.close()


def notice_to_msg_inner_notice():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, title, content, notice_type, create_time, receiver from notice")
    rows = cur.fetchall()
    notice_content = []

    for notice_id, title, content, notice_type, create_at, user_id in rows:
        data = {}
        data["id"] = notice_id
        data["title"] = title
        data["content"] = content
        data["notice_type"] = NOTICE_TYPE[notice_type.upper()]
        data["notice_type_name"] = NOTICE_TYPE_CN[notice_type.upper()]
        data["create_at"] = create_at
        data["user_id"] = user_id if user_id != PROJECT_ID else ""
        data["project_id"] = PROJECT_ID

        notice_content.append(data)

    InnerNoticeModel.add_update_notice_batch(notice_content)

    # print("notice_content ==", notice_content)
    # log.info("迁移 notice 至 msg_inner_notice", notice_content[0], len(notice_content))
    conn.close()


def email_config_to_msg_email_config():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, server_addr, server_port, is_tls, user_name, user_pass, from_user, to_user "
                "from email_config")
    rows = cur.fetchall()
    notice_content = []

    for email_id, server_addr, server_port, is_tls, user_name, user_pass, from_user_addr, test_to_user_addr in rows:
        data = {}
        data["id"] = email_id
        data["server_addr"] = server_addr
        data["server_port"] = server_port
        data["is_tls"] = 1 if is_tls else 0
        data["user_name"] = user_name
        data["user_pass"] = user_pass
        data["from_user_addr"] = from_user_addr
        data["test_to_user_addr"] = test_to_user_addr
        data["project_id"] = PROJECT_ID

        notice_content.append(data)

    EmailConfigModel.add_email_conf_batch(notice_content)

    # print("notice_content ==", notice_content)
    # log.info("迁移 email_config 至 msg_email_config", notice_content[0], len(notice_content))
    conn.close()


def ldap_config_to_ldap_config():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT id, server_addr, is_ssl, server_port, user_name, user_pass, basedn, create_time, "
                "update_time from ldap_config")
    rows = cur.fetchall()
    ldap_content = []

    for ldap_id, server_addr, is_ssl, server_port, user_name, user_pass, base_dn, create_at, update_at in rows:
        data = {}
        data["id"] = ldap_id
        data["server_addr"] = server_addr
        data["is_ssl"] = 1 if is_ssl else 0
        data["server_port"] = server_port
        data["user_name"] = user_name
        data["user_pass"] = user_pass
        data["base_dn"] = base_dn
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["project_id"] = PROJECT_ID

        ldap_content.append(data)

    LdapConfigModel.add_update_ldap_conf_batch(ldap_content)

    # print("ldap_content ==", ldap_content)
    # log.info("迁移 ldap_config 至 ldap_config", ldap_content[0], len(ldap_content))

    conn.close()


def device_agent_to_device_agent():
    try:
        conn = psycopg2.connect(**CONNECT_CONFIG)
        cur = conn.cursor()
        cur.execute("SELECT id, host_ip, host_name, ansible_conn_status, agent_name, agent_version, agent_url,"
                    " agent_status, create_time, update_time from device_agent")
        rows = cur.fetchall()
        device_content = []

        for device_id, host_ip, host_name, ansible_conn_status, agent_name, agent_version, agent_url, agent_status, \
            create_at, update_at in rows:
            data = {}
            data["id"] = device_id
            data["host_ip"] = host_ip
            data["host_name"] = host_name
            data["ansible_conn_status"] = ansible_conn_status
            data["agent_name"] = agent_name
            data["agent_version"] = agent_version
            data["agent_url"] = agent_url
            data["agent_status"] = agent_status
            data["create_at"] = create_at
            data["update_at"] = update_at

            device_content.append(data)

        DeviceAgentModel.add_device_agent_batch(device_content)
    except Exception as e:
        log.error(e)

    # print("device_content ==", device_content)
    # log.info("迁移 device_agent 至 device_agent", device_content[0], len(device_content))
    conn.close()


def business_app_to_business_apps():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    """
    sql = "select role.role_id, role.menu_id, menu.app_id from rolepermission as role " \
          "left join menu on role.menu_id = menu.id " \
          "where role.role_id != 'None'"
    """
    sql_str = "SELECT ba.id, app_name, ba.description, business_id, ba.disable, shorter_form, " \
              "ba.create_time, ba.update_time " \
              "from business_app as ba " \
              "left join business on ba.business_id = business.id " \
              "where business.project_id = '%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    business_content = []

    for b_id, business_app_name, description, business_id, enable, shorter_name, create_at, update_at in rows:
        data = {}
        data["id"] = b_id
        data["business_app_name"] = business_app_name
        data["description"] = description
        data["business_id"] = business_id
        data["enable"] = 0 if enable else 1
        data["shorter_name"] = shorter_name
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["project_id"] = PROJECT_ID
        data["is_del"] = 0
        data["segmentation"] = ','.join(gen_segmentation_words(data.get("business_app_name")))

        business_content.append(data)

    BusinessAppsModel.add_business_apps_batch(business_content)

    # print("business_content ==", business_content)
    # log.info("迁移 business_app 至 business_apps", business_content[0], len(business_content))
    conn.close()


def business_app_org_to_business_app_org():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    cur.execute("SELECT app_id, org_id from business_app_org")
    rows = cur.fetchall()
    business_content = []

    for app_id, org_id in rows:
        data = {}
        data["app_id"] = app_id
        data["org_id"] = org_id

        business_content.append(data)

    BusinessAppOrgModel.add_business_org_batch(business_content)

    # print("business_content ==", business_content)
    # log.info("迁移 business_app_org 至 business_app_org", business_content[0], len(business_content))
    conn.close()


def business_to_business():
    conn = psycopg2.connect(**CONNECT_CONFIG)
    cur = conn.cursor()
    sql_str = "SELECT id, name, description, org_id, org_array, sortby, disable, create_time, update_time " \
              "from business " \
              "where project_id = '%s'" % PROJECT_ID
    cur.execute(sql_str)
    rows = cur.fetchall()
    business_content = []

    for b_id, name, description, org_id, org_array, sortby, enable, create_at, update_at in rows:
        data = {}
        data["id"] = b_id
        data["name"] = name
        data["description"] = description
        data["org_id"] = org_id
        data["org_array"] = org_array
        data["sortby"] = sortby
        data["enable"] = 0 if enable else 1
        data["create_at"] = create_at
        data["update_at"] = update_at
        data["project_id"] = PROJECT_ID
        data["is_del"] = 0

        business_content.append(data)

    BusinessModel.add_business_batch(business_content)

    # print("business_content ==", business_content)
    # log.info("迁移 business 至 business", business_content[0], len(business_content))
    conn.close()


# 迁移角色信息　至　user_role_relationship
def get_dept_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name='ucmp_dept'"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.DEPT_ADMIN)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])
    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    for user_id, in cursor.fetchall():
        user_role = {}
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = dept_tup[1]
        user_role['name'] = "部门管理员"
        user_role['platform_name'] = "ucmp"
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


# 迁移角色信息　至　user_role_relationship
def get_user_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name='ucmp_user'"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.USER)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])

    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    for user_id, in cursor.fetchall():
        user_role = {}
        # print(list(user_id_info))
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = dept_tup[1]
        user_role['name'] = "普通用户"
        user_role['platform_name'] = "ucmp"
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


# 迁移角色信息　至　user_role_relationship
def get_admin_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name in " \
          "('ucmp_admin','F5管理员','系统管理员','云平台管理员','DB管理员','中间件管理员','存储管理员', 'guardian_admin', 'admin')"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.PROJECT_ADMIN)
    # print(new_role_id)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])

    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    # print(list(user_id))
    for user_id, in cursor.fetchall():
        user_role = {}
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = "ucmp_admin"
        user_role['name'] = dept_tup[1]
        user_role['platform_name'] = "ucmp"
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


# 迁移角色信息　至　user_role_relationship
def get_root_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name='ucmp_root'"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.ROOT_ADMIN)
    print(new_role_id)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])

    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    for user_id, in cursor.fetchall():
        user_role = {}
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = dept_tup[1]
        user_role['name'] = "超级管理员"
        user_role['platform_name'] = "ucmp"
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    print(user_role_list)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


# 迁移其他平台最高权限
def get_atomflow_root_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name='atomflow_admin'"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_ATOMFLOW).get(settings.ROOT_ADMIN)
    print(new_role_id)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])

    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    for user_id, in cursor.fetchall():
        user_role = {}
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = dept_tup[1]
        user_role['name'] = "超级管理员"
        user_role['platform_name'] = PLATFORM_ATOMFLOW
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    print(user_role_list)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


# 迁移其他平台最高权限
def get_cmdb_root_role_info():
    link = pymysql.connections.Connection(**KEY_STONE_DB)
    cursor = link.cursor()
    sql = "select id, name from role where name='cmdb_admin'"
    cursor.execute(sql)
    res_dept = cursor.fetchall()
    dept_role_tup_list = list(res_dept)
    new_role_id = settings.INIT_ROLE_ID.get(settings.PLATFORM_CMDB).get(settings.ROOT_ADMIN)
    print(new_role_id)
    user_role_list = []
    role_id_list = []
    for dept_tup in dept_role_tup_list:
        role_id_list.append(dept_tup[0])

    sql = 'select actor_id from assignment where role_id in (%s)' % ','.join(['%s'] * len(role_id_list))
    cursor.execute(sql, role_id_list)
    for user_id, in cursor.fetchall():
        user_role = {}
        user_role['user_id'] = user_id
        user_role['id'] = new_role_id
        user_role['role_data'] = dept_tup[1]
        user_role['name'] = "超级管理员"
        user_role['platform_name'] = PLATFORM_CMDB
        user_role['project_id'] = PROJECT_ID
        user_role_list.append(user_role)
    print(user_role_list)
    cursor.close()
    link.close()
    UserRoleRelationShip.create_role_batch(user_role_list)


if __name__ == '__main__':
    # select_users_org_max_node_id()
    # operation_conf_to_sys_info_conf()
    # apps_to_sys_module()
    # menu_to_sts_menu()
    # users_to_users()
    # license_to_sys_license()
    # strategy_to_msg_strategy()
    # template_to_msg_template()
    # sms_config_to_msg_sms_config()
    # message_to_msg_messages()
    # notice_status_to_msg_inner_notice_status()
    # notice_to_msg_inner_notice()
    # email_config_to_msg_email_config()
    # ldap_config_to_ldap_config()
    # # device_agent_to_device_agent()
    # business_app_to_business_apps()
    # business_app_org_to_business_app_org()
    # business_to_business()
    # get_admin_role_info()
    # get_user_role_info()
    # get_dept_role_info()
    # get_root_role_info()
    org_to_users_orgs()
    # get_atomflow_root_role_info()
    # get_cmdb_root_role_info()

