import json
from sqlalchemy import Column, Integer, Binary, String, Boolean, Text, desc
from guardian.utils.db import provide_session
from guardian.apps import CommonModel, BaseModel
from guardian.apps import ON, DOING, N_SSL, N_PUBLIC
from guardian.apps.users.models import UserRolePermissionModel


class SysModuleModel(BaseModel, CommonModel):
    __tablename__ = "sys_module"

    id = Column(String(40), nullable=False, primary_key=True, index=True)
    module_name = Column(String(50), nullable=False, doc="模块名称")
    description = Column(String(200), doc="描述")
    module_url = Column(String(100), doc="模块地址")
    sortby = Column(Integer, default=0, doc="排序方式")
    remote_url = Column(String(100), doc="外部链接")
    is_public = Column(Integer, default=N_PUBLIC, doc="是否公用")

    def __init__(self, *args, **kwargs):
        super(SysModuleModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(SysModuleModel)
        if self.id:
            qry = qry.filter(SysModuleModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('module_name'):
            qry = qry.filter(cls.module_name == kwargs.get('module_name'))
        if kwargs.get('module_url'):
            qry = qry.filter(cls.module_url == kwargs.get('module_url'))
        if "is_public" in kwargs:
            qry = qry.filter(cls.is_public == kwargs.get('is_public'))
        res = qry.order_by(desc(SysModuleModel.create_at))
        return res.count(), res.all()

    @classmethod
    @provide_session
    def get_module_by_role_ids(cls, role_id_list, session=None):
        qry = session.query(cls, UserRolePermissionModel)
        qry = qry.join(UserRolePermissionModel, cls.id == UserRolePermissionModel.module_id).filter(
            UserRolePermissionModel.role_id.in_(role_id_list))
        return qry.all()

    @classmethod
    @provide_session
    def add_module_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "module_name": data_info.get("module_name"),
                "module_url": data_info.get("module_url"),
                "sortby": data_info.get("sortby"),
                "remote_url": data_info.get("remote_url"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class SysMenuModel(BaseModel, CommonModel):
    __tablename__ = "sys_menu"

    id = Column(String(40), primary_key=True, nullable=False, index=True)
    title = Column(String(50), nullable=False, doc="菜单名称")
    parent_id = Column(String(40), doc="父级菜单ID")
    url = Column(String(100), doc="URL")
    sys_module_id = Column(String(40), doc="系统模块ID")
    icon = Column(String(50), doc="图标")
    sortby = Column(Integer, default=0, doc="排序方式")

    def __init__(self, *args, **kwargs):
        super(SysMenuModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(SysMenuModel)
        if self.id:
            qry = qry.filter(SysMenuModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, offset=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('title'):
            qry = qry.filter(cls.title == kwargs.get('title'))
        if kwargs.get('parent_id'):
            qry = qry.filter(cls.parent_id == kwargs.get('parent_id'))
        if kwargs.get('url'):
            qry = qry.filter(cls.url == kwargs.get('url'))
        if kwargs.get('sys_module_id'):
            qry = qry.filter(cls.sys_module_id == kwargs.get('sys_module_id'))
        if kwargs.get('icon'):
            qry = qry.filter(cls.icon == kwargs.get('icon'))
        res = qry.order_by(desc(SysMenuModel.create_at))
        qry = res.limit(limit).offset((offset - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def get_all(cls, session=None):
        qry = session.query(cls)
        qry = qry.order_by(desc(SysMenuModel.sortby))
        return qry.all()

    @classmethod
    @provide_session
    def get_menu_info_by_role_ids(cls, session=None, **kwargs):
        qry = session.query(cls)
        qry = qry.join(UserRolePermissionModel, cls.id == UserRolePermissionModel.menu_id)
        if kwargs.get('role_ids'):
            qry = qry.filter(UserRolePermissionModel.role_id.in_(kwargs.get('role_ids')))
        return qry.order_by(desc(SysMenuModel.sortby)).all()

    @classmethod
    @provide_session
    def delete_sys_menu(cls, menu_id, session=None, **kwargs):
        sys_menu = session.query(menu_id).filter(cls.id == kwargs.get(menu_id)).first()
        session.delete(sys_menu)
        session.commit()

    @classmethod
    @provide_session
    def add_menu_info(cls, title, parent_id, url, sys_module_id, icon, sortby, session=None, **kwargs):
        obj = SysMenuModel(title=title,
                           parent_id=parent_id,
                           url=url,
                           sys_module_id=sys_module_id,
                           icon=icon,
                           sortby=sortby)
        session.add(obj)
        session.commit()

    @provide_session
    def update_menu_info(self, menu_id, title, parent_id, url, sys_module_id, icon, sortby, session=None):
        qry = session.query(self).first()
        qry.id = menu_id
        qry.title = title
        qry.parent_id = parent_id
        qry.url = url
        qry.sys_module_id = sys_module_id
        qry.icon = icon
        qry.sortby = sortby
        session.commit()

    @classmethod
    @provide_session
    def get_menu_by_ids(cls, menu_ids, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.id.in_(menu_ids))
        return qry.order_by(desc(cls.sortby)).all()

    @classmethod
    @provide_session
    def add_menu_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "title": data_info.get("title"),
                "parent_id": data_info.get("parent_id"),
                "url": data_info.get("url"),
                "sys_module_id": data_info.get("sys_module_id"),
                "icon": data_info.get("icon"),
                "sortby": data_info.get("sortby"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class SysInfoConfModel(BaseModel, CommonModel):
    __tablename__ = "sys_info_conf"

    id = Column(String(50), primary_key=True, nullable=True, index=True)
    sys_logo = Column(String(50), doc="系统LOGO ID")
    sys_name = Column(String(50), doc="系统名称")
    version = Column(String(40), doc="版本编号")
    copyright = Column(String(200), doc="版权")
    surport_mail = Column(String(50), doc="客服邮箱")
    surport_tel = Column(String(20), doc="客服电话")
    log_delete_time = Column(String(10), doc="日志删除时间")
    session_expire = Column(Integer, default=30, doc="session过期时间, 默认30分钟")
    case_sensitive = Column(Integer, default=ON, doc="是否区分大小写")
    license_expire = Column(Integer, default=7, doc="license过期通知时间，默认7天")
    project_id = Column(String(100), doc="租户id")

    def __init__(self, *args, **kwargs):
        super(SysInfoConfModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(SysInfoConfModel)
        if self.id:
            qry = qry.filter(SysInfoConfModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_all(cls, session=None):
        qry = session.query(cls)
        return qry.count(), qry.all()

    @classmethod
    @provide_session
    def get_conf_by_project_id(cls, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get("project_id"):
            qry = qry.filter(cls.project_id == kwargs.get("project_id"))
        return qry.order_by(desc(cls.create_at)).first()

    @provide_session
    def add_item(self, session=None):
        if not self.id:
            self.id = self.gen_uuid()
        session.add(self)
        session.commit()
        return self.id

    @provide_session
    def update_item(self, session=None):
        session.merge(self)
        session.commit()
        return self.id

    @classmethod
    @provide_session
    def add_sys_info_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "sys_logo": data_info.get("sys_logo"),
                "sys_name": data_info.get("sys_name"),
                "version": data_info.get("version"),
                "copyright": data_info.get("copyright"),
                "surport_mail": data_info.get("surport_mail"),
                "surport_tel": data_info.get("surport_tel"),
                "log_delete_time": data_info.get("log_delete_time"),
                "session_expire": data_info.get("session_expire"),
                "create_at": data_info.get("create_at"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class LicenseModel(BaseModel, CommonModel):
    __tablename__ = "sys_license"

    id = Column(String(40), primary_key=True, index=True, nullable=False)
    sys_module_id = Column(String(40), doc="系统模块ID")
    license_data = Column(Binary(), doc="许可文件")
    license_info = Column(Text, doc="许可信息")
    status = Column(Boolean, doc="许可状态")
    project_id = Column(String(40), doc="域ID")

    def __init__(self, *args, **kwargs):
        super(LicenseModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(LicenseModel)
        if self.id:
            qry = qry.filter(LicenseModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_all(cls, session=None):
        qry = session.query(cls)
        return qry.count(), qry.all()

    @classmethod
    @provide_session
    def get_one_by_module_id(cls, module_id=None, project_id=None, session=None):
        qry = session.query(LicenseModel)
        if module_id:
            qry = qry.filter(cls.sys_module_id == module_id)
        if project_id:
            qry = qry.filter(cls.project_id == project_id)
        return qry.first()

    @provide_session
    def update_license_file(self, session=None, **kwargs):
        can_edit = ["license_data", "license_info", "status"]
        for k, v in kwargs.items():
            if k in can_edit and v is not None:
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def upload_license_file(cls, app_id, data, info, status, project_id, session=None):
        query = session.query(LicenseModel)
        license_info = query.filter(cls.sys_module_id == app_id).filter(cls.project_id == project_id).first()
        if not license_info:
            obj = LicenseModel(
                sys_module_id=app_id,
                license_data=data,
                license_info=json.dumps(info, ensure_ascii=False),
                status=status,
                project_id=project_id
            )
            obj.id = obj.gen_uuid()
            session.add(obj)
        else:
            license_info.sys_module_id = app_id
            license_info.license_data = data
            license_info.license_info = json.dumps(info, ensure_ascii=False)
            license_info.status = status
            session.merge(license_info)
        session.commit()

    @classmethod
    @provide_session
    def add_license_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "sys_module_id": data_info.get("sys_module_id"),
                "license_data": data_info.get("license_data"),
                "license_info": data_info.get("license_info"),
                "status": data_info.get("status"),
                "create_at": data_info.get("create_at"),
                "project_id": data_info.get("project_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class SyncLdapStatusModel(BaseModel, CommonModel):
    __tablename__ = "sys_sync_ldap_status"

    id = Column(String(40), primary_key=True, index=True, nullable=False)
    project_id = Column(String(64), doc="域ID")
    sync_by = Column(String(50), doc="同步操作人")
    base_dn = Column(String(100), doc="domain name")
    sync_info = Column(String(20), doc="同步内容")
    sync_status = Column(Integer, nullable=False, doc="同步状态")
    description = Column(Text, doc="备注")

    def __init__(self, *args, **kwargs):
        super(SyncLdapStatusModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(LicenseModel)
        if self.id:
            qry = qry.filter(SyncLdapStatusModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_latest_create_one(cls, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get("project_id"):
            qry = qry.filter(cls.project_id == kwargs.get("project_id"))
        if kwargs.get("base_dn"):
            qry = qry.filter(cls.base_dn == kwargs.get("base_dn"))
        if kwargs.get("sync_info"):
            qry = qry.filter(cls.sync_info == kwargs.get("sync_info"))
        return qry.order_by(desc(cls.create_at)).first()

    @classmethod
    @provide_session
    def add_sync_ldap_status(cls, sync_status=DOING, session=None, **kwargs):
        entry = cls()
        entry.id = cls().gen_uuid()
        entry.sync_status = sync_status
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v != "":
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_sync_status(self, status, description=None, session=None):
        self.sync_status = status
        self.description = description
        session.merge(self)
        session.commit()
        return self


class LdapConfigModel(BaseModel, CommonModel):
    __tablename__ = "ldap_config"

    id = Column(String(50), primary_key=True, nullable=False, index=True)
    project_id = Column(String(64), nullable=False, doc="租户ID")
    server_addr = Column(String(50), nullable=False, doc="服务器地址")
    server_port = Column(Integer, nullable=False, doc="服务器端口")
    is_ssl = Column(Integer, default=N_SSL, doc="是否获得SSL证书")
    user_name = Column(String(100), doc="用户名")
    user_pass = Column(String(50), doc="密码")
    base_dn = Column(String(100), doc="domain name")

    def __init__(self, *args, **kwargs):
        super(LdapConfigModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(LdapConfigModel)
        if self.id:
            qry = qry.filter(LdapConfigModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, page_idx=1, limit=100, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('server_addr'):
            qry = qry.filter(cls.server_addr == kwargs.get('server_addr'))
        if kwargs.get('server_port'):
            qry = qry.filter(cls.server_port == kwargs.get('server_port'))
        if kwargs.get('is_ssl'):
            qry = qry.filter(cls.is_ssl == kwargs.get('is_ssl'))
        if kwargs.get('user_name'):
            qry = qry.filter(cls.user_name == kwargs.get('user_name'))
        if kwargs.get('base_dn'):
            qry = qry.filter(cls.base_dn == kwargs.get('base_dn'))
        res = qry.order_by(desc(cls.create_at))
        qry = res.limit(limit).offset((page_idx - 1) * limit)
        return res.count(), qry.all()

    @classmethod
    @provide_session
    def get_ldap_info_by_project_id(cls, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        return qry.first()

    @classmethod
    @provide_session
    def add_ldap_conf(cls, session=None, **kwargs):
        entry = cls()
        entry.id = entry.gen_uuid()
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v != "":
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_ldap_conf(self, session=None, **kwargs):
        can_edit = ["server_addr", "server_port", "is_ssl", "user_name", "user_pass", "base_dn"]
        for k, v in kwargs.items():
            if k in can_edit and v != "":
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def add_update_ldap_conf_batch(cls, data, session=None):
        data_list = []

        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "server_addr": data_info.get("server_addr"),
                "project_id": data_info.get("project_id"),
                "is_ssl": data_info.get("is_ssl"),
                "server_port": data_info.get("server_port"),
                "user_name": data_info.get("user_name"),
                "user_pass": data_info.get("user_pass"),
                "base_dn": data_info.get("base_dn"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


@provide_session
def get_menu_by_platform(platform, session=None):
    qry = session.query(SysMenuModel)
    qry = qry.join(SysModuleModel, SysModuleModel.id == SysMenuModel.sys_module_id).filter(
        SysModuleModel.module_url.in_(platform))
    return qry.count(), qry.order_by(desc(SysMenuModel.sortby)).all()
