
import jieba


def gen_segmentation_words(word):
    """

    :param word:
    :return:
    """
    w_list = [w for w in word]
    jieba_list = jieba.lcut_for_search(word)
    return set(w_list + jieba_list)


def get_app_name_similar_by_seg(seg, app_tuples, similar):
    """
    相似度算法：
    1、输入的app_name 的分词list 与数据库中 segmentation 的分词list 分别求交集和病机
    2、len(交集) / len(并集)
    :param seg:
    :param app_tuples:
    :return:
    """
    seg = set(seg)
    rst = []
    for app_id, business_app_name, shorter_name, segmentation in app_tuples:
        segmentation_list = segmentation.split(",")
        similarity = len(set(segmentation_list) & seg) / len(set(segmentation_list) | seg)
        if similarity >= similar:
            rst.append({
                "id": app_id,
                "business_app_name": business_app_name,
                "shorter_name": shorter_name,
                "similar": similarity
            })
    rst.sort(key=lambda k: k.get('similar', 0), reverse=True)
    return rst


if __name__ == '__main__':
    rst = ','.join(gen_segmentation_words("akdk"))
    print(rst)
