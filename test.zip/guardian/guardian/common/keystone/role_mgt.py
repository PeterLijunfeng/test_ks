from guardian import settings
from guardian.log4 import app_logger as log
import requests
from guardian.common.errors import KeystoneHandleException


def create_role(role):
    req_data = {
        "role": {
            "name": "developer"
        }
    }

    req_data['role']['name'] = role
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/roles', headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            role_id = resp_json['role']['id']
            name = resp_json['role']['name']
            return role_id, name
        else:
            return None, None
    else:
        log.error('error create a new role, response: {0}'.format(_resp))
        raise KeystoneHandleException('error create role {0} with response status {1}'
                                      .format(role, _resp.status_code),
                                      _resp.status_code)


def udpate_role(role_id, role_name):
    req_data = {
        "role": {
            "name": "developer"
        }
    }
    req_data['role']['name'] = role_name
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.patch(settings.KEYSTONE_BASE + '/v3/roles/'+role_id,
                           headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            role_id = resp_json['role']['id']
            name = resp_json['role']['name']
            return role_id, name
        else:
            return None, None
    else:
        log.error('error create a new role, response: {0}'.format(_resp))
        raise KeystoneHandleException('error create role {0} with response status {1}'
                                      .format(role_name, _resp.status_code),
                                      _resp.status_code)


def delete_roles(role_id):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.delete(settings.KEYSTONE_BASE + '/v3/roles/' + role_id, headers=myheaders, verify=False)

    if _resp.status_code == 204:
        log.debug('delete roles -- response {0}'.format(_resp))
    else:
        log.error('error delete roles, response: {0}'.format(_resp))
        raise KeystoneHandleException('error delete roles {0} with response status {1}'
                                      .format(role_id, _resp.status_code),
                                      _resp.status_code)


def list_roles():
    log.debug('list_roles')
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/roles', headers=myheaders, verify=False)

    if _resp.ok:
        log.debug('list_roles -- response {0}'.format(_resp))
        resp_json = _resp.json()
        if resp_json is not None:
            roles = resp_json['roles']
            return roles
        else:
            return None
    else:
        log.error('error list roles, response: {0}'.format(_resp))
        raise KeystoneHandleException('error list roles  with response status {0}'
                                      .format(_resp.status_code),
                                      _resp.status_code)


def get_roles_by_id(roleid):
    log.debug('list_roles')
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/roles/' + roleid, headers=myheaders, verify=False)
    if _resp.ok:
        log.debug('get_roles_by_id -- response {0}'.format(_resp))
        resp_json = _resp.json()
        if resp_json is not None:
            role = resp_json['role']
            return role
        else:
            return None
    else:
        log.error('error get_roles_by_id, response: {0}'.format(_resp))
        raise KeystoneHandleException('error get_roles_by_id with response status {0}'
                                      .format(_resp.status_code),
                                      _resp.status_code)


def assign_role(domainid, userid, roleid):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.put(settings.KEYSTONE_BASE + '/v3/domains/' + domainid + '/users/' + userid + '/roles/' + roleid,
                         headers=myheaders, verify=False)
    if _resp.ok:
        log.debug('assign role {0} to user {1} successfully!!!'.format(roleid, userid))
    else:
        log.error('error got a new token, response: {0}'.format(_resp))
        raise KeystoneHandleException('error assigning role {0} to user {1} with response status {2}'
                                      .format(roleid, userid, _resp.status_code),
                                      _resp.status_code)


def assign_role_batch(domainid, userid, role_ids):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    for roleid in role_ids:
        _resp = requests.put(
            settings.KEYSTONE_BASE + '/v3/domains/' + domainid + '/users/' + userid + '/roles/' + roleid,
            headers=myheaders, verify=False)
        if _resp.ok:
            log.debug('assign role {0} to user {1} successfully!!!'.format(roleid, userid))
        else:
            log.error('error got a new token, response: {0}'.format(_resp))
            raise KeystoneHandleException('error assigning role {0} to user {1} with response status {2}'
                                          .format(roleid, userid, _resp.status_code),
                                          _resp.status_code)


def revoke_role(domainid, userid, roleid):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.delete(
        settings.KEYSTONE_BASE + '/v3/domains/' + domainid + '/users/' + userid + '/roles/' + roleid,
        headers=myheaders, verify=False)
    if _resp.ok:
        log.debug('assign role {0} to user {1} successfully!!!'.format(roleid, userid))
    else:
        log.error('error got a new token, response: {0}'.format(_resp))
        raise KeystoneHandleException('error assigning role {0} to user {1} with response status {2}'
                                      .format(roleid, userid, _resp.status_code),
                                      _resp.status_code)


def revoke_role_batch(domainid, userid, role_ids):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN

    for roleid in role_ids:
        _resp = requests.delete(
            settings.KEYSTONE_BASE + '/v3/domains/' + domainid + '/users/' + userid + '/roles/' + roleid,
            headers=myheaders, verify=False)
        if _resp.ok:
            log.debug('assign role {0} to user {1} successfully!!!'.format(roleid, userid))
        else:
            log.error('error got a new token, response: {0}'.format(_resp))
            raise KeystoneHandleException('error assigning role {0} to user {1} with response status {2}'
                                          .format(roleid, userid, _resp.status_code),
                                          _resp.status_code)


def query_role_by_role_name(role_name):
    req_data = dict()
    req_data['name'] = role_name
    log.debug('query role name:{0}'.format(role_name))
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/roles', headers=myheaders, params=req_data, verify=False)

    if _resp.ok:
        log.debug('query role name -- response {0}'.format(_resp))
        resp_json = _resp.json()
        if resp_json is not None:
            roles = resp_json['roles']
            return roles
        else:
            return None
    else:
        log.error('error query role name, response: {0}'.format(_resp))
        raise KeystoneHandleException('error query role name with response status {0}'
                                      .format(_resp.status_code),
                                      _resp.status_code)


def assign_role_project(project_id, userid, roleid):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.put(
        settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + userid + '/roles/' + roleid,
        headers=myheaders, verify=False)
    if _resp.ok:
        log.debug('assign role on project {0} to user {1} successfully!!!'.format(roleid, userid))
    else:
        log.error('error got a new token, response: {0}'.format(_resp))
        raise KeystoneHandleException('error assigning role on project {0} to user {1} with response status {2}'
                                      .format(roleid, userid, _resp.status_code),
                                      _resp.status_code)


def assign_role_project_batch(project_id, userid, role_ids):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN

    for roleid in role_ids:
        _resp = requests.put(
            settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + userid + '/roles/' + roleid,
            headers=myheaders, verify=False)
        if _resp.ok:
            log.debug('assign role on project {0} to user {1} successfully!!!'.format(roleid, userid))
        else:
            log.error('error got a new token, response: {0}'.format(_resp))
            raise KeystoneHandleException('error assigning role on project {0} to user {1} with response status {2}'
                                          .format(roleid, userid, _resp.status_code),
                                          _resp.status_code)


def revoke_role_project(project_id, userid, roleid):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN

    _resp = requests.delete(
        settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + userid + '/roles/' + roleid,
        headers=myheaders, verify=False)
    if _resp.ok:
        log.debug('revoke role on project {0} to user {1} successfully!!!'.format(roleid, userid))
    else:
        log.error('error got a new token, response: {0}'.format(_resp))
        raise KeystoneHandleException('error revoking role {0} to user {1} with response status {2}'
                                      .format(roleid, userid, _resp.status_code),
                                      _resp.status_code)


def revoke_role_project_batch(project_id, userid, role_ids):
    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN

    for roleid in role_ids:
        _resp = requests.delete(
            settings.KEYSTONE_BASE + '/v3/projects/' + project_id + '/users/' + userid + '/roles/' + roleid,
            headers=myheaders, verify=False)
        if _resp.ok:
            log.debug('revoke role {0} to user {1} successfully!!!'.format(roleid, userid))
        else:
            log.error('error got a new token, response: {0}'.format(_resp))
            raise KeystoneHandleException('error revoking role {0} to user {1} with response status {2}'
                                          .format(roleid, userid, _resp.status_code),
                                          _resp.status_code)
