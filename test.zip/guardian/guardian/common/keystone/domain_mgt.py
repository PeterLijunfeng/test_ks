from guardian import settings
from guardian.log4 import app_logger as LOG
import requests
from guardian.common.errors import KeystoneHandleException

DEFAULT_DOMAIN_ID = "default"
DEFAULT_DOMAIN_NAME = "leaptocloud"


def create_domain(domain_name, description):
    req_data = {
        "domain": {
            "description": "My new domain",
            "enabled": True,
            "name": "mynewdomain"
        }
    }

    req_data['domain']['name'] = domain_name
    req_data['domain']['description'] = description

    myheaders = {'Content-Type': 'application/json'}
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.post(settings.KEYSTONE_BASE + '/v3/domains', headers=myheaders, json=req_data, verify=False)

    if _resp.ok:
        resp_json = _resp.json()
        if resp_json is not None:
            return resp_json
    else:
        LOG.error('error create a new domains, response: {0}'.format(_resp))
        raise KeystoneHandleException('error create domains {0} with response status {1}'
                                .format(domain_name, _resp.status_code),
                                _resp.status_code)


def list_domain():
    """
    {
        "description": "My domain",
        "enabled": true,
        "id": "2cf2952e868a41a18a2fa9cdd0268990",
        "links": {
          "self": "http://192.168.3.124:35357/v3/domains/2cf2952e868a41a18a2fa9cdd0268990"
        },
        "name": "guardian"
      }
    :return:
    """

    myheaders = dict()
    myheaders['Content-Type'] = 'application/json'
    myheaders['X-Auth-Token'] = settings.KEYSTONE_ADMIN_TOKEN
    _resp = requests.get(settings.KEYSTONE_BASE + '/v3/domains', headers=myheaders, params=None, verify=False)

    if _resp.ok:
        LOG.debug('list domains -- response {0}'.format(_resp))
        resp_json = _resp.json()
        return resp_json
    else:
        LOG.error('error list domains, response {0}:'.format(_resp))
        raise KeystoneHandleException('error list domains with response status {0}'
                                      .format(_resp.status_code), _resp.status_code)
