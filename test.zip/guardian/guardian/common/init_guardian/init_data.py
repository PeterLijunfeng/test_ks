# -*- coding: utf-8 -*-
"""
初始化guardian脚本
    执行初始化前，请配置本文档中的 SUPER_ADMIN_INFO, ROLE_LIST
    初始化的管理员的名称需要在 settings.py中配置。修改 INIT_ADMIN_NAME 的字符串
    1、创建租户
    2、创建超级管理员
    3、初始化guardian module, menu, template, logo
    4、初始化角色
    5、超级管理员绑定角色
"""

import os
import requests
from datetime import datetime
from guardian.utils.db import provide_session
from guardian.log4 import app_logger as log
from guardian.common.errors import ApiException
from guardian.common.keystone.project_mgt import list_project as keystone_list_project
from guardian.common.keystone.project_mgt import create_project as keystone_create_project
from guardian.common.keystone.user_mgt import query_user as keystone_query_user
from guardian.common.keystone.user_mgt import create_user as keystone_create_user
from guardian.common.keystone.user_mgt import update_user as keystone_update_user
from guardian.common.keystone.domain_mgt import list_domain as keystone_list_domain
from guardian.common.keystone.domain_mgt import create_domain as keystone_create_domain
from guardian.common.keystone.role_mgt import create_role as keystone_create_role
from guardian.common.keystone.role_mgt import query_role_by_role_name as keystone_query_role
from guardian.common.keystone.role_mgt import assign_role_project as keystone_binding_role
from guardian.settings import GUARDIAN_BASE, APIBASEURL, INIT_ROLE_ID, INIT_ADMIN_NAME, INIT_ROOT_NAME
from guardian.settings import KEYSTONE_DEFAULT_ROLE_NAME, LOGIN_DEFAULT_DOMAIN_NAME
from guardian.settings import UCMP_ROLE_KIND_ROOT, PLATFORM_UCMP, UCMP_ROLE_KIND_CHOICES
from guardian.settings import CMDB_ROLE_KIND_ROOT, PLATFORM_CMDB, CMDB_ROLE_KIND_CHOICES
from guardian.settings import ATOMFLOW_ROLE_KIND_ROOT, PLATFORM_ATOMFLOW, ATOMFLOW_ROLE_KIND_CHOICES
from guardian.settings import GUARDIAN_ROLE_KIND_ROOT, PLATFORM_GUARDIAN, GUARDIAN_ROLE_KIND_CHOICES
from guardian.apps import ON
from guardian.apps.users.models import UsersModel
from guardian.apps.users.models import UserRolesModel
from guardian.apps.users.models import UserRoleRelationShip
from guardian.apps.users.models import UserRolePermissionModel
from guardian.apps.sys_config.models import SysMenuModel


SUPER_ADMIN_INFO = {
    "project_name": "admin",
    "username": INIT_ADMIN_NAME,
    "password": "123456",
    "email": "superadmin@company.com",
    "comments": "superadmin",
    "domain_name": LOGIN_DEFAULT_DOMAIN_NAME,
    "domain_comments": "domain",
    "keystone_default_role": KEYSTONE_DEFAULT_ROLE_NAME,
}

SUPER_ROOT_INFO = {
    "project_name": "system_root",
    "username": INIT_ROOT_NAME,
    "password": "system_super_root",
    "email": "superadmin@company.com",
    "comments": "superadmin",
    "domain_name": LOGIN_DEFAULT_DOMAIN_NAME,
    "domain_comments": "domain",
    "keystone_default_role": KEYSTONE_DEFAULT_ROLE_NAME,
}

ROLE_DATA = [
    "atomflow_root",
    "system_root",
    "cmdb_root",
    "ucmp_root",
]

INIT_SQL = "init_guardian_data.sql"
INIT_TEMPLATE_SQL = "init_guardian_template.sql"
ROLE_COMMETS = "system init role"
LOGO_INFO = "logo_leaptocloud.png"
PLATFORM_LIST = [PLATFORM_UCMP, PLATFORM_CMDB, PLATFORM_ATOMFLOW, PLATFORM_GUARDIAN]
ROOT_ROLE_LIST = [UCMP_ROLE_KIND_ROOT, CMDB_ROLE_KIND_ROOT, ATOMFLOW_ROLE_KIND_ROOT, GUARDIAN_ROLE_KIND_ROOT]


def create_domain(domain_name, domain_comments):
    data = keystone_list_domain()
    domain_list = data.get("domains")
    domain_id = None
    for domain in domain_list:
        if domain.get("name") == domain_name:
            domain_id = domain.get("id")
    if not domain_id:
        domain_data = keystone_create_domain(domain_name, domain_comments)
        domain_id = domain_data.get("domain").get("id")
        if not domain_id:
            raise Exception("can not get domain_id")
    log.info("domain_name: %s  domain_id: %s" % (domain_name, domain_id))
    return domain_id


def create_project(project_name, domain):
    project_data = keystone_list_project(domain)
    for project in project_data.get('projects'):
        if project.get('name', '') == project_name:
            project_id = project.get('id')
            break
    else:
        project_info = keystone_create_project(domain, project_name, 'admin project', False, domain)
        project_id = project_info.get('project').get('id')
        if not project_id:
            raise Exception("can not get project_id")
    log.info("project_id: %s" % (project_id))
    return project_id


def create_user(project_id, domain_id, keystone_role_name, **kwargs):
    username = kwargs.get("username")
    password = kwargs.get("password")
    email = kwargs.get("email")
    comments = kwargs.get("comments")

    user_info = keystone_query_user(domain_id, username)
    if user_info["users"]:
        user_id = user_info["users"][0]["id"]
    else:
        resp = keystone_create_user(domain_id=domain_id, user_name=username, passwd=password,
                                    enabled=True, project_id=project_id)
        user_id = resp['user']['id']
        # binding keystone default role in order to authentication token
        role_id = keystone_query_role(keystone_role_name)
        if role_id:
            role_id = role_id[0].get('id')
        else:
            role_id, name = keystone_create_role(keystone_role_name)
        keystone_binding_role(project_id=project_id, userid=user_id, roleid=role_id)

    user_obj = UsersModel.get_user_by_username_domain(username, domain_id)
    if user_obj:
        user_info = {'default_project_id': project_id}
        # modify user default project
        keystone_update_user(domain_id=domain_id, user_id=user_id, project_id=project_id)
        UsersModel.update_user(user_obj, kwargs=user_info)
    else:
        UsersModel.create_user(user_id=user_id, username=username, realname=username, email=email, tel="", phone="",
                               org_id="", org_name="", domain_id=domain_id, enable=ON, first_login=True,
                               comments=comments, org_array=[], default_project_id=project_id, object_suid="",
                               dn="", user_code="", lower_name=username.lower())
    log.info("super_admin_id: %s" % user_id)
    return user_id


def create_guardian_roles(project_id, platform_list, role_comments, platform_role_dict, init_role_id):
    log.info("start create_guardian_roles")
    init_role_id_list = []
    for platform, role in init_role_id.items():
        init_role_id_list += role.values()

    filters = {
        "project_id": project_id,
        "role_id_list": init_role_id_list
    }
    cnt, role_objs = UserRolesModel.get_list(**filters)
    exist_role_list = []
    for role_obj in role_objs:
        exist_role_list.append(role_obj.role_data)
    role_data = []
    for platform_name in platform_list:
        platfrom_dict = platform_role_dict.get(platform_name)
        for data, name in platfrom_dict.items():
            if data not in exist_role_list:
                role_data.append({
                    "id": init_role_id[platform_name][name],
                    "name": name,
                    'role_ctl': {},
                    'role_data': data,
                    "comments": role_comments,
                    "project_id": None if data in ROOT_ROLE_LIST else project_id,
                    "platform_name": platform_name
                 })
    if role_data:
        UserRolesModel().create_role_batch(role_data)
    log.info("create_guardian_roles done!")


def assign_menu_to_role(role_id_list):
    log.info("start assign_menu_to_role")
    cnt, menu_objs = SysMenuModel.get_list()
    relation_data = []
    for role_id in role_id_list:
        for menu in menu_objs:
            relation_data.append({
                'id': UserRolePermissionModel().gen_uuid(),
                'role_id': role_id,
                'module_id': menu.sys_module_id,
                'menu_id': menu.id
            })
    UserRolePermissionModel().create_menu_premission(relation_data=relation_data)
    log.info("assign_menu_to_role done!")


def assign_role_to_superadmin(super_admin_id, add_role_id_list):
    filters = {
        "user_id": super_admin_id,
        "role_ids": add_role_id_list,
    }

    rst = UserRoleRelationShip.get_relation_by_user_role_ids(**filters)
    rst_role_id_list = [relate.role_id for relate in rst]
    delete_roles = list(set(rst_role_id_list).difference(set(add_role_id_list)))
    add_roles = list(set(add_role_id_list).difference(set(rst_role_id_list)))
    if delete_roles:
        UserRoleRelationShip.delete_relation(user_id=super_admin_id, role_ids=delete_roles)
    if add_roles:
        UserRoleRelationShip.add_relation(user_id=super_admin_id, role_ids=add_roles)
    log.info("assign_role_to_superadmin done!")


@provide_session
def init_db_data(init_sql, session=None):
    log.info('start _init_db_data')
    this_dir, this_filename = os.path.split(__file__)
    # sql_path = os.path.join(this_dir, "init_guardian_data.sql")
    sql_path = os.path.join(this_dir, init_sql)
    with open(sql_path, 'r', encoding='UTF-8') as f:
        lines = []
        i = 0
        for line in f.readlines():
            i += 1
            qry = line.split("\n")[0]
            lines.append(qry)
        qry = " ".join(lines)
        session.execute(qry)
    log.info('end _init_db_data')


def init_leaptocloud_logo():
    url = "%s%s/sys/file" % (GUARDIAN_BASE, APIBASEURL)
    log.info("url is %s" % url)
    file = {'file': (LOGO_INFO, open(LOGO_INFO, 'rb'), "image/png")}
    data = requests.post(url, files=file)
    log.info(data.status_code)
    log.info("logo static url: {0}".format(data.json().get("data").get("url")))
    data = data.json().get("data")
    if "url" in data and data.get("url"):
        return data.get("url")
    else:
        log.error("init_leaptocloud_logo ERROR: can not get logo static url")
        raise ApiException("init_leaptocloud_logo ERROR: can not get logo static url")


@provide_session
def init_db_template(project_id, platform, init_template_sql, session=None):
    log.info('start init_db_template')
    this_dir, this_filename = os.path.split(__file__)
    # sql_path = os.path.join(this_dir, "init_guardian_data.sql")
    sql_path = os.path.join(this_dir, init_template_sql)
    with open(sql_path, 'r', encoding='UTF-8') as f:
        lines = []
        i = 0
        for line in f.readlines():
            i += 1
            qry = (line % (project_id, platform)).split("\n")[0]
            # 格式化前，将SQL语句中的 % 替换为了 &
            if "&" in qry:
                qry = qry.replace("&", "%")
            lines.append(qry)
        qry = " ".join(lines)
        session.execute(qry)
    log.info('end init_db_template')


@provide_session
def init_sys_conf(project_id, logo_url, session=None):
    log.info('start init_sys_conf')
    line = "INSERT INTO sys_info_conf (create_at, update_at, id, sys_logo, sys_name, version, copyright, surport_mail, surport_tel, log_delete_time, session_expire, project_id, case_sensitive, license_expire) values('%s', '%s', 'dbdf7fbd-att1-4d34-9ba5-2d3779c11b21','%s','IT运营管理中枢','V3.3','Copyright © 2019','support@domain.com','400-000-0000','7',30, '%s', 1, 7) ON CONFLICT (id) do nothing;"
    qry = line % (datetime.now(), datetime.now(), logo_url, project_id)
    session.execute(qry)
    log.info('end init_sys_conf')


def create_root_user(project_id, domain_id, keystone_role_name, **kwargs):
    username = kwargs.get("username")
    password = kwargs.get("password")

    user_info = keystone_query_user(domain_id, username)
    if user_info["users"]:
        user_id = user_info["users"][0]["id"]
    else:
        resp = keystone_create_user(domain_id=domain_id, user_name=username, passwd=password,
                                    enabled=True, project_id=project_id)
        user_id = resp['user']['id']
        # binding keystone default role in order to authentication token
        role_id = keystone_query_role(keystone_role_name)
        if role_id:
            role_id = role_id[0].get('id')
        else:
            role_id, name = keystone_create_role(keystone_role_name)
        keystone_binding_role(project_id=project_id, userid=user_id, roleid=role_id)

    user_obj = UsersModel.get_user_by_username_domain(username, domain_id)
    if user_obj:
        user_info = {'default_project_id': project_id}
        # modify user default project
        keystone_update_user(domain_id=domain_id, user_id=user_id, project_id=project_id)
        UsersModel.update_user(user_obj, kwargs=user_info)
    else:
        UsersModel.create_user(user_id=user_id, username=username, realname=username, email="", tel="", phone="",
                               org_id="", org_name="", domain_id=domain_id, enable=ON, first_login=False,
                               comments="", org_array=[], default_project_id=project_id, object_suid="",
                               dn="", user_code="", lower_name=username.lower())
    log.info("super_admin_id: %s" % user_id)
    return user_id


def create_super_root_role():
    role_list = []
    for role_data in ROLE_DATA:
        role_info = {}
        role_info['name'] = INIT_ROOT_NAME
        # role_info['project_id'] = PROJECT_ID
        role_info['role_data'] = role_data
        role_info['platform_name'] = role_data.split('_')[0]
        role_list.append(role_info)
    print(role_list)

    UserRolesModel.add_create_role_batch(role_list)


def main():
    log.info("START init guardian data")
    platform_list = PLATFORM_LIST
    platform_role_dict = {
        PLATFORM_UCMP: UCMP_ROLE_KIND_CHOICES,
        PLATFORM_CMDB: CMDB_ROLE_KIND_CHOICES,
        PLATFORM_ATOMFLOW: ATOMFLOW_ROLE_KIND_CHOICES,
        PLATFORM_GUARDIAN: GUARDIAN_ROLE_KIND_CHOICES
    }

    domain_id = create_domain(SUPER_ADMIN_INFO.get("domain_name"),
                              SUPER_ADMIN_INFO.get("domain_comments"))
    project_id = create_project(SUPER_ADMIN_INFO.get("project_name"), domain_id)
    keystone_role_name = SUPER_ADMIN_INFO.get("keystone_default_role")
    # 若当前domain下已经存在该用户，只更新project_id
    super_admin_id = create_user(project_id, domain_id, keystone_role_name, **SUPER_ADMIN_INFO)
    super_root_id = create_root_user(project_id, domain_id, keystone_role_name, **SUPER_ROOT_INFO)
    logo_url = init_leaptocloud_logo()
    init_sys_conf(project_id, logo_url)

    init_db_data(INIT_SQL)
    init_db_template(project_id, PLATFORM_UCMP, INIT_TEMPLATE_SQL)

    create_guardian_roles(project_id, platform_list, ROLE_COMMETS, platform_role_dict, INIT_ROLE_ID)
    filters = {
        "project_id": project_id,
        "role_data_list": [UCMP_ROLE_KIND_ROOT, CMDB_ROLE_KIND_ROOT, ATOMFLOW_ROLE_KIND_ROOT, GUARDIAN_ROLE_KIND_ROOT]
    }
    cnt, role_info = UserRolesModel().get_list(**filters)
    role_id_list = []
    for role in role_info:
        role_id_list.append(role.id)

    filters_root = {
        "name": INIT_ROOT_NAME,
        "role_data_list": [UCMP_ROLE_KIND_ROOT, CMDB_ROLE_KIND_ROOT, ATOMFLOW_ROLE_KIND_ROOT, GUARDIAN_ROLE_KIND_ROOT]
    }
    cnt, role_root_info = UserRolesModel().get_list(**filters_root)
    role_root_id_list = []
    for role in role_root_info:
        role_root_id_list.append(role.id)

    assign_menu_to_role(role_id_list)
    assign_role_to_superadmin(super_admin_id, role_id_list)
    assign_role_to_superadmin(super_root_id, role_root_id_list)
    log.info("END init guardian data")


if __name__ == '__main__':
    main()
