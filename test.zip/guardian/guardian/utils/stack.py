#-*- coding: utf-8 -*-
'''
@author: mathews
'''
import threading
from guardian.settings import LOG


class Stack(object):
    """栈"""
    def __init__(self):
        self.__list = []
        self._lock = threading.Lock()

    def push(self, item):
        """添加一个新的元素item到栈顶"""
        self._lock.acquire()
        try:
            self.__list.append(item)
        finally:
            self._lock.release()
        LOG.debug('stack push {0}'.format(item))

    def pop(self):
        """弹出栈顶元素"""
        self._lock.acquire()

        ret = None

        try:
            if len(self.__list) > 0:
                ret = self.__list.pop()
        finally:
            self._lock.release()

        LOG.debug('stack pop {0}'.format(ret))
        return ret

    def peek(self):
        """返回栈顶元素"""
        if self.__list is None:
            return None
        else:
            return self.__list[-1]

    def is_empty(self):
        """判断是否为空"""
        return len(self.__list) == 0
        # return not self.__list

    def size(self):
        """返回元素的个数"""
        return len(self.__list)
