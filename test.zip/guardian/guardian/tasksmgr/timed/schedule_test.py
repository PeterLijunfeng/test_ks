
from guardian.log4 import app_logger
from celery.decorators import task
from celery.utils.log import get_task_logger

log = get_task_logger("celery_logger")


@task(name="schedule_run", queue="musir", routing_key="test.hello_test")
def schedule_run():
    print("scheduler run 0")
    log.info("scheduler run 0")
    log.error("scheduler run 0")


@task(name="schedule_run_1", queue="musir", routing_key="test.hello_test")
def schedule_run_1():
    print("scheduler run 1")
    log.info("scheduler run 1")
    log.error("scheduler run 1")