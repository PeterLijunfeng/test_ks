import unittest
import requests
from datetime import datetime
from time import time


class DeviceTestCase(unittest.TestCase):
    def setUp(self):
        self.base_url = "http://127.0.0.1:8080/gd/v2"
        self.start_time = datetime.now()
        self.token = 'gAAAAABcmZxEl5DoYcBK--LjZRLsKvz_huac28E-UADnRykUQ_XrQCBrV-gDdbCwtCNJ7pNKIKiU6UZAF8KS6uPga0MoiW7nVcSKsg4h_vYuz3RbbEpi3tM36sHu6CnGIXZkAOXwdcYBnSfLgrcnAyRsUf1W0ZZ91zIS_WjXubUTH2ztBFSEPF4'
        self.headers = {'X-Subject-Token': self.token}
        print("start unittest -----{0}".format(datetime.now()))

    def test_get_agent_list(self):
        api_start_time = time()
        url = self.base_url + "/device/agent/list"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_get_agent_list cost time: {0}".format(time() - api_start_time))

    def _test_sync_device_agent(self):
        api_start_time = time()
        url = self.base_url + "/device/agent/sync"
        print("url is %s" % url)
        data = requests.get(url, headers=self.headers)
        print(data.status_code)
        print(data.json())
        print("test_sync_device_agent cost time: {0}".format(time() - api_start_time))

    def _test_agent_script_exec(self):
        api_start_time = time()
        url = self.base_url + "/agent/script/exec"
        print("url is %s" % url)
        req_data = [
            {
                "host_ip": "127.0.0.1",
                "host_name": "host126",
                "agent_version": "1.0",
                "agent_url": "127.0.0.1"
            }
        ]

        data = requests.post(url, headers=self.headers, json=req_data)
        print(data.status_code)
        print(data.json())
        print("test_agent_script_exec cost time: {0}".format(time() - api_start_time))

def tearDown(self):
    print("------------------data--------------")
    print(self.data)
    print("------------------data--------------")
    print("end unittest -----{0}".format(datetime.now()))
