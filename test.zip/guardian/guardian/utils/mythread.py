# -*- coding: utf-8 -*-
'''
@author: ray
'''

import threading


class GuardianThread(threading.Thread):

    def __init__(self, func, args=()):
        super(GuardianThread, self).__init__()
        self.func = func
        self.args = args

    def run(self):
        self.result = self.func(*self.args)

    def get_result(self):
        try:
            return self.result
        except Exception as e:
            print(e)