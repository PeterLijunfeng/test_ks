import pymysql

from guardian import settings
from guardian.apps.users.models import UserRolesModel
from guardian.settings import UCMP_ROLE_KIND_ROOT, CMDB_ROLE_KIND_ROOT, PLATFORM_CMDB, ATOMFLOW_ROLE_KIND_ROOT, \
    PLATFORM_ATOMFLOW, PLATFORM_GUARDIAN, GUARDIAN_ROLE_KIND_ROOT

"""
角色初始化脚本：
    初始化: 1.ucmp_admin
           2.ucmp_dept
           3.ucmp_user
           4.ucmp_root
           5.ucmp_app
           6.ucmp_business
           
    创建角色: 1.ucmp_admin: F5管理员,系统管理员,云平台管理员,DB管理员,中间件管理员,存储管理员
           　2.ucmp_dept: 部门管理员
           　3.ucmp_user: 普通用户
需要输入：PROJECT_ID

"""
PROJECT_ID = 'b91ff5afc1044e4c80bf9e68532a71fb'


def init_roles():
    data_root_admin = {}
    data_project_admin = {}
    data_dept_admin = {}
    data_user = {}
    data_app = {}
    data_business_admin = {}
    role_list = []

    data_root_admin['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.ROOT_ADMIN)
    data_root_admin['name'] = settings.ROOT_ADMIN
    data_root_admin['role_data'] = settings.UCMP_ROLE_KIND_ROOT
    data_root_admin['platform_name'] = settings.PLATFORM_UCMP
    data_root_admin['project_id'] = PROJECT_ID
    data_root_admin['role_ctl'] = '{}'
    role_list.append(data_root_admin)

    data_project_admin['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.PROJECT_ADMIN)
    data_project_admin['name'] = settings.PROJECT_ADMIN
    data_project_admin['role_data'] = settings.UCMP_ROLE_KIND_ADMIN
    data_project_admin['platform_name'] = settings.PLATFORM_UCMP
    data_project_admin['project_id'] = PROJECT_ID
    data_project_admin['role_ctl'] = '{}'
    role_list.append(data_project_admin)

    data_dept_admin['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.DEPT_ADMIN)
    data_dept_admin['name'] = settings.DEPT_ADMIN
    data_dept_admin['role_data'] = settings.UCMP_ROLE_KIND_DEPT
    data_dept_admin['platform_name'] = settings.PLATFORM_UCMP
    data_dept_admin['project_id'] = PROJECT_ID
    data_dept_admin['role_ctl'] = '{}'
    role_list.append(data_dept_admin)

    data_user['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.USER)
    data_user['name'] = settings.USER
    data_user['role_data'] = settings.UCMP_ROLE_KIND_USER
    data_user['platform_name'] = settings.PLATFORM_UCMP
    data_user['project_id'] = PROJECT_ID
    data_user['role_ctl'] = '{}'
    role_list.append(data_user)

    data_app['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.APP_ADMIN)
    data_app['name'] = settings.APP_ADMIN
    data_app['role_data'] = settings.UCMP_ROLE_KIND_APP
    data_app['platform_name'] = settings.PLATFORM_UCMP
    data_app['project_id'] = PROJECT_ID
    data_app['role_ctl'] = '{}'
    role_list.append(data_app)

    data_business_admin['id'] = settings.INIT_ROLE_ID.get(settings.PLATFORM_UCMP).get(settings.BUSINESS_ADMIN)
    data_business_admin['name'] = settings.BUSINESS_ADMIN
    data_business_admin['role_data'] = settings.UCMP_ROLE_KIND_BUSINESS
    data_business_admin['platform_name'] = settings.PLATFORM_UCMP
    data_business_admin['project_id'] = PROJECT_ID
    data_business_admin['role_ctl'] = '{}'
    role_list.append(data_business_admin)

    UserRolesModel.add_create_role_batch(role_list)


def create_ucmp_admin_rloes():
    new_role_list = ["F5管理员", "系统管理员", "云平台管理员", "DB管理员", "中间件管理员", "存储管理员"]
    role_list = []
    for info in new_role_list:
        data = {}
        data['name'] = info
        data['role_data'] = settings.UCMP_ROLE_KIND_ADMIN
        data['platform_name'] = settings.PLATFORM_UCMP
        data['project_id'] = PROJECT_ID
        data['role_ctl'] = '{}'
        role_list.append(data)
    UserRolesModel.add_create_role_batch(role_list)


# 创建 UCMP_ROOT 角色
def create_ucmp_root_rloes():
    new_role_list = ["超级管理员"]
    role_list = []
    for info in new_role_list:
        data = {}
        data['name'] = info
        data['role_data'] = UCMP_ROLE_KIND_ROOT
        data['platform_name'] = settings.PLATFORM_UCMP
        data['project_id'] = PROJECT_ID
        data['role_ctl'] = '{}'
        role_list.append(data)
    UserRolesModel.add_create_role_batch(role_list)


# 创建 CMDB_ROOT 角色
def create_cmdb_root_rloes():
    new_role_list = ["超级管理员"]
    role_list = []
    for info in new_role_list:
        data = {}
        data['name'] = info
        data['role_data'] = CMDB_ROLE_KIND_ROOT
        data['platform_name'] = PLATFORM_CMDB
        data['project_id'] = PROJECT_ID
        data['role_ctl'] = '{}'
        role_list.append(data)
    UserRolesModel.add_create_role_batch(role_list)


# 创建 atomflow_root 角色
def create_atomflow_root_rloes():
    new_role_list = ["超级管理员"]
    role_list = []
    for info in new_role_list:
        data = {}
        data['name'] = info
        data['role_data'] = ATOMFLOW_ROLE_KIND_ROOT
        data['platform_name'] = PLATFORM_ATOMFLOW
        data['project_id'] = PROJECT_ID
        data['role_ctl'] = '{}'
        role_list.append(data)
    UserRolesModel.add_create_role_batch(role_list)


# 创建 system_root 角色
def create_system_root_rloes():
    new_role_list = ["超级管理员"]
    role_list = []
    for info in new_role_list:
        data = {}
        data['name'] = info
        data['role_data'] = GUARDIAN_ROLE_KIND_ROOT
        data['platform_name'] = PLATFORM_GUARDIAN
        data['project_id'] = PROJECT_ID
        data['role_ctl'] = '{}'
        role_list.append(data)
    UserRolesModel.add_create_role_batch(role_list)


if __name__ == "__main__":
    # init_roles()
    # create_ucmp_admin_rloes()
    create_ucmp_root_rloes()
    create_cmdb_root_rloes()
    create_atomflow_root_rloes()
    create_system_root_rloes()
