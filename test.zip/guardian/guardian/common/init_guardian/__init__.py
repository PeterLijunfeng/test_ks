"""
init_data.py
    初始化数据库：sys_module, menu, template, sys_info_conf, logo_file
    初始化 superadmin, roles, assign role to superadmin

init_guardian_data.sql
    初始化 sys_module: sortby desc
    初始化 menu: sortby desc
    初始化 template: strategy_app_name, type_name, type_id from utils/strategy_conf.py
"""
