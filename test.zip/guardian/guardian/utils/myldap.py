# -*- coding: utf-8 -*-
"""
@author: ray
@description: 由于windows、linux在实现ldap协议后，用户定义的属性不一致，导致处理结果差异化
现在将获取属性 设置为用户自定义， 通过getattr 来读取相关属性， 使用reload 再不重启guardian情况下 用户自由定义
windows ad
    LDAP_ATTRIBUTES = {
            "dn": "distinguishedName",
            "objectGUID": "objectGUID",
            "realname": "name",
            'email': "userPrincipalName",
            'username': "sAMAccountName"
}

linux ldap

    LDAP_ATTRIBUTES = {
            "dn": "entry_dn",
            "objectGUID": "uid",
            "realname": "name",
            'email': "",
            'username': "cn"
}

"""
import ldap3
from ldap3 import Connection, Server, ALL
from guardian import settings
from imp import reload

def ldap_conn(server_addr, server_port, user, password):
    ldap_addr = server_addr+":"+str(server_port)
    try:
        server = Server(ldap_addr, get_info=ALL, connect_timeout=settings.LDAP_TIMEOUT)
        conn = Connection(server, user, password, auto_bind=True)
        return conn
    except Exception as e:
        print("Ldap Connect error:",e)


def search_ad_list(conn, search_base, objectclass_list, filter_string=None):
    """
    查询ad 数据，返回list
    :param conn:
    :param dc_list:
    :param objectclass_list:
    :return:
    """

    if not objectclass_list:
        raise Exception("objectclass is null")

    dc_search_string = search_base

    if len(objectclass_list) == 1:
        objectclass_string = '(objectclass=%s)'%objectclass_list[0]
    else:
        objectclass_string_list = []
        for objectclass in objectclass_list:
            objectclass_string_list.append('(objectclass=%s)'%objectclass)
        objectclass_string = '(&%s)'%(''.join(objectclass_string_list))

    # objectclass_string = '(&(objectclass=organizationalUnit)(objectclass=top))'
    objectclass_string = filter_string if filter_string else objectclass_string
    if conn.search(dc_search_string, objectclass_string, search_scope=ldap3.SUBTREE, attributes=ldap3.ALL_ATTRIBUTES):
        return conn.entries
    else:
        return []


def parse_org_list(org_entry_list):
    """
    :param org_entry_list:

    :return:

    """
    return map(lambda x:{
        "dn": str(getattr(x, settings.LDAP_ORG_ATTRIBUTES['dn'], "")),
        "objectGUID": str(getattr(x, settings.LDAP_ORG_ATTRIBUTES['objectGUID'], "")),
        "name": str(getattr(x, settings.LDAP_ORG_ATTRIBUTES['name'], "")),
    },org_entry_list)
    return map(lambda x: {
        "dn":x.distinguishedName.value,
        "objectGUID":x.objectGUID.value.replace("{", "").replace("}", ""),
        "name":x.name.value
    }, org_entry_list)




def parse_user_list(user_entry_list):
    """

    :param user_entry_list:
            这里违反了函数单一化功能要求， 由于发现windows下AD， 和linux ldap返回数据有出入
             做此下侧, TODO：可做成用户配置属性，根据settings配置 获取相关属性值
    :return:
    """
    reload(settings)

    for user_entry in user_entry_list:
        try:
            email = str(getattr(user_entry, settings.LDAP_ATTRIBUTES['email'], ""))
            username = str(getattr(user_entry, settings.LDAP_ATTRIBUTES['username'], ""))
            dn = str(getattr(user_entry, settings.LDAP_ATTRIBUTES['dn'], ""))
            objectGUID = str(getattr(user_entry, settings.LDAP_ATTRIBUTES['objectGUID'], "")).replace("{", "").replace("}", "")
            realname = str(getattr(user_entry, settings.LDAP_ATTRIBUTES['realname'], ""))
        except:
            pass

        yield {
            "dn": dn,
            "objectGUID": objectGUID,
            "realname": realname,
            'email': email,
            'username': username,
            'entry_data': str(user_entry)
        }

def get_ad_parent_dn(dn):
    # 'OU=测试1组,OU=西安测试中心,DC=leaptocloud,DC=com'
    dn_list = dn.split(",")
    return ",".join(dn_list[1:])
