# -*- coding:utf-8 -*-
import traceback
import json
from functools import wraps
from flask import request, Response
from guardian.common.errors import ApiException, AuthException, KeystoneHandleException
from guardian.apps.users.services import token_validate
from sqlalchemy.exc import SQLAlchemyError
from werkzeug.exceptions import HTTPException, BadRequest, Unauthorized, InternalServerError
from guardian.log4 import app_logger as log

API_NEED_LOGIN = "L"
API_OPEN = "O"
API_CLOSE = "C"
SUPPORT_CONTROL = [API_NEED_LOGIN, API_OPEN, API_CLOSE]

SYSCONFIG = {
    "upload_file": API_OPEN,
    "get_logo": API_OPEN,

    "edit_system_conf": API_NEED_LOGIN,
    "get_license": API_NEED_LOGIN,
    "get_system_conf": API_OPEN,  # login page
    "upload_license": API_NEED_LOGIN,
    "get_modules": API_NEED_LOGIN,
    "get_menus": API_NEED_LOGIN,
    "get_user_menus": API_NEED_LOGIN,
    "get_role_asigned_menus": API_NEED_LOGIN,

    "get_app_org": API_NEED_LOGIN,
    "update_app_org": API_NEED_LOGIN,
    "sync_ad_users": API_NEED_LOGIN,
    "sync_ad_orgs": API_NEED_LOGIN,

    "create_update_ldap_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "get_ldap_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "test_ldap_conf": API_NEED_LOGIN,  # allow role: ucmp_root
}

MESSAGES = {
    "create_update_msgs_strategy": API_NEED_LOGIN,
    "enable_disable_msgs_strategy": API_NEED_LOGIN,
    "del_msgs_strategy": API_NEED_LOGIN,
    "list_strategy": API_NEED_LOGIN,
    "send_strategy_message": API_OPEN,
    "send_customize_message": API_OPEN,
    "get_strategy_conf": API_NEED_LOGIN,

    "update_template": API_NEED_LOGIN,
    "list_template": API_NEED_LOGIN,

    "create_notice": API_NEED_LOGIN,  # allow role: ucmp_admin
    "list_notice": API_NEED_LOGIN,
    "list_notice_not_read": API_NEED_LOGIN,
    "mark_notice_read": API_NEED_LOGIN,
    "del_notice_status": API_NEED_LOGIN,

    "create_update_sms_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "get_sms_conf": API_NEED_LOGIN,  # allow role: ucmp_root

    "create_update_email_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "get_email_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "test_email_conf": API_NEED_LOGIN,  # allow role: ucmp_root
    "send_email": API_NEED_LOGIN,  # allow role: ucmp_root
}

USERS = {
    "list_domains": API_OPEN,
    "list_users": API_NEED_LOGIN,
    "login_user": API_OPEN,
    "login_user_scope_project": API_OPEN,
    "logout_user": API_NEED_LOGIN,
    "validate_token": API_OPEN,
    "create_user": API_NEED_LOGIN,
    "update_user": API_NEED_LOGIN,
    "delete_user": API_NEED_LOGIN,
    "user_detail": API_NEED_LOGIN,
    "reset_user_passwd": API_NEED_LOGIN,
    "modify_user_passwd": API_NEED_LOGIN,
    "get_users_by_username": API_NEED_LOGIN,
    "check_user_email": API_NEED_LOGIN,
    "change_user_project": API_NEED_LOGIN,
    "inside_list_users": API_OPEN,
    "get_administrator_users_by_role_id": API_NEED_LOGIN,
    "get_users_by_role_type": API_NEED_LOGIN,
    "get_dept_role_users": API_NEED_LOGIN,

    "create_role": API_NEED_LOGIN,
    "update_role": API_NEED_LOGIN,
    "delete_role": API_NEED_LOGIN,
    "assign_user_role": API_NEED_LOGIN,
    "get_user_role": API_NEED_LOGIN,
    "get_role_detail": API_NEED_LOGIN,
    "get_role_lists": API_NEED_LOGIN,
    "get_role_kinds": API_NEED_LOGIN,  # allow role: ucmp_root, ucmp_admin
    "check_role_by_name": API_NEED_LOGIN,
    "get_user_allow_role_list": API_NEED_LOGIN,

    "create_project": API_NEED_LOGIN,
    "update_project": API_NEED_LOGIN,
    "list_project": API_NEED_LOGIN,

    "create_org": API_NEED_LOGIN,
    "update_org_name": API_NEED_LOGIN,
    "delete_org": API_NEED_LOGIN,
    "list_sub_org_id": API_NEED_LOGIN,
    "list_parent_org_id": API_NEED_LOGIN,
    "get_sub_orgs": API_NEED_LOGIN,
    "get_org_code": API_NEED_LOGIN,
    "get_org_count_by_name": API_NEED_LOGIN,
    "get_org_by_name_or_id": API_NEED_LOGIN,
    "get_orgs_info": API_NEED_LOGIN,
    "get_org_trees": API_NEED_LOGIN,
    "org_business_trees": API_NEED_LOGIN,
    "get_users_by_roles": API_NEED_LOGIN,
}

BUSINESS = {
    "check_business_name": API_NEED_LOGIN,
    "create_business": API_NEED_LOGIN,
    "delete_business": API_NEED_LOGIN,
    "list_business": API_NEED_LOGIN,

    "check_business_apps_name": API_NEED_LOGIN,
    "list_apps_by_business": API_NEED_LOGIN,
    "get_apps_similarity": API_NEED_LOGIN,
    "create_business_apps": API_NEED_LOGIN,
    "delete_apps": API_NEED_LOGIN,
    "get_app_org": API_NEED_LOGIN,
    "update_app_org": API_NEED_LOGIN,
    "incre_auth_bulk_apps_orgs": API_NEED_LOGIN,
    "get_business_info_by_app": API_NEED_LOGIN,
    "get_business_info_by_org": API_NEED_LOGIN,
    "get_business_info_by_id": API_NEED_LOGIN,
    "list_apps_by_user_org": API_NEED_LOGIN,
}

DEVICEAGENT = {
    "get_agent_list": API_NEED_LOGIN,
    "sync_device_agent": API_NEED_LOGIN,
    "agent_script_exec": API_NEED_LOGIN
}

API_CONTROL = dict()
API_CONTROL.update(USERS)
API_CONTROL.update(MESSAGES)
API_CONTROL.update(SYSCONFIG)
API_CONTROL.update(BUSINESS)
API_CONTROL.update(DEVICEAGENT)


def auth_check():
    """
    :return: user
     {
        "id": userobj.get('id'),
        "name": userobj.get('name', ''),
        "roles": role_names,
        "token": token,
        "project_id": token_obj['project']['id'],
        "project_name": token_obj['project']['name'],
        "domain_id": userobj['domain']['id'],
        "domain_name": userobj['domain']['name'],
        "token_expires_at": token_obj["expires_at"],
    }
    """
    api_key = request.headers.get('X-Subject-Token')
    if not api_key:
        return None
    try:
        user = token_validate(api_key)
    except KeystoneHandleException as e:
        log.error("AUTH FAILED-KeystoneHandleException: %s" % str(e))
        raise AuthException(error_code=9001, msg="AUTH FAILED")
    except Exception as e:
        log.error("AUTH FAILED-Exception: %s" % str(e))
        raise AuthException(error_code=9001, msg="AUTH FAILED")
    return user


def role_check():
    pass


def restful(func):
    @wraps(func)
    def decorated_function(*args, **kwargs):
        headers = dict()
        headers['Content-Type'] = 'application/json'
        try:
            if func.__name__ not in API_CONTROL \
                    or API_CONTROL[func.__name__] not in SUPPORT_CONTROL \
                    or API_CONTROL[func.__name__] == API_CLOSE:
                raise ApiException(error_code=1003, msg="API NOT FOUND OR NOT SUPPORT")
            user = None
            if API_CONTROL[func.__name__] == API_NEED_LOGIN:
                user = auth_check()
                if not user:
                    raise AuthException(error_code=Unauthorized.code, msg="AUTH FAILED")
            kwargs["user"] = user
            data = func(*args, **kwargs)
            if user:
                headers['X-Subject-Token'] = user["token"]
            if "__token" in data:
                headers['X-Subject-Token'] = data["__token"]
                del data["__token"]
            rst_data = {
                "rst": "ok",
                "data": data,
            }
            return Response(json.dumps(rst_data), headers=headers)
        except AuthException as e:
            common_res = {"rst": "err", "msg": "认证失败", "err_code": e.error_code}
            return Response(json.dumps(common_res), status=Unauthorized.code, headers=headers)
        except SQLAlchemyError as e:
            common_res = {"rst": "err", "msg": "捕获数据操作异常(未处理),", "err_code": 4002}
            log.error("Error %s" % str(e))
            log.error("Exception error: %s" % traceback.format_exc())
            return Response(json.dumps(common_res), status=BadRequest.code, headers=headers)
        except HTTPException as e:
            common_res = {"rst": "err", "msg": "Bad Request", "err_code": e.code}
            log.error("Error %s" % str(e))
            log.error("Exception error: %s" % traceback.format_exc())
            # return abort(e.code, **common_res)
            return Response(json.dumps(common_res), status=BadRequest.code, headers=headers)
        except KeystoneHandleException as e:
            common_res = {"rst": "err", "msg": "Keystone Request failed", "err_code": e.error_code}
            log.error("Error %s" % str(e))
            log.error("Exception error: %s" % traceback.format_exc())
            # return abort(BadRequest.code, **common_res)
            return Response(json.dumps(common_res), status=BadRequest.code, headers=headers)
        except ApiException as e:
            common_res = {"rst": "err", "msg": e.msg, "err_code": e.error_code}
            log.error("Error %s" % str(e))
            log.error("Exception error: %s" % traceback.format_exc())
            return Response(json.dumps(common_res), status=BadRequest.code, headers=headers)
            # return abort(BadRequest.code, **common_res)
        except Exception as e:
            common_res = {"rst": "err", "msg": "系统响应失败", "err_code": 1000}
            log.error("Error %s" % str(e))
            log.error("Exception error: %s" % traceback.format_exc())
            return Response(json.dumps(common_res), status=InternalServerError.code, headers=headers)

    return decorated_function
