import json
from time import time
from time import sleep
from aiohttp import ClientSession
import asyncio
from io import StringIO
import traceback
from aiohttp.client_exceptions import ClientConnectorError
from aiohttp.client_exceptions import ClientError
from asyncio import TimeoutError


async def send_task_handler(idx, target_url, data, headers, method):
    try:
        s = time()
        async with ClientSession() as session:
            if method == "post":
                async with session.post(target_url, data=json.dumps(data), headers=headers, timeout=4) as response:
                    print("URL : %s, response.status : %s" %(target_url, response.status))
                    return idx, response.status, time()-s
            elif method == "get":
                async with session.get(target_url, params=data, headers=headers, timeout=4) as response:
                    print("URL : %s, response.status : %s" %(target_url, response.status))
                    return idx, response.status, time()-s
    except ClientConnectorError:
        print("ClientConnectorError: %s" % str(idx))
        return idx, 1, time()-s
    except ClientError:
        print("ClientError: %s" % str(idx))
        return idx, 2, time()-s
    except TimeoutError:
        print("TimeoutError: %s" % str(idx))
        return idx, 3, time()-s
    except Exception as e:
        except_trace = StringIO()
        traceback.print_exc(file=except_trace)
        print("idx %s, SyncError: %s" % ( str(idx),except_trace.getvalue()))
        return idx, 4, time()-s


async def dispatch_task(count, url, data, headers, method):
    failed_tasks = []
    ok_tasks = []
    all_tasks = []
    for i in range(count):
        task_item = asyncio.ensure_future(send_task_handler(i, url, data, headers, method))
        all_tasks.append(task_item)
    try:
        responses = await asyncio.gather(*all_tasks)
        for responses_item in responses:
            print("idx: %s  status: %s, cost: %s"%(responses_item[0], responses_item[1], responses_item[2]))
            if responses_item[1] != 200:
                failed_tasks.append(responses_item)
            else:
                ok_tasks.append(responses_item)
        print("failed count: %d \nok count:%d" % (len(failed_tasks), len(ok_tasks)))
    except Exception as e:
        except_trace = StringIO()
        traceback.print_exc(file=except_trace)
        print("error %s, %s"% (str(e),except_trace.getvalue()))

if __name__ == '__main__':
    times = 5
    break_sec = 2
    count = 20
    url = "http://192.168.3.124:35357/v3/auth/tokens"
    # token_list = []
    token_str = "gAAAAABcCizCdzUg7Hrj8nSw99OFrWUNCE85iBFoiC7JRXrsN9vgHUS8JJ3_Rldl55rgY4CtG-fUcKQDt-MWzL1rNmmhY8rJaiZUhEQb_xh1qtTYRX1IpimIIiv06wCvuOfYveej5_7bJZsNPdTm-L3sLx8b1iA4QywwMjcgOzcLXqMf-m-aASo"
    headers = {'content-type': 'application/json', 'X-Auth-Token': 'bb4eb0618420a94ed4d1', 'X-Subject-Token': token_str}
    data = {}
    method = "get"
    for i in range(times):
        s_time = time()
        loop = asyncio.get_event_loop()
        loop.run_until_complete(dispatch_task(count, url, data, headers, method))
        print("%d times, cost time: %d" %(i, time() - s_time))
        sleep(break_sec)



