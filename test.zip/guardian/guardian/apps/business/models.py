import json
from sqlalchemy import Column, Integer, String, desc, Text, or_
from guardian.apps import CommonModel
from guardian.utils.db import provide_session
from guardian.apps import BaseModel
from guardian.apps import ON, N_DEL, DEL
from guardian.apps.users.models import UsersOrgsModel
from guardian.log4 import app_logger as log


class BusinessModel(CommonModel, BaseModel):
    __tablename__ = "business"

    id = Column(String(40), nullable=False, primary_key=True, index=True)
    name = Column(String(50), nullable=False, doc="业务名称")
    description = Column(String(400), default='', doc="业务描述")
    project_id = Column(String(40), nullable=False, doc="域ID")
    org_id = Column(String(40), nullable=False, doc="组织ID")
    org_array = Column(Text, doc="组织信息列表")
    sortby = Column(Integer, default=0, doc="排序方式")
    enable = Column(Integer, default=ON, doc="是否可用")
    is_del = Column(Integer, default=N_DEL, doc="是否已删")

    def __init__(self, *args, **kwargs):
        super(BusinessModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_one(cls, business_id, session=None):
        qry = session.query(BusinessModel)
        if cls.id:
            qry = qry.filter(cls.id == business_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_one_name(cls, name, project_id, incloud_del=False, session=None):
        qry = session.query(BusinessModel)
        qry = qry.filter(cls.name == name).filter(cls.project_id == project_id)
        if not incloud_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, incloud_del=False, page_idx=1, limit=20, session=None, **kwargs):
        qry = session.query(cls, UsersOrgsModel) \
            .join(UsersOrgsModel, cls.org_id == UsersOrgsModel.id, isouter=True)
        if kwargs.get('name'):
            qry = qry.filter(cls.name.ilike("%{0}%".format(kwargs.get('name'))))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if kwargs.get('org_id'):
            qry = qry.filter(cls.org_id == kwargs.get('org_id'))
        if kwargs.get('org_ids'):
            qry = qry.filter(cls.org_id.in_(kwargs.get('org_ids')))
        if not incloud_del:
            qry = qry.filter(cls.is_del == N_DEL)
        res = qry.order_by(desc(BusinessModel.create_at))
        return res.count(), res.limit(limit).offset((page_idx - 1) * limit).all()

    @classmethod
    @provide_session
    def get_business_by_project(cls, incloud_del=False, session=None, **kwargs):
        qry = session.query(cls.id, cls.name, cls.org_id)
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if not incloud_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.all()

    @classmethod
    @provide_session
    def create_business(cls, session=None, **kwargs):
        entry = BusinessModel()
        entry.id = cls().gen_uuid()
        if "org_array" in kwargs:
            kwargs["org_array"] = json.dumps(kwargs.get("org_array"))
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v is not None:
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def update_business(self, session=None, **kwargs):
        can_edit = ["name", "description", "org_id", "enable", "org_array", "is_del"]
        if "org_array" in kwargs:
            kwargs["org_array"] = json.dumps(kwargs.get("org_array"))
        for k, v in kwargs.items():
            if k in can_edit and v is not None:
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @provide_session
    def del_business(self, session=None):
        self.is_del = DEL
        session.merge(self)
        session.commit()
        return self.id

    @classmethod
    @provide_session
    def add_business_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "name": data_info.get("name"),
                "description": data_info.get("description"),
                "org_id": data_info.get("org_id"),
                "org_array": data_info.get("org_array"),
                "sortby": data_info.get("sortby"),
                "enable": data_info.get("enable"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
                "project_id": data_info.get("project_id"),
                "is_del": data_info.get("is_del"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class BusinessAppsModel(CommonModel, BaseModel):
    __tablename__ = "business_apps"

    id = Column(String(40), nullable=False, primary_key=True, index=True)
    business_app_name = Column(String(50), nullable=False, index=True, doc="应用名称")
    shorter_name = Column(String(100), doc="应用简称")
    description = Column(String(400), doc="描述")
    business_id = Column(String(40), nullable=False, doc="业务ID")
    enable = Column(Integer, default=ON, doc="是否可用")
    is_del = Column(Integer, default=N_DEL, doc="是否已删除")
    project_id = Column(String(40), nullable=False, doc="租户ID")
    segmentation = Column(Text, doc="分词字符串")

    def __init__(self, *args, **kwargs):
        super(BusinessAppsModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @classmethod
    @provide_session
    def get_one(cls, app_id, session=None):
        qry = session.query(BusinessAppsModel)
        qry = qry.filter(cls.id == app_id)
        return qry.first()

    @classmethod
    @provide_session
    def get_one_name(cls, name, project_id, incloud_del=False, session=None):
        qry = session.query(cls)
        qry = qry.filter(cls.business_app_name == name).filter(cls.project_id == project_id)
        if not incloud_del:
            qry = qry.filter(cls.is_del == N_DEL)
        return qry.first()

    @classmethod
    @provide_session
    def get_list(cls, incloud_del=False, page_idx=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls)
        if kwargs.get('app_ids'):
            qry = qry.filter(cls.id.in_(kwargs.get('app_ids').split(',')))
        if kwargs.get('business_app_name') and kwargs.get('shorter_name'):
            qry = qry.filter(or_(cls.business_app_name.ilike("%{0}%".format(kwargs.get('business_app_name'))),
                                 cls.shorter_name.ilike("%{0}%".format(kwargs.get('shorter_name')))))
        if kwargs.get('business_id'):
            qry = qry.filter(cls.business_id == kwargs.get('business_id'))
        if kwargs.get('project_id'):
            qry = qry.filter(cls.project_id == kwargs.get('project_id'))
        if not incloud_del:
            qry = qry.filter(cls.is_del == N_DEL)
        res = qry.order_by(desc(BusinessAppsModel.create_at))
        return res.count(), res.limit(limit).offset((page_idx - 1) * limit).all()

    @classmethod
    @provide_session
    def get_apps_similarity(cls, session=None, **kwargs):
        qry = session.execute("select id, business_app_name, shorter_name, segmentation from business_apps where "
                              "project_id='%s' and string_to_array(segmentation, ',') && string_to_array('%s', ',') " %
                              (kwargs.get('project_id'), kwargs.get('app_name_seg')))
        return qry.fetchall()

    @provide_session
    def update_app(self, session=None, **kwargs):
        can_edit = ["business_app_name", "shorter_name", "description", "enable", "is_del", "segmentation"]
        for k, v in kwargs.items():
            if k in can_edit and v is not None:
                setattr(self, k, v)
        session.merge(self)
        session.commit()

    @classmethod
    @provide_session
    def create_app(cls, session=None, **kwargs):
        entry = BusinessAppsModel()
        entry.id = cls().gen_uuid()
        for k, v in kwargs.items():
            if k in cls.__dict__.keys() and v is not None:
                setattr(entry, k, v)
        session.add(entry)
        session.commit()
        return entry

    @provide_session
    def del_app(self, session=None):
        self.is_del = DEL
        session.merge(self)
        session.commit()
        return self.id

    @classmethod
    @provide_session
    def add_business_apps_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": data_info.get("id"),
                "business_app_name": data_info.get("business_app_name"),
                "description": data_info.get("description"),
                "business_id": data_info.get("business_id"),
                "enable": data_info.get("enable"),
                "shorter_name": data_info.get("shorter_name"),
                "create_at": data_info.get("create_at"),
                "update_at": data_info.get("update_at"),
                "project_id": data_info.get("project_id"),
                "is_del": data_info.get("is_del"),
                "segmentation": data_info.get("segmentation"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )


class BusinessAppOrgModel(CommonModel, BaseModel):
    __tablename__ = "business_app_org"

    id = Column(String(40), nullable=False, primary_key=True, index=True)
    app_id = Column(String(50), nullable=False, index=True, doc="应用id")
    org_id = Column(String(100), doc="组织机构id")

    def __init__(self, *args, **kwargs):
        super(BusinessAppOrgModel, self).__init__(*args, **kwargs)

    def __repr__(self):
        return "<TAG: {self.id}>".format(self=self)

    @provide_session
    def get_one(self, session=None):
        qry = session.query(BusinessAppOrgModel)
        if self.id:
            qry = qry.filter(BusinessAppOrgModel.id == self.id)
        return qry.first()

    @classmethod
    @provide_session
    def create_business_app_org(cls, app_id, org_id, session=None):
        entry = BusinessAppOrgModel()
        entry.id = cls().gen_uuid()
        entry.app_id = app_id
        entry.org_id = org_id
        session.add(entry)
        session.commit()
        return entry

    @classmethod
    @provide_session
    def bulk_add_app_org(cls, app_org_list, session=None):
        data_list = []
        for app_id, org_id in app_org_list:
            data_item = {
                "id": cls().gen_uuid(),
                "app_id": app_id,
                "org_id": org_id
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def get_orgs_by_app_id(cls, app_id, session=None):
        qry = session.query(cls).filter(cls.app_id == app_id)
        return qry.all()

    @classmethod
    @provide_session
    def get_orgs_join_app(cls, session=None, **kwargs):
        qry = session.query(cls.org_id, BusinessAppsModel.id, BusinessAppsModel.business_app_name,
                            BusinessAppsModel.shorter_name).join(BusinessAppsModel, cls.app_id == BusinessAppsModel.id)
        if kwargs.get("project_id"):
            qry = qry.filter(BusinessAppsModel.project_id == kwargs.get("project_id"))
        return qry.all()

    @classmethod
    @provide_session
    def delete_app_org_by_app_org(cls, app_id, org_id, session=None):
        qry = session.query(cls).filter(cls.app_id == app_id).filter(cls.org_id == org_id)
        return qry.delete()

    @classmethod
    @provide_session
    def add_business_org_batch(cls, data, session=None):
        data_list = []
        for data_info in data:
            data_item = {
                "id": cls().gen_uuid(),
                "app_id": data_info.get("app_id"),
                "org_id": data_info.get("org_id"),
            }
            data_list.append(data_item)
        session.execute(
            cls.__table__.insert(),
            data_list
        )

    @classmethod
    @provide_session
    def list_app_info_by_org(cls, page_idx=1, limit=10000, session=None, **kwargs):
        qry = session.query(cls, BusinessAppsModel)
        qry = qry.join(BusinessAppsModel, cls.app_id == BusinessAppsModel.id)
        if kwargs.get('org_id'):
            qry = qry.filter(cls.org_id == kwargs.get('org_id'))
        res = qry.order_by(desc(cls.create_at))
        return res.count(), res.limit(limit).offset((page_idx - 1) * limit).all()


@provide_session
def get_business_info_by_app_id(app_id, session=None):
    qry = session.query(BusinessModel).join(BusinessAppsModel, BusinessModel.id == BusinessAppsModel.business_id)
    qry = qry.filter(BusinessAppsModel.id == app_id)
    return qry.first()
